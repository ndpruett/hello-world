import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.webdom.api.elements.DOMBrowser;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
		
		getVariables().set("MyURL","https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		getVariables().set("GLBL_ExtractFileName","DASF_Report_04202021_01.pdf",
			Variables.Scope.GLOBAL);
		getVariables().set("GLBL_OBIEE_TAMCN","%D00037K%",
			Variables.Scope.GLOBAL);
		getVariables().set("GLBL_OBIEE_AAC_NO","%M29030%",
			Variables.Scope.GLOBAL);
		
		/* Configure per environment, notes in next section */
		
		getVariables().set("DROP_1","36",
			Variables.Scope.GLOBAL);
		getVariables().set("SEARCH_1","94",
			Variables.Scope.GLOBAL);
		getVariables().set("DROP_2","37",
			Variables.Scope.GLOBAL);
		getVariables().set("SEARCH_2","94",
			Variables.Scope.GLOBAL);

		
		/*
		 * DEV DROPDOWN #1 INDEX = 37
		 * DEV SEARCH #1 INDEX = 100
		 * DEV DROPDOWN #2 INDEX = 38
		 * DEV SEARCH #2 INDEX = 100
		 * CM DROPDOWN #1 INDEX = 36
		 * CM SEARCH #1 INDEX = 94
		 * CM DROPDOWN #2 INDEX = 37
		 * CM SEARCH #2 INDEX = 94
		 * PATCH DROPDOWN #1 INDEX = 36
		 * PATCH SEARCH #1 INDEX = 68
		 * PATCH DROPDOWN #2 INDEX = 37
		 * PATCH SEARCH #2 INDEX = 90
		 */
		
	} //public void initialize() throws Exception

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
				getDatabank("dasf_report_db").getNextDatabankRecord();
				executeDASFReport();
				
	} //public void run() throws Exception
	
	/* DEV
	 * CM 
	 * PATCH = 97
	 */

	
			public void executeDASFReport() throws Exception {
				getDatabank("dasf_report_db").getNextDatabankRecord();
				getVariables().set("GLBL_ExtractFileName","{{db.dasf_report_db.filename,MAL_Report_04202021_01.pdf}}",
				Variables.Scope.GLOBAL);
		
				
				browser.launch();
				DOMBrowser myBrowser = web.window("/web:window[@index='0' or @index='1']");
				myBrowser.maximize();
				getScript("CACI_FunctLib_EBSFunctions").callFunction(
				"EBSCertificateLogin", "{{MyURL}}", "243");
				delay(3000);
				userNavigation();
				genDASFReport();
				delay(12000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "02_DASF_Information");
				delay(12000);
				getScript("ExportOBIEEFunction_DASF").callFunction("processExportPDF");
				delay(12000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "{{db.dasf_report_db.screen_no,01}}_DASF_Report_Generated");
				delay(12000);
				browser.close();
		
	} //public void executeDASFReport() throws Exception
	
	private void userNavigation() throws Exception {
		
		/*
		
		
				beginStep(
						"[1] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DY%2BaMJ89go7i%2BEo7G03X9bpipUabSXtek1PGXJ0f15v8o3OBZNz%2FPiSYUwZxwdS13OqyLW0DP9QKUvopGTfz3XXDkr%2B9TbZQTruFE2%2FxXGZB6KblY0N9%2FMJFS1MJXN9OYRIvL1YD15Fyb3CtOcJUsay%2Fze0D7S4vyscGt2IWYRBRMpo (/obrareq.cgi)",
						0);
				{
					web.window(31, "/web:window[@index='0' or @title='about:blank']")
							.navigate(
									"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin");
					web.window(32,
							"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
							.waitForPage(null);
					{
						delay(4000);
					}
					web.button(
							33,
							"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
							.click();
				}
				endStep();
				
				*/
				
				beginStep("[2] Select User Role", 0);
				{
					//web.window(34, "/web:window[@index='0' or @title='Home']")
					//		.waitForPage(null);
					{
						delay(12000);
					}
					web.element(
							37,
							"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC OBIEE Reports User' or @index='68']")
							.click();
				}
				endStep();
				beginStep("[3] Select User Responsibility", 0);
				{
					web.window(38, "/web:window[@index='0' or @title='Home']")
							.waitForPage(null);
					{
						delay(8000);
					}
					web.element(
							41,
							"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='OBIEE Dashboards & Reports' or @index='70']")
							.click();
				}
				endStep();
				beginStep(
						"[4] Launch OBIEE Report", 0);
				{
					web.window(42, "/web:window[@index='0' or @title='Home']")
							.waitForPage(null);
					{
						delay(6000);

					}
					web.link(
							46,
							"/web:window[@index='1' or @title='OBIEE Launcher']/web:document[@index='1']/web:a[@text='Open this content in a new window' or @href='javascript:makeNewWindow();' or @index='0']")
							.click();
				}
				endStep();
		
		
	} //private void userNavigation() throws Exception
		
		private void genDASFReport() throws Exception {
			
			
		
				beginStep(
						"[5] Navigate to DASF", 0);
				{
					web.window(
							47,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']")
							.waitForPage(null);
					{
						delay(3000);
					}
					web.link(
							48,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']/web:document[@index='0']/web:a[@text='DASF' or @href='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/saw.dll?Dashboard&PortalPath=/shared/Supply/GCSS-MC Document Management/Doc Management&Page=DASF' or @index='18']")
							.click();
				}
				endStep();
				beginStep(
						"[6] DASF Report - Input Values", 0);
				{
					web.window(
							49,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']")
							.waitForPage(null);
					{
						delay(3000);
					}
					web.image(
							51,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:img[@id='saw_7802_7_1_dropdownIcon' or @index='{{DROP_1,36}}' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/master/selectdropdown_ena.png']")
							.click();
					{
						delay(3000);
					}
					web.element(
							52,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:span[@text='More/Search...']")
							.click();
					{
						delay(3000);
					}
					web.image(
							53,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:img[@id='idRemoveAllButton' or @index='49' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/uicomponents/obips.Shuttle/shuttleleftall_dwn.png']")
							.click();
					{
						delay(3000);
					}
					web.textBox(
							54,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:input_text[@id='choiceListSearchString_D' or @name='choiceListSearchString' or @index='3']")
							.click();
					{
						delay(3000);
					}
					web.textBox(
							55,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:input_text[@id='choiceListSearchString_D' or @name='choiceListSearchString' or @index='3']")
							.setText("%M29030%");
					{
						delay(3000);
					}
					web.button(
							56,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:input_button[@id='searchButton' or @name='searchButton' or @value='Search' or @index='1']")
							.click();
					{
						delay(3000);
					}
					web.image(
							57,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:img[@id='idMoveAllButton' or @index='47' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/uicomponents/obips.Shuttle/shuttlerightall_dwn.png']")
							.click();
					{
						delay(3000);
					}
					web.link(
							58,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:a[@text='OK' or @href='javascript:void(0)' or @index='24']")
							.click();
					{
						delay(6000);
					}
					web.image(
							59,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:img[@id='saw_7821_4_1_dropdownIcon' or @index='{{DROP_2,37}}' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/master/selectdropdown_ena.png']")
							.click();
					{
						delay(3000);;
					}
					web.element(
							60,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:span[@text='Search...' and @index='{{SEARCH_2,97}}']")
							.click();
					{
						delay(3000);;
					}
					web.image(
							61,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:img[@id='idRemoveAllButton' or @index='49' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/uicomponents/obips.Shuttle/shuttleleftall_dwn.png']")
							.click();
					{
						delay(3000);;
					}
					web.element(
							62,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:div[@text='SUPPLY' or @index='113']")
							.click();
					{
						delay(3000);
					}
					web.image(
							63,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:img[@id='idMoveButton' or @index='46' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/uicomponents/obips.Shuttle/shuttleright_dwn.png']")
							.click();
					{
						delay(3000);
					}
					web.link(
							64,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:a[@text='OK' or @href='javascript:void(0)' or @index='24']")
							.click();
					{
						delay(3000);
					}
					web.button(
							65,
							"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Doc Management']/web:document[@index='0']/web:input_button[@id='idContinueButton' or @value='Continue' or @index='0']")
							.click();
				}
				endStep();
		

	} // private void genDASFReport() throws Exception

	public void finish() throws Exception {
		
	} //public void finish() throws Exception
	
} //public class script extends IteratingVUserScript
