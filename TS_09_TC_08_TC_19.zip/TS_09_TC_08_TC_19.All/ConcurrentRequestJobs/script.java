import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
		getVariables().set("MyURL","https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		getVariables().set("MyUser","200",
			Variables.Scope.GLOBAL);
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
		beginStep("Unit Test ");
		{
		String submittedRequestID;
		String submittedRequestPhase;
		
			try
			{
				boolean closeEBS = true;  // use 'false' This will not close the EBSForms. 'false' is used, When you require the loop until the concurrent request completed.
				Object submittedRequestIDObject = processConcurrentRequestJob("XXMC_CREATE_MI_IB_REL_SKD", closeEBS); 
				
				submittedRequestID = submittedRequestIDObject.toString();
				
				//Below lines of code needed when require to wait for the request Concurrent Request Job to be COMPLETED.  Remember this will work only when the 2nd parameter on processConcurrentRequestJob is 'false'
				//Start looping code to follow the status
				/*
				submittedRequestPhase = getConcurrentRequestPhase(submittedRequestID);	
				
				while (submittedRequestPhase.equals("Running"))
				{
					delay(30000);
					submittedRequestPhase = getConcurrentRequestPhase(submittedRequestID);	
				}
				//End looping code to follow the status
				*/
			}
			catch (Exception e){
				info(" Exception in run () : " + e.getMessage());
				throw e;
			} // try
		} //beginStep ("Unit Test")
		endStep();

	} // public void run()

	public void finish() throws Exception {
	}
	
	public void openBrowserGCSSMC() throws Exception {
		browser.launch();
	}

	public void closeBrowserGCSSMC() throws Exception {
		browser.close();
	}
	
	
	
	/*
	 * processConcurrentRequestJob will navigate to EBS Jobs submission step and submit it.
	 * This will not support any parameters to be submitted along with Job submission.
	 * 
	 * @param return String is the RequestID that can be used by calling function for further purposes
	 * @param String PAR_processName must be the same name as the Concurrent Request Process Name
	 * @param boolean PAR_isCloseApplication 'true' - close EBS Forms and Browser. 'false' - Do not close the EBS forms
	 * 			The situation 'false' will be used is when the calling function has a need to use the returned String <Concurrent Request ID>
	 * 			and loop it until the job phase becomes COMPLETED before moving forward with next steps.
	 * 
	 * Below is the code snippet for consideration to validate the status of the request submitted until it moved out of 'Running' status
	 * 			Object submittedRequestIDObject = getScript("ConcurrentRequestJobs").callFunction("processConcurrentRequestJob", "XXMC_CREATE_MI_IB_REL_SKD",false);  // change the job name hard coded here to the one you want
	 * 
	 *          // The below part of code assumes the EBS Forms is still open.  The 'false' boolean on the above line confirms that the EBS form need not be closed
	 *			submittedRequestID = submittedRequestIDObject.toString();
	 *					
	 *			delay(5000);
	 *			Object submittedRequestPhaseObject = null;
	 *				
	 *			submittedRequestPhase = "Running"; // Setting a default value of Running to enter the following loop, it will loop until the status is something other than "Running" like Completed or Error
	 *				
	 *			int count = 0;
					
	 *			while (submittedRequestPhase.equals("Running"))
	 *			{
	 *				if (count > 0) // firsst run within the loop need not wait for 10 seconds
	 *				{
	 *					delay(30000); // 30 seconds delay						
     *				}
	 *				submittedRequestPhaseObject = getScript("ConcurrentRequestJobs").callFunction(
	 *						"getConcurrentRequestPhase", submittedRequestID);
	 *
	 *				submittedRequestPhase = submittedRequestPhaseObject.toString();
	 *
	 *				count++;
	 *			} // while (submittedRequestPhase.equals("Running"))
	 * 
	*/
	public String processConcurrentRequestJob(String PAR_processName, boolean PAR_isCloseApplication) throws Exception {
		String submittedRequestID = null;
		//String submittedRequestPhase = null;
		
		try
		{
			navigateToHomePage();

			navigateSubmitConcurrentRequest ();  // Call to Navigate to Submit Concurent Request
			
			submittedRequestID = submitConcurrentRequest(PAR_processName);
			
			//submittedRequestPhase = getConcurrentRequestPhase(submittedRequestID);	
			
			if (PAR_isCloseApplication) // if true
			{
				closeEBSForm();
			}
			
			return submittedRequestID;  // return the ConcurrentRequest RequestID
		}
		catch (Exception e) {
			info("processConcurrentRequestJob : " + e.getClass() + e.getMessage());
			throw e;
		}
	} // public void processConcurrentRequestJob(String PAR_processName)
	
	private void navigateToHomePage() throws Exception {
		beginStep("navigateToHomePage()",0);
	{
		getVariables().set("MyUser", "243", Variables.Scope.GLOBAL);
		getScript("CACI_FunctLib_EBSFunctions")
				.callFunction(
						"EBSCertificateLogin",
						"{{MyURL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}",
						"{{MyUser,243}}");
	}
	endStep();
	
	} //public void navigateToHomePage ()
	
	
	private void navigateSubmitConcurrentRequest () throws Exception {
		delay(12000);
		
		getScript("CACI_FunctLib_EBSFunctions").callFunction("enterResponsiblity", "GCSS-MC Help Desk Concurrent Manager","Run Requests");
		delay(3000);

		getScript("CACI_FunctLib_EBSFunctions").callFunction("SS_getEBSNavigationAndClickOnMenuItems", "Run Requests",";");
		delay(12000);
		
		//to click the 2nd Open on the notification bar, since the 1st notification bar goes off by default
		for(int i=0; i<5; i++) {
			if (web.notificationBar(15, "/web:window[@index='0' or @title='Home']").exists()) {
				web.notificationBar(15, "/web:window[@index='0' or @title='Home']")
				.clickButton("Open");
				
				break;
			}
			delay(3000);
		} // for(int i=0; i<5; i++)
			
	} // public void navigateSubmitConcurrentRequest ()
	
	private String submitConcurrentRequest(String PAR_processName) throws Exception
	{
		
		String decisionMessage = "";
		String concurrentRequestNumber = "";

		beginStep("[4] Submit a New Request", 0);
		{
			forms.captureScreenshot(17);
			{
				think(215.797);
			}
			forms.button(18, "//forms:button[(@name='WHAT_TYPE_OK_0')]")
					.click();
		}
		endStep();

		
		beginStep("[5] Submit Request", 0);
		{
			forms.captureScreenshot(20);
			{
				think(2.86);
			}
			forms.textField(21,
					"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]")
					.setText(PAR_processName);
			{
				think(0.0);
			}
			forms.textField(22,
					"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(2.015);
			}
			forms.button(23, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
					.click();
		}
		endStep();
		beginStep("[6] Caution", 0);
		{
			forms.captureScreenshot(25);
			{
				think(2.141);
			}
			forms.choiceBox(26, "//forms:choiceBox").clickButton("OK");
			{
				think(0.609);
			}

		}
		endStep();
		beginStep("[7] Decision", 0);
		{
			forms.captureScreenshot(29);
			{
				think(2.797);
			}
			
			//getVariables().set(decisionMessage, forms.choiceBox(216, "//forms:choiceBox").getAlertMessage());
			decisionMessage = forms.choiceBox(216, "//forms:choiceBox").getAlertMessage();
			
			concurrentRequestNumber = getConcurrentRequestIDNumber(decisionMessage);

	        info (getClass().getName() + " submitConcurrentRequest(String PAR_processName) " + "decisionMessage : " + decisionMessage);

	        info(getClass().getName() + " submitConcurrentRequest(String PAR_processName) " + "concurrentRequestNumber : " + concurrentRequestNumber);
	        
			forms.choiceBox(30, "//forms:choiceBox").clickButton("No");
			
			think(1.797);
		}
		endStep();
		
		info ("Before return of concurrentRequestNumber : " + concurrentRequestNumber);
		
		return concurrentRequestNumber;
		
	} // public String submitConcurrentRequest(String "PAR_processName")

	private String getConcurrentRequestIDNumber(String PAR_myString) throws Exception {
        /*
         * Synopsis this function parses the requestIDNumber from the alert
         * message that has the request id number this is normally called by the
         * function getRequestIDThenClickButton() but it can be used whenever
         * you need to parse a number from any string
         * 
         * @param PAR_myString - This is a string to parse the number from
         * 
         * @return requestID or the number in the string in String type
         * 
         * manny gochuico, CACI International
         */
        final StringBuilder requestID = new StringBuilder(PAR_myString.length());
        for (int i = 0; i < PAR_myString.length(); i++) {
                final char x = PAR_myString.charAt(i);
                if (x > 47 && x < 58) {
                        requestID.append(x);
                }
        }
        return requestID.toString();
	} // end of getConcurrentRequestIDNumber
	
	/**
	 * Purpose is to identify using View -> Request the current Phase
	 * Provides the current Phase like RUNNING or COMPLETED etc
	*/
	public String getConcurrentRequestPhase(String PAR_RequestID) throws Exception
	{
		String currentPhase = "";
		
		beginStep("[9] Find Requests", 0);
		{
	
			forms.window(1685, "//forms:window[(@name='NAVIGATOR')]")
					.selectMenu("View|Requests");
		}
		endStep();
		beginStep("[10] Find Requests", 0);
		{
			forms.captureScreenshot(1687);
			{
				think(3.86);
			}
			forms.radioButton(1688,
					"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]")
					.select();
			{
				think(8.877);
			}
			forms.textField(1689,
					"//forms:textField[(@name='JOBS_QF_REQUEST_ID_0')]")
					.setText(PAR_RequestID); //passing RequestID
			{
				think(0.0);
			}
			forms.button(1690, "//forms:button[(@name='JOBS_QF_FIND_0')]")
					.click();
			{
				think(0.0);
			}
			forms.window(1691, "//forms:window[(@name='JOBS')]").activate(true);
		}
		endStep();
		beginStep("[11] Requests", 0);
		{
			forms.captureScreenshot(1693);
			{
				think(2.279);
			}
			forms.button(1694, "//forms:button[(@name='JOBS_REFRESH_0')]")
					.setFocus();
			{
				think(1.451);
			}
			forms.textField(1695,
					"//forms:textField[(@name='JOBS_REQUEST_ID_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(0.784);
			}
			forms.textField(1696, "//forms:textField[(@name='JOBS_PROGRAM_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(1.365);
			}
			forms.textField(1697, "//forms:textField[(@name='JOBS_PARENT_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(1.588);
			}
			forms.textField(1698, "//forms:textField[(@name='JOBS_PHASE_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(1.716);
			}
			
			//getVariables().set(currentPhase, forms.textField(1698, "//forms:textField[(@name='JOBS_PHASE_0')]").getText());
			
			currentPhase = forms.textField(1698, "//forms:textField[(@name='JOBS_PHASE_0')]").getText();
	
			
			forms.textField(1699, "//forms:textField[(@name='JOBS_STATUS_0')]")
					.invokeSoftKey("NEXT_FIELD");
		}
		endStep();
		
		info("currentPhase : " + currentPhase);
	
		return currentPhase;
	} // public String getConcurrentRequestPhase(String PAR_RequestID)

	public void closeEBSForm () throws Exception {
		try
		{
			beginStep(" closeEBSForm() : Navigator - GCSS-MC Help Desk Concurrent Manager", 0);
			{
				forms.window(107, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
				forms.captureScreenshot(105);
				{
					delay(5000);
				}
				forms.window(106, "//forms:window[(@name='NAVIGATOR')]").close();
				{
					delay(3000);
				}
				forms.choiceBox(362, "//forms:choiceBox").clickButton("OK");
				{
					delay(5000);
				}

				web.window(108, "/web:window[@index='0' or @title='Home']").close();
			}
			endStep();
		}
		catch (Exception e)
		{
			info(" closeEBS Form () : " + getClass().getName() + e.getMessage());
			throw e;
		}
	}  // public void closeEBSForm () throws Exception	
	
	

	
	public void clickOnViewRequests(String PAR_formName) throws Exception {
		/*
		 * @parameter PAR_formName refers to the EBS form displayed on the
		 * screen . for example:
		 *  "ORDER" to perform a view-request action on a sales order form
		 *  "NAVIGATOR" to perform a view-request action from the NAVIGATOR
		 *  
		 *  clickOnViewRequests("NAVIGATOR");
		 */
		try
		{
			beginStep(
				"[1] Click on View | Requests",
				0);
			{
	
				forms.captureScreenshot(25);
				{
					think(1.0);
				}
				forms.window(
					26,
					"//forms:window[(@name='" + PAR_formName + "')]").selectMenu(
					"View|Requests");
	
	
			}
			endStep();
		} // try
		catch(Exception e)
		{
			info("clickOnViewRequests(String PAR_formName) : " + getClass().getName() + e.getMessage());
			throw e;
		}
		
	} // end of clickOnViewRequests(String PAR_formName)
	
	
	public void clickOnSubmitNewRequestsButton() throws Exception {
		/*
		 * when you click on View-Request, this function clicks on the
		 * "Submit New Requests" button on the view-Request form
		 */
		try
		{
			beginStep(
				"[1] Click on Submit a new Request",
				0);
			{
	
				forms.captureScreenshot(28);
				{
					think(1.0);
				}
				forms.radioButton(
					29,
					"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_MY_COMPLETED_JOBS_0')]").setFocus();
				{
					think(0.0);
				}
				forms.button(
					30,
					"//forms:button[(@name='JOBS_QF_NEW_0')]").click();
	
				{
					think(2.0);
	
				}
			}
			endStep();
		} //try
		catch(Exception e)
		{
			info("clickOnSubmitNewRequestsButton() : " + getClass().getName() + e.getMessage());
			throw e;
		}
	} // end of clickOnSubmitNewRequestsButton()
	
	
	public void enterConcurrentOrReportName(String PAR_concurrentProgramName) throws Exception {
		/*
		 * In the Submit new Request Form, this is the function where you enter
		 * the concurrent program name and then press the tab button. if there
		 * are parameters for the report or concurrent program, then you must
		 * record that options form and call that function after this function.
		 * 
		 * usage:
		 * 
		 * This function is used with 6 other functions that you will use sequentially in your script.
		 * 1) clickOnViewRequests(String PAR_formName) - This initiates the the View/Request functionality
		 * 2) clickOnSubmitNewRequestsButton() - This clicks on the New Request Button
		 * 3) enterConcurrentOrReportName(String PAR_concurrentProgramName) - This script. ..  is a script wher eyou enter the job name
		 * 4) enterReportParameter(String PAR_ParameterLabel, String PAR_ParameterValue) - you enter one or more of this line to enter a parameter
		 * 5) clickOKOnParameterWindow() - this clicks on the OK button in the parameter window
		 * 6) clickOKOnSubmitRequestButton() - this will submit the job
		 * 
		 */
		try
		{
			beginStep(
				"[1] Submit New Request",
				0);
			{
	
				forms.captureScreenshot(64);
				{
					think(1.0);
				}
				forms.textField(
					65,
					"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]").setText(
					PAR_concurrentProgramName);
	
				{
					think(1.0);
				}
				forms.textField(
					66,
					"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]").invokeSoftKey(
					"NEXT_FIELD");
			}
			endStep();
		}
		catch(Exception e)
		{
			info("enterConcurrentOrReportName(String PAR_concurrentProgramName)" + getClass().getName() + e.getMessage());
			throw e;
		}
	} // end of enterConcurrentOrReportName(String PAR_concurrentProgramName)

	public boolean checkIfTheRecordWasSaved(String PAR_Message) throws Exception
	{
		/*
		 * usage checkIfTheRecordWasSaved("records applied and saved")
		 */
		boolean recordWasSaved = false;
		String statusBarMessage = null;
		
		try
		{

			{
				think(1.0);
			}
			statusBarMessage = forms.statusBar(96, "//forms:statusBar").getText();
			
			if(statusBarMessage.indexOf(PAR_Message)>0)
				recordWasSaved = true;
	
			{
				think(1.0);
			}

		} catch (Exception e){
			{
				info("ERROR executing checkIfTheRecordWasSaved");
				info("error message: "+e);
				throw e;
			}
		}
		return recordWasSaved;
		
	} // end of checkIfTheRecordWasSaved

	public void enterReportParameter(String PAR_ParameterLabel, String PAR_ParameterValue) throws Exception
	{
		
		{
			think(1.0);
		}
		forms.flexWindow(88, "//forms:flexWindow").setText(PAR_ParameterLabel,
				"", PAR_ParameterValue);
		{
			think(1.0);
		}
		forms.captureScreenshot(87);
	} // end of enterReportParameter

	public void clickOKOnParameterWindow() throws Exception
	{
		{
			think(1.0);
		}
		forms.flexWindow(92, "//forms:flexWindow").clickOk(); // click OK on parameter window
	} // end of clickOKOnParameterWindow

	public void clickOKOnSubmitRequestButton() throws Exception
	{
		try
		{
			{
				think(1.0);
			}
			forms.button(95, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
			.click(); // click on submit request Submit button
			{
				think(1.0);
			}
		}
		catch(Exception e)
		{
			info("clickOKOnSubmitRequestButton() : " + getClass().getName() + e.getMessage());
			throw e;
		}
		
	} // end of clickOKOnSubmitRequestButton
	
}
