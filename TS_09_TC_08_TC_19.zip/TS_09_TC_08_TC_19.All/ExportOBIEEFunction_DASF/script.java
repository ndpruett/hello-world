import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
	}
	
	public void processExportPDF() throws Exception {
		try
		{
			//EXPORT PDF//
			beginStep("[9] Oracle BI Interactive Dashboards - MAL (/saw.dll)", 0);
			{
				web.window(73, "/web:window[@index='2']").waitForPage(null);
				{
					delay(5000);
				}
				Integer i;
				for (i=0;i<1000000;i++){
				
					
					if ( web.link(
					75,
					"/web:window[@index='2']/web:document[@index='0']/web:a[@text='Export']")
					.exists())
					
				{
					
						break;
						
				}
					
					delay(30000);
			}
				
				web.link(
						75,
						"/web:window[@index='2']/web:document[@index='0']/web:a[@text='Export']")
						.click();
				{
					delay(5000);
				}
				/*
				web.element(
						76,
						"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MAL']/web:document[@index='0']/web:td[@text='PDF' or @index='410']")
			     		.click();
			}
			endStep();
			//SAVE PDF//
			beginStep("[10] Oracle BI Interactive Dashboards - MAL (/saw.dll)", 0);
			{
	//			web.window(77,
	//			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MAL']")
	//			.waitForPage(null);
				{
					delay(5000);
				}
				info("Line 1");
				web.link(
						80,
						"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MAL']/web:document[@index='0']/web:a[@text='OK' or @href='javascript:void(0)' or @index='36']")
						.click();
				{
					delay(12000);
				}
				info("Line 2");
				web.notificationBar(81,
						"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MAL']")
						.selectOptionBy("Save", "Save as");
				{
					delay(5000);
				}
				info("Line 3");
	
				web.dialog(109, "/web:dialog_unknown[@text='Save As' or @index='0']")
						.setText(0, PAR_ExtractFileName);
				{
					delay(5000);
				}
				web.dialog(110,
						"/web:dialog_unknown[@text='Save As' or @index='0']")
						.clickButton(0);
				{
					delay(5000);
				}
			//	web.dialog(111,
			//			"/web:dialog_unknown[@text='Save As' or @index='0']")
			//			.clickButton(0);
				{
					delay(5000);
				}
				web.notificationBar(112,
						"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MAL']")
						.clickButton("Close");
				{
					delay(5000);
				}
			}
			endStep();
			//END SAVE AS PDF

		*/
		
		}
	}
		catch(Exception e){
			info("processExportPDF(String PAR_ExtractFileName) : "+ e.getMessage());
			throw e;
		}
		
	}//public void processExportPDF(String PAR_ExtractFileName) throws Exception

	public void finish() throws Exception {
	}
}
