import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.webdom.api.elements.DOMBrowser;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
		getVariables().set("GLBL_Replacement", "M2903012210073",
				Variables.Scope.GLOBAL);

	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
		pickPackShip();
		
	}
	
	public void pickPackShip() throws Exception {
		
		userNavigation();
		enterReplacementSDN();
		pickandShip();
		transactMoveOrder();
		confirmShipment();
		closeEBSBrowser();
		browser.close();
		
		
	} //pickPackShip()
	
	
	public void userNavigation() throws Exception {
		
		getVariables().set("MyURL",
			"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		browser.launch();
		DOMBrowser myBrowser = web.window("/web:window[@index='0' or @index='1']");
		myBrowser.maximize();
		getScript("CACI_FunctLib_EBSFunctions").callFunction(
			"EBSCertificateLogin", "{{MyURL}}", "243");
			delay(3000);
		
		beginStep("[1] No Title (/AppsLogin)", 0);
		{
			web.window(2, "/web:window[@index='0' or @title='about:blank']")
					.navigate(
							"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin");
			{
				delay(12000);
			}
			
			
		
		}
		endStep();
		beginStep(
				"[2] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DPT4rKSi2c1RXo2cTxRFqnBcrJSDvxOkljy682dT8cpLleyh8EQbOkawLMMdKYaXh%2Bz8oKSWOVRmDS1YeocQu0HjmW0m3X9EUW2621zNc1XZuHkz2wMSAIz8%2BLtmvmAufxBC3gblWi7NqsfBBXdzPSYO9IvscrhI9fVGn3MtMxlLmMX6JpD7PIoHr (/obrareq.cgi)",
				0);
		{
			web.window(5,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					.waitForPage(null);
			{
				delay(12000);;
			}
			web.button(
					6,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
					.click();
		}
		endStep();
		beginStep("[3] Home (/OA.jsp)", 0);
		{
			web.window(7, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(12000);
			}
			web.element(
					10,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Inventory / Supply Shipping & Receiving NCO' or @index='58']")
					.click();
		}
		endStep();
		beginStep("[4] Home (/OA.jsp)", 0);
		{
			web.window(11, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(12000);
			}
			web.element(
					14,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Shipping' or @index='178']")
					.click();
		}
		endStep();
		beginStep("[5] Home (/OA.jsp)", 0);
		{
			web.window(15, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(12000);
			}
			web.element(
					18,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Transactions' or @index='180']")
					.click();
		}
		endStep();
		
		
	}
	
		public void enterReplacementSDN()throws Exception {
		
		
		beginStep("[6] Organizations (Working...)", 0);
		{
			forms.captureScreenshot(20);
			{
				delay(6000);
			}
			forms.listOfValues(21, "//forms:listOfValues").find("%MRA%");
		}
		endStep();
		beginStep("[7] Query Manager", 0);
		{
			forms.captureScreenshot(23);
			{
				delay(6000);
			}
			forms.textField(24,
					"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
					.setText("{{GLBL_Replacement,23823838}}");
			{
				delay(3000);
			}
			forms.textField(25,
					"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				delay(3000);
			}
			forms.button(26, "//forms:button[(@name='QUERY_MANAGER_FIND_0')]")
					.click();
		}
		endStep();
		
		beginStep("[8] Caution", 0);
		{
			forms.captureScreenshot(28);
			{
				delay(3000);
			}
			forms.choiceBox(29, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		
		
		}
		
		public void pickandShip() throws Exception {
		
		beginStep("[9] Shipping Transactions", 0);
		{
			forms.captureScreenshot(31);
			{
				delay(3000);
			}
			forms.textField(32,
					"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.list(33, "//forms:list[(@name='DLVB_BUTTONS_ACTIONS_0')]")
					.selectItem("Pick and Ship");
			{
				delay(3000);
			}
			forms.button(34, "//forms:button[(@name='DLVB_BUTTONS_GO_0')]")
					.click();
		}
		endStep();
		beginStep("[10] Messages", 0);
		{
			forms.captureScreenshot(36);
			{
				delay(3000);
			}
			forms.button(37, "//forms:button[(@name='MESSAGE_OK_0')]").click();
		}
		endStep();
		beginStep("[11] Shipping Transactions", 0);
		{
			forms.captureScreenshot(39);
			{
				delay(3000);;
			}
			forms.list(40, "//forms:list[(@name='DLVB_BUTTONS_ACTIONS_0')]")
					.setFocus();
			{
				delay(1000);
			}
			forms.window(41, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
					.close();
			{
				delay(3000);
			}
		}
		endStep();
		
		
		beginStep(
				"[12] Navigator - GCSS-MC Inventory / Supply Shipping & Receiving NCO",
				0);
		{
			forms.captureScreenshot(67);
			{
				delay(1000);
			}
			forms.treeList(68, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem("Shipping");
			{
				delay(3000);
			}
			forms.treeList(91, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.selectItem("Shipping");
			{
				delay(3000);
				
			}
			forms.treeList(114, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem("Shipping|Transactions");
			{
				delay(3000);
			}
			forms.treeList(137, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.selectItem("Shipping|Transactions");
		}
		endStep();
		beginStep("[13] Query Manager", 0);
		{
			forms.captureScreenshot(139);
			{
				delay(3000);
			}
			forms.textField(140,
					"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
					.setText("{{GLBL_Replacement,28381838}}");
			{
				delay(3000);
			}
			forms.textField(141,
					"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				delay(3000);
			}
			forms.button(142, "//forms:button[(@name='QUERY_MANAGER_FIND_0')]")
					.click();
		}
		endStep();
		beginStep("[14] Caution", 0);
		{
			forms.captureScreenshot(144);
			{
				delay(3000);
			}
			forms.choiceBox(145, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		beginStep("[15] Shipping Transactions", 0);
		{
			forms.captureScreenshot(147);
			{
				delay(3000);
			}
			forms.textField(148,
					"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.window(149, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
					.clickToolBarButton("Transact Move Order");
		}
		endStep();
		
	}
		
		public void transactMoveOrder() throws Exception {
		
		
		beginStep("[16] Transact Move Orders (MRA)", 0);
		{
			forms.captureScreenshot(151);
			{
				delay(3000);
			}
			forms.checkBox(152,
					"//forms:checkBox[(@name='TOLINES_BLK_SUBMIT_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.button(153,
					"//forms:button[(@name='TOLINES_CONTROL_OPEN_0')]").click();
			{
				delay(3000);
			}
			forms.button(154,
					"//forms:button[(@name='TOLINES_CONTROL_OPEN_0')]")
					.setFocus();
		
		endStep();
		
	/*	
		beginStep(
				"[17] Transact Move Order Line Allocations (MRA) - 474939206",
				0);
		{
			forms.captureScreenshot(156);
			{
				think(1.169);
			}
			forms.button(157, "//forms:button[(@name='CONTROL_DONE_0')]")
					.click();
		}
		endStep();
		beginStep("[18] Error", 0);
		{
			forms.captureScreenshot(159);
			{
				think(2.953);
			}
			forms.choiceBox(160, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		
		*/
		
		
		beginStep(
				"[19] Transact Move Order Line Allocations (MRA) - 474939206",
				0);
		{
			forms.captureScreenshot(162);
			{
				delay(3000);
			}
			forms.button(163,
					"//forms:button[(@name='CONTROL_LOT_SERIAL_BUTTON_0')]")
					.click();
			{
				delay(3000);
			}
		}
		endStep();
		
		/*
		
		beginStep("[20] Serial Entry (MRA)", 0);
		{
			forms.captureScreenshot(402);
			{
				think(12.492);
			}
			forms.textField(403,
					"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
					.setText("080203010");
			{
				think(0.514);
			}
			forms.textField(404,
					"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(0.004);
			}
			forms.statusBar(405, "//forms:statusBar").assertText(
					"FormsFT AutoValidation: Verify StatusBar text value",
					"FRM-40212: Invalid value for field FM_SERIAL_NUMBER.",
					MatchOption.Exact, 0);
			{
				think(3.417);
			}
			forms.textField(406,
					"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(0.006);
			}
			forms.statusBar(407, "//forms:statusBar").assertText(
					"FormsFT AutoValidation: Verify StatusBar text value",
					"FRM-40212: Invalid value for field FM_SERIAL_NUMBER.",
					MatchOption.Exact, 0);
			{
				think(9.125);
			}
			forms.button(408,
					"//forms:button[(@name='NAVIGATION_CONTROL_OK_0')]")
					.click();
			{
				think(0.36);
			}
			forms.statusBar(409, "//forms:statusBar").assertText(
					"FormsFT AutoValidation: Verify StatusBar text value",
					"FRM-40212: Invalid value for field FM_SERIAL_NUMBER.",
					MatchOption.Exact, 0);
			{
				think(2.698);
			}
			forms.window(410, "//forms:window[(@name='SERIAL_ENTRY')]")
					.activate(true);
			{
				think(0.578);
			}
			forms.alertDialog(411, "//forms:alertDialog").clickYes();
		}
		endStep();
		
		*/
		
		/*
		 
		 
		beginStep("[21] Forms", 0);
		{
			forms.captureScreenshot(413);
			{
				think(3.405);
			}
			forms.textField(414,
					"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
					.openDialog();
		}
		endStep();
		beginStep("[22] Serial Numbers", 0);
		{
			forms.captureScreenshot(416);
			{
				think(3.942);
			}
			forms.listOfValues(417, "//forms:listOfValues").clickCancel();
			{
				think(0.455);
			}
			forms.window(418, "//forms:window[(@name='SERIAL_ENTRY')]")
					.activate(true);
		}
		endStep();
		beginStep("[23] Serial Entry (MRA)", 0);
		{
			forms.captureScreenshot(420);
			{
				think(10.307);
			}
			forms.radioButton(421,
					"//forms:radioButton[(@name='SERIAL_CONTROL_SERIAL_FORMAT_INDIVIDUAL_0')]")
					.select();
			{
				think(0.149);
			}
			forms.statusBar(422, "//forms:statusBar").assertText(
					"FormsFT AutoValidation: Verify StatusBar text value",
					"FRM-40212: Invalid value for field FM_SERIAL_NUMBER.",
					MatchOption.Exact, 0);
			{
				think(26.204);
			}
			forms.textField(423,
					"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
					.setText("56018624");
			{
				think(0.702);
			}
			forms.button(424,
					"//forms:button[(@name='NAVIGATION_CONTROL_OK_0')]")
					.click();
			{
				think(0.367);
			}
			forms.statusBar(425, "//forms:statusBar").assertText(
					"FormsFT AutoValidation: Verify StatusBar text value",
					"FRM-40212: Invalid value for field FM_SERIAL_NUMBER.",
					MatchOption.Exact, 0);
			{
				think(1.893);
			}
			forms.window(426, "//forms:window[(@name='SERIAL_ENTRY')]")
					.activate(true);
			{
				think(0.394);
			}
			forms.alertDialog(427, "//forms:alertDialog").clickYes();
		}
		endStep();
		
		
		*/
		
		beginStep("[24] Forms", 0);
		{
			forms.captureScreenshot(429);
			{
				delay(3000);
			}
			forms.textField(430,
					"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
					.openDialog();
		}
		endStep();
		beginStep("[25] Serial Numbers (Working...)", 0);
		{
			forms.captureScreenshot(432);
			{
				delay(3000);
			}
			forms.listOfValues(53, "//forms:listOfValues").find("%"); 
			{
				think(2.0);
			}
			forms.listOfValues(54, "//forms:listOfValues").choose(1);
		}
		endStep();
		beginStep("[26] Serial Entry (MRA)", 0);
		{
			forms.captureScreenshot(436);
			{
				delay(3000);
			}
			forms.button(437,
					"//forms:button[(@name='NAVIGATION_CONTROL_OK_0')]")
					.click();
		}
		endStep();
		beginStep(
				"[27] Transact Move Order Line Allocations (MRA) - 474939206",
				0);
		{
			forms.captureScreenshot(439);
			{
				delay(3000);
			}
			forms.button(440, "//forms:button[(@name='CONTROL_DONE_0')]")
					.click();
			{
				delay(3000);
			}
			/*
			
			forms.statusBar(441, "//forms:statusBar")
					.assertText(
							"FormsFT AutoValidation: Verify StatusBar text value",
							"FRM-40400: Transaction complete: 2 records applied and saved.",
							MatchOption.Exact, 0);
			*/
			{
				think(25.747);
			}
			forms.alertDialog(442, "//forms:alertDialog").clickYes();
		}
		endStep();
		beginStep("[28] Forms", 0);
		{
			forms.captureScreenshot(444);
			{
				delay(3000);
			}
			forms.window(445, "//forms:window[(@name='TOLINES_WIN')]")
					.activate(true);
		}
		endStep();
		beginStep("[29] Transact Move Orders (MRA)", 0);
		{
			forms.captureScreenshot(447);
			{
				delay(3000);
			}
			forms.window(448, "//forms:window[(@name='TOLINES_WIN')]").close();
			{
				delay(3000);
			}
			forms.window(449, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
					.activate(true);
		}
		endStep();
		beginStep("[30] Shipping Transactions", 0);
		{
			forms.captureScreenshot(451);
			{
				delay(3000);
			}
			forms.textField(452,
					"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.textField(453,
					"//forms:textField[(@name='DLVB_RELEASED_STATUS_NAME_0')]")
					.click();
			{
				delay(3000);
			}
			forms.textField(454,
					"//forms:textField[(@name='DLVB_SOURCE_HEADER_NUMBER_0')]")
					.click();
			{
				delay(3000);
			}
			forms.textField(455,
					"//forms:textField[(@name='DLVB_SERIAL_NUMBER_0')]")
					.click();
			{
				delay(3000);
			}
			forms.window(456, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
					.close();
			{
				delay(3000);
			}
			forms.window(457, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
		}
		endStep();
	}
}
		
		
		public void confirmShipment() throws Exception {
		
		
		beginStep(
				"[31] Navigator - GCSS-MC Inventory / Supply Shipping & Receiving NCO",
				0);
		{
			forms.captureScreenshot(459);
			{
				delay(3000);
			}
			forms.treeList(460, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.selectItem("Shipping|Transactions");
		}
		endStep();
		beginStep("[32] Query Manager", 0);
		{
			forms.captureScreenshot(462);
			{
				delay(3000);
			}
			forms.textField(463,
					"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
					.setText("{{GLBL_Replacement,20391938}}");
			{
				delay(3000);
			}
			forms.textField(464,
					"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				delay(3000);
			}
			forms.button(465, "//forms:button[(@name='QUERY_MANAGER_FIND_0')]")
					.click();
		}
		endStep();
		beginStep("[33] Caution", 0);
		{
			forms.captureScreenshot(467);
			{
				delay(3000);
			}
			forms.choiceBox(468, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		beginStep("[34] Shipping Transactions", 0);
		{
			forms.captureScreenshot(470);
			{
				delay(3000);
			}
			forms.textField(471,
					"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.tab(472, "//forms:tab[(@name='ENTITIES_TABS')]").select(
					"Delivery");
			{
				delay(3000);
			}
			forms.textField(473, "//forms:textField[(@name='DLVY_NAME_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.button(474,
					"//forms:button[(@name='DLVY_BUTTONS_BUTTON5_0')]").click();
		}
		endStep();
		beginStep("[35] Error", 0);
		{
			forms.captureScreenshot(476);
			{
				delay(3000);
			}
			forms.choiceBox(477, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		beginStep("[36] Confirm Delivery", 0);
		{
			forms.captureScreenshot(479);
			{
				delay(3000);
			}
			forms.button(480, "//forms:button[(@name='SHIP_CONFIRM_OK_0')]")
					.click();
		}
		endStep();
		beginStep("[37] Messages", 0);
		{
			forms.captureScreenshot(482);
			{
				delay(3000);
			}
			forms.button(483, "//forms:button[(@name='MESSAGE_OK_0')]").click();
			{
				delay(3000);
			}
			forms.window(484, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
					.activate(true);
		}
		endStep();
		beginStep("[38] Shipping Transactions", 0);
		{
			forms.captureScreenshot(486);
			{
				delay(3000);
			}
			forms.textField(487, "//forms:textField[(@name='DLVY_NAME_0')]")
					.setFocus();
			{
				delay(3000);
			}
			forms.textField(488,
					"//forms:textField[(@name='DLVY_STATUS_NAME_0')]").click();
			{
				delay(3000);
			}
	}
}
		public void closeEBSBrowser() throws Exception {
		
			beginStep("[7] Forms", 0);
			{
				forms.captureScreenshot(27);
				{
					think(5.729);
				}
				forms.window(28, "//forms:window[(@name='NAVIGATOR')]").selectMenu(
						"File|Exit Oracle Applications");
			}
			endStep();
			beginStep("[8] Caution", 0);
			{
				forms.captureScreenshot(30);
				{
					think(2.102);
				}
				forms.choiceBox(31, "//forms:choiceBox").clickButton("OK");
			}
			endStep();
			{
				delay(3000);
			}

		}
		
		

	public void finish() throws Exception {
	}
}
