import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		
		getVariables().set("MyURL",
			"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		beginStep("[TC-08 & 09] Create Maintenance SR");
		{
			browser.launch();
			delay(6000);
			getScript("Create_Maintenance_SR").callFunction(
					"generateMaintenanceSR");
			delay(6000);
			browser.close();
			delay(6000);
			browser.launch();
			getScript("TS_09_Create_Databank").run(1);
			browser.close();
			delay(6000);
		}
		endStep();
		beginStep("[TC-10] Manual File Drop");
		{
			/*
			 * Manual Step			 * 
			 */
		}
		endStep();
		beginStep("[TC-11] Manual File Drop");
		{
			/*
			 * Manual Step			 * 
			 */
		}
		endStep();
		
		
		/* 
		 * run TC-12 debrief process, various reports, and pick, pack, and ship
		 */
		
		beginStep("[TC-12] Run Debrief Process");
		{
			
			browser.launch();
			delay(6000);
			getVariables().set("GLBL_ServiceRequestNumber",
					"{{GLBL_ServiceRequestNumber}}", Variables.Scope.GLOBAL);
			getScript("Main_TC_12").callFunction("debriefProcess");
			browser.close();
			if (false) {
				getScript("MMR_Report").callFunction("generateMMRReport");
			}
			browser.launch();
			delay(6000);
			getScript("TS_09Main_TC12Bricks")
					.callFunction("runConsolidatedAssetListingReport", "GCSS-MC Inventory / Supply Officer", "Consolidated Asset Listing (Spreadsheet)", "MMFAF7", "MMFAF7", "N", "Y");
			browser.close();
			delay(6000);
			browser.launch();
			delay(6000);
			getScript("TC_12_Enter_Receipt").callFunction(
					"processMultipleSDNReceipt");
			browser.close();
			browser.launch();
			delay(6000);
			getVariables().set("GLBL_Replacement",
					"{{GLBL_Replacement_SDN_1}}", Variables.Scope.GLOBAL);
			getScript("Main_TC12_PickPackShip").callFunction("pickPackShip");
			browser.close();
			delay(6000);
			getVariables().set("GLBL_Replacement",
					"{{GLBL_Replacement_SDN_2}}", Variables.Scope.GLOBAL);
			delay(6000);
						browser.launch();
			delay(6000);
			getScript("Main_TC12_PickPackShip").callFunction("pickPackShip");
			browser.close();
			delay(6000);
						
		}
		
		/* 
		 * end run TC-12 debrief process, various reports, and pick, pack, and ship
		 */
		
		
		
		endStep();
		
		
		
		beginStep("[TC-13] Run DASF");
		{
			browser.launch();
			delay(6000);
			getScript("DASF_Report").callFunction("executeDASFReport");
			browser.close();
				delay(6000);
		}
		endStep();
		beginStep("[TC-14] Run MPR");
		{
			browser.launch();
			delay(6000);
			getScript("Main_TC_14").callFunction("executeMPR");
			browser.close();
			delay(6000);
		}
		endStep();
		beginStep("[TC-15] Process Multiple SDN Receipt");
		{
			browser.launch();
			delay(6000);
			getScript("TS_09_Main_TC_15").callFunction(
					"processMultipleSDNReceipt");
			browser.close();
			delay(6000);
		}
		endStep();
		beginStep("[TC-16] Recieve Serial Numbers");
		{
		}
		endStep();
		beginStep("[TC-17] Debrief Labor & Material");
		{
			browser.launch();
			delay(6000);
			getScript("Main_TC_17_Task_Materials").callFunction(
					"debriefLaborandMaterials");
			browser.close();
			delay(6000);
			browser.launch();
			delay(6000);
			if (false) {
				getScript("MMR_Report").callFunction("generateMMRReport");
			}
			browser.close();
			delay(6000);
		}
		endStep();
		beginStep("[TC-18] View IB Configuration");
		{
			browser.launch();
			delay(6000);
			getVariables().set("GLBL_ServiceRequestNumber", "{{GLBL_ServiceRequestNumber}}",
					Variables.Scope.GLOBAL);
			getScript("Main_TC_18").callFunction(
					"processConfirmSerialExistsOnConfiguration");
			browser.close();
			delay(6000);
		}
		endStep();
		beginStep("[TC-19] Close Task(s) and SR");
		{
			browser.launch();
			delay(6000);
			getScript("TS_09_Update_Task_Operational_Status_TC_19").run(1);
			browser.close();
			delay(6000);
		}
		endStep();

	}
	
	
	public void calNavigation() throws Exception {
		browser.launch();
		getVariables().set("MyURL",
			"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		getScript("CACI_FunctLib_EBSFunctions").callFunction(
			"EBSCertificateLogin", "{{MyURL}}", "243");
			delay(3000);
			
		/*
		beginStep(
			"[1] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DavCMEll8rhMTVXCFQ02AJuBrrfdW7vTFoDP81J40jali26LmcqgtR%2FqqH76qaD3XEHVd6zT9w4mD%2Fcnw3s6287j7a4nGZFmYwQCTOp0RZz1AF52lNphj%2BN1SSuYIEtGlxDO7SrFv23JaliigkwAcXHJ2RiIMKoRzvEadIBSCFKeBoV0v1NH%2F (/obrareq.cgi)",
			0);
	{
		web.window(2, "/web:window[@index='0' or @title='about:blank']")
				.navigate(
						"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin");
		
		web.window(4,
				"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
				.waitForPage(null);
				web.button(
				5,
				"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
				.click();
	}
	
	endStep();
	
	
		/*
	beginStep("[2] Home (/OA.jsp)", 0);
	{
		
		web.window(6, "/web:window[@index='0' or @title='Home']")
				.waitForPage(null);
				
		{
			delay(12000);
		}
		web.element(
				9,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Help Desk Concurrent Manager' or @index='140']")
				.click();
	}
	endStep();
	beginStep("[3] Home (/OA.jsp)", 0);
	{
		/*
		web.window(10, "/web:window[@index='0' or @title='Home']")
				.waitForPage(null);
				
		{
			delay(8000);
		}
		web.element(
				13,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Run Requests' or @index='144']")
				.click();
	}
	endStep();
	beginStep("[4] Submit a New Request", 0);
	{
		forms.captureScreenshot(15);
		{
			delay(8000);
		}
		forms.button(16, "//forms:button[(@name='WHAT_TYPE_OK_0')]")
				.click();
	}
	endStep();
	*/	
	}

	public void finish() throws Exception {
	}
}
