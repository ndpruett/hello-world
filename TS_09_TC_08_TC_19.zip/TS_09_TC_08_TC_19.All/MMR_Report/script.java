import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.webdom.api.elements.DOMBrowser;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
			generateMMRReport();
		
	}
	
	public void generateMMRReport() throws Exception {
		
			browser.launch();
			DOMBrowser myBrowser = web.window("/web:window[@index='0' or @index='1']");
			myBrowser.maximize();
			getScript("CACI_FunctLib_EBSFunctions").callFunction(
				"EBSCertificateLogin", "{{MyURL}}", "243");
			delay(3000);
			userNavigation();
			generateMMRReport();
			getScript("ExportOBIEEFunction").callFunction("processExportPDF");
			closeOBIEEBrowser();
		
		
	}
	
	private void userNavigation() throws Exception { 
		
		try {
			
			/*
	
				beginStep(
						"[1] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DOwKSN%2FsEhqZOpU8dzBhrpHrTgTuPkPdhMSg4PENyCo9fFT3QtS1SawFHYp84Nv8BQ4GKjKzASwJF3yEydVMfYFERsZ4KAxDtVZ03bfqoLD2ehK9VPQAEHQoeJ%2FyUmaoKWS%2Bv03jfsEkyPkEq%2B4TWTb77IAlfBvksvmGgU4emjwePy5GqG1RG (/obrareq.cgi)",
						0);
				{
					web.window(2, "/web:window[@index='0' or @title='about:blank']")
							.navigate(
									"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin");
					//web.window(4,
					//		"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					//		.waitForPage(null);
					{
						delay(6000);
					}
					web.button(
							5,
							"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
							.click();
			*/
					{
						delay(12000);
					}
				
				endStep();
				beginStep("[2] Home (/OA.jsp)", 0);
				{
					//web.window(7, "/web:window[@index='0' or @title='Home']")
					//		.waitForPage(null);
					{
						delay(12000);
					}
					web.element(
							14,
							"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC OBIEE Reports User']")
							.click();
				}
				endStep();
				beginStep("[3] Home (/OA.jsp)", 0);
				{
				//	web.window(15, "/web:window[@index='0' or @title='Home']")
				//			.waitForPage(null);
					{
						delay(12000);
					}
					web.element(
							18,
							"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='OBIEE Dashboards & Reports' or @index='70']")
							.click();
				}
				endStep();
				beginStep(
						"[4] OracleOasis : Launch Discoverer or Web report (/RF.jsp)",
						0);
				{
					web.window(19, "/web:window[@index='1' or @title='OBIEE Launcher']")
							.waitForPage(null);
					{
						delay(3000);
					}
					web.link(
							21,
							"/web:window[@index='1' or @title='OBIEE Launcher']/web:document[@index='1']/web:a[@text='Open this content in a new window' or @href='javascript:makeNewWindow();' or @index='0']")
							.click();
				}
				endStep();
				} 
	
	catch(Exception e){
		info("userNavigation() : "+ e.getMessage());
		throw e;
	
		}
	} //private void userNavigation() throws Exception
		

		private void executeMMRReport() throws Exception {



		beginStep(
				"[9] Oracle BI Interactive Dashboards - Dashboard Index (/saw.dll)",
				0);
		{
			web.window(
					55,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']")
					.waitForPage(null);
			{
				think(1.178);
			}
			web.link(
					57,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']/web:document[@index='0']/web:a[@text='Parts Requested' or @href='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/saw.dll?Dashboard&PortalPath=/shared/Maintenance/GCSS-MC Service Requests/MMR&Page=Parts Requested' or @index='49']")
					.click();
		}
		endStep();
		beginStep(
				"[10] Oracle BI Interactive Dashboards - MMR (/MMR&Page=Parts Requested)",
				0);
		{
			web.window(58,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']")
					.waitForPage(null);
			{
				think(3.056);
			}
			web.image(
					60,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:img[@id='saw_7901_7_1_dropdownIcon' or @index='36' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/master/selectdropdown_ena.png']")
					.click();
			{
				think(2.38);
			}
			web.element(
					61,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:span[@text='More/Search...' or @index='68']")
					.click();
			{
				think(6.816);
			}
			web.textBox(
					62,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:input_text[@id='choiceListSearchString_D' or @name='choiceListSearchString' or @index='3']")
					.click();
			{
				think(0.558);
			}
			web.textBox(
					63,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:input_text[@id='choiceListSearchString_D' or @name='choiceListSearchString' or @index='3']")
					.setText("27630938");
			{
				think(1.595);
			}
			web.button(
					64,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:input_button[@id='searchButton' or @name='searchButton' or @value='Search' or @index='1']")
					.click();
			{
				think(1.836);
			}
			web.image(
					65,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:img[@id='idMoveAllButton' or @index='47' or @src='https://gcssmc-dv-obiee.dev.gcssmc.sde/analytics/res/v-1eK-3w21YHU/s_Alta/uicomponents/obips.Shuttle/shuttlerightall_dwn.png']")
					.click();
			{
				think(1.442);
			}
			web.link(
					66,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:a[@text='OK' or @href='javascript:void(0)' or @index='24']")
					.click();
			{
				think(8.288);
			}
			web.button(
					67,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:input_button[@id='idContinueButton' or @value='Continue' or @index='0']")
					.click();
		}
		endStep();
		
		} //private void executeMMRReport() throws Exception
		
		private void closeOBIEEBrowser() throws Exception {
		
		beginStep("[11] Oracle BI Interactive Dashboards - MMR (/saw.dll)", 0);
		{
			web.window(68,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']")
					.waitForPage(null);
			{
				think(41.945);
			}
			web.window(70,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']")
					.close();
			{
				think(2.063);
			}
			web.window(71, "/web:window[@index='1' or @title='OBIEE Launcher']")
					.close();
			{
				think(1.687);
			}
			web.image(
					72,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:img[@alt='Logout' or @index='12' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_MEDIA/signout.png']")
					.click();
		}
		endStep();

	} //private void closeOBIEEBrowser() throws Exception

	public void finish() throws Exception {
	}
}
