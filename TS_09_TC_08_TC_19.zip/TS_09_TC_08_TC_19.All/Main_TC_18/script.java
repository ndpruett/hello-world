import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		getVariables().set("MyURL",
//			"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
//			"https://gcssmc-ebs.cm.gcssmc.sde/OA_HTML/AppsLogin",
			"https://gcssmc-pt-ebs.int.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		
		getVariables().set("GLBL_SerialNumber", "{{GLBL_SerialNumber}}", Variables.Scope.GLOBAL);

		browser.launch();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		processConfirmSerialExistsOnConfiguration();
		
	} // public void run() throws Exception 
	
	public void processConfirmSerialExistsOnConfiguration() throws Exception {
		try
		{
			getVariables().set("MyUser", "236", Variables.Scope.GLOBAL);
			getVariables().set("Search_Serial_Number","{{GLBL_SerialNumber}}", Variables.Scope.GLOBAL);
			getVariables().set("GLBL_Prefix_AORO_File_Name","10", Variables.Scope.GLOBAL);

			getScript("NavigateItemDetail").callFunction("confirmSerialNumberExistsOnConfiguration");
	
		}
		catch (Exception e) {
			info("processConfirmSerialExistsOnConfiguration() " + e.getMessage());
			throw e;
		}
		
	} // private void processMPR()
	

	public void finish() throws Exception {
	}
	
	public void closeBrowserGCSSMC() throws Exception {
		browser.close();
	}
	
}
