import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.webdom.api.elements.DOMBrowser;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
		getVariables().set("MyURL",
				"https://gcssmc-ebs.cm.gcssmc.sde/OA_HTML/AppsLogin",
				Variables.Scope.GLOBAL);
		
		
	} //public void initialize() throws Exception

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	
	public void run() throws Exception {
				
				generateMaintenanceSR();

	} //public void run() throws Exception
	
	public void generateMaintenanceSR() throws Exception {
		
				

				browser.launch();
				DOMBrowser myBrowser = web.window("/web:window[@index='0' or @index='1']");
				myBrowser.maximize();
				getScript("CACI_FunctLib_EBSFunctions").callFunction(
				"EBSCertificateLogin", "{{MyURL}}", "243");
				delay(3000);
				userNavigation();
				getDatabank("MAIN_TC_09_Parts_Data").getNextDatabankRecord();
				createMaintenaceSR();
				delay(4000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "01_Created_Maintenance_SR");
				delay(6000);
				createTaskSecrep();
				delay(4000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "02_SECREP_Task_Created");
				delay(6000);
				createTaskConsumables();
				delay(4000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "03_Consumables_Task_Created");
				delay(6000);
				partNav();
				addPart();
				delay(4000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "04_Parts_Created");
				delay(6000);
				createOrder();
				delay(4000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "05_Part_Order_Created");
				delay(6000);
				collectSdnInformation();
				delay(4000);
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot",
						"False", "True", "06_SDN_Information_Created");
				delay(6000);
				closeEBSBrowser();
				delay(3000);
				browser.close();
				
		
		
	} //public void generateMaintenanceSR() throws Exception
	
	
	private void userNavigation() throws Exception {
		
		/*
		
				beginStep(
					"[1] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DDhv8maFnlOdg0KOYHdhSZYn3yqJjfx68OOV%2FX3EnMc3FM9umZOs%2B2UTR3VyNPgXkf7KoiF3tKnB6Rx65c7kQLfO3Fn75ck9mQudRxVB9b7zGc1fAorKvCUHXNKR1jWHAlGRnYfSmQyDgIkh0JvHiZMsOs3FavXFsEuvBPZC9fwsSGQfpbajMvIkr (/obrareq.cgi)",
					0);
			{
				web.window(11, "/web:window[@index='0' or @title='about:blank']")
						.navigate(
								"{{MyURL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}");
				web.window(12,
						"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
						.waitForPage(null);
				{
					delay(8000);
				}
				web.button(
						13,
						"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
						.click();
			}
			endStep();
			
			
		*/
		
			beginStep("[2] Select User Responsibility", 0);
			{
				//web.window(14, "/web:window[@index='0' or @title='Home']")
				//		.waitForPage(null);
				{
					delay(8000);
				}
				web.element(
						17,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Maintenance Chief' or @index='170']")
						.click();
			}
			endStep();
			beginStep("[3] Select User Role", 0);
			{
				web.window(18, "/web:window[@index='0' or @title='Home']")
						.waitForPage(null);
				{
					delay(8000);
				}
				web.element(
						21,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Request' or @index='190']")
						.click();
			}
			endStep();
			beginStep("[4] Select User Role - 2", 0);
			{
				web.window(22, "/web:window[@index='0' or @title='Home']")
						.waitForPage(null);
				{
					delay(8000);
				}
				web.element(
						25,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Requests' or @index='194']")
						.click();
			}
			endStep();
			beginStep("[5] Select User Role - 3", 0);
			{
				web.window(26, "/web:window[@index='0' or @title='Home']")
						.waitForPage(null);
				{
					delay(8000);
				}
				web.element(
						29,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Create Service Requests' or @index='196']")
						.click();
			}
			endStep();
	} //private void userNavigation() throws Exception
	
	private void createMaintenaceSR() throws Exception {
		
				
				beginStep("[6] Set Incident Tracking Type", 0);
			{
				forms.captureScreenshot(31);
				{
					delay(4000);
				}
				forms.textField(32,
						"//forms:textField[(@name='INCIDENT_TRACKING_INCIDENT_TYPE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[7] Set Service Request Type", 0);
			{
				forms.captureScreenshot(34);
				{
					delay(4000);
				}
				forms.listOfValues(35, "//forms:listOfValues").find(
						"%Maintenance - CM%");
			}
			endStep();
			beginStep("[8] Select Incident Tracking Account", 0);
			{
				forms.captureScreenshot(37);
				{
					delay(4000);
				}
				forms.textField(38,
						"//forms:textField[(@name='INCIDENT_TRACKING_ACCOUNT_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[9] Set Customer Account", 0);
			{
				forms.captureScreenshot(40);
				{
					delay(4000);
				}
				forms.listOfValues(41, "//forms:listOfValues").find("%UIC-M29030%");
				{
					delay(4000);
				}
				forms.listOfValues(42, "//forms:listOfValues")
						.select("UIC-M29030|M29030 CLB 4 CLR 3 3D MLG|M29030 CLB 4 CLR 3 3D MLG||2602||P1-UNIT 38404;TOECR Change Required|FPO|AP|US||966048404");
			}
			endStep();
			beginStep("[10] Select Incident Severity", 0);
			{
				forms.captureScreenshot(44);
				{
					delay(4000);
				}
				forms.textField(45,
						"//forms:textField[(@name='INCIDENT_TRACKING_SEVERITY_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[11] Set Incident Severity", 0);
			{
				forms.captureScreenshot(47);
				{
					delay(4000);
				}
				forms.listOfValues(48, "//forms:listOfValues")
						.find("%05 B-Urgent%");
			}
			endStep();
			beginStep("[12] Select Group Owner", 0);
			{
				forms.captureScreenshot(50);
				{
					delay(4000);
				}
				forms.textField(51,
						"//forms:textField[(@name='INCIDENT_TRACKING_GROUP_OWNER_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[13] Set Group Owner", 0);
			{
				forms.captureScreenshot(53);
				{
					delay(4000);
				}
				forms.listOfValues(54, "//forms:listOfValues").find("%AAC-M29030%");
				{
					delay(4000);
				}
				forms.listOfValues(55, "//forms:listOfValues").select(
						"AAC-M29030|M29030 CLB 4 CLR 3 3D MLG (R/U)|118");
			}
			endStep();
			beginStep("[14] Select NIIN", 0);
			{
				forms.captureScreenshot(57);
				{
					delay(4000);
				}
				forms.textField(58,
						"//forms:textField[(@name='INCIDENT_TRACKING_PRODUCT_NAME_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[15] Set NIIN", 0);
			{
				forms.captureScreenshot(60);
				{
					delay(4000);
				}
				forms.flexWindow(61, "//forms:flexWindow").setTextAndClickOk(
						"ITEM", "", "015305676");
				{
					delay(4000);
				}
			}
			endStep();
			beginStep("[6] Select Serial Number", 0);
			{
				forms.captureScreenshot(23);
				{
					delay(4000);
				}
				forms.textField(24,
						"//forms:textField[(@name='INCIDENT_TRACKING_CURRENT_SERIAL_NUMBER_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[7] Set Serial Number", 0);
			{
				forms.captureScreenshot(26);
				{
					delay(4000);
				}
				forms.listOfValues(27, "//forms:listOfValues").find("%BJD020%");
				{
					delay(4000);
				}
				forms.listOfValues(46, "//forms:listOfValues")
						.select("BJD020|015305676|TRUCK,ARMORED,CARGO|4774800||||D00037K|I|Latest|M2903072230001|10097552||P1-UNIT 38404;TOECR Change Required|FPO|USMC|AP||966048404|US|M29030 CLB 4 CLR 3 3D MLG||2602||P1-UNIT 38404;TOECR Change Required|FPO|AP|US||966048404|ORGANIZATION");
				{
					delay(4000);
				}
			}
			endStep();
			beginStep("[18] Set Incident Tracking Summary", 0);
			{
				forms.captureScreenshot(88);
				{
					delay(4000);
				}
				forms.textField(89,
						"//forms:textField[(@name='INCIDENT_TRACKING_SUMMARY_0')]")
						.setText("Create Maintenance SR");
				{
					delay(4000);
				}
				forms.textField(90,
						"//forms:textField[(@name='INCIDENT_TRACKING_URGENCY_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[19] Set Request Urgency", 0);
			{
				forms.captureScreenshot(92);
				{
					delay(4000);
				}
				forms.listOfValues(93, "//forms:listOfValues").find("%Deadlined%");
			}
			endStep();
			beginStep("[20] Save SR", 0);
			{
				forms.captureScreenshot(95);
				{
					delay(4000);
				}
				forms.textField(96,
						"//forms:textField[(@name='INCIDENT_TRACKING_EXTERNAL_REFERENCE_0')]")
						.setFocus();
				{
					delay(4000);
				}
				forms.window(97,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.clickToolBarButton("Save");
				{
					delay(4000);
				}
				//forms.statusBar(98, "//forms:statusBar")
				//		.assertText(
				//				"FormsFT AutoValidation: Verify StatusBar text value",
				//				"FRM-40400: Transaction complete: 1 records applied and saved.",
				//				MatchOption.Exact, 0);
				
				{
					delay(4000);
				}
				forms.textField(99,
						"//forms:textField[(@name='INCIDENT_TRACKING_INCIDENT_NUMBER_0')]")
						.setFocus();
				{
					delay(4000);
				}
				forms.textField(100,
						"//forms:textField[(@name='INCIDENT_TRACKING_STATUS_CODE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[21] Update Status to Equip Accepted", 0);
			{
				forms.captureScreenshot(102);
				{
					delay(4000);
				}
				forms.listOfValues(103, "//forms:listOfValues").find(
						"%Equip Accepted%");
			}
			endStep();
			beginStep(
					"[22] Save Updated SR", 0);
			{
				forms.captureScreenshot(105);
				{
					delay(4000);
				}
				forms.window(106,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.clickToolBarButton("Save");
				{
					delay(2000);
				}
			//	forms.statusBar(107, "//forms:statusBar")
			//			.assertText(
			//					"FormsFT AutoValidation: Verify StatusBar text value",
			//					"FRM-40400: Transaction complete: 1 records applied and saved.",
			//					MatchOption.Exact, 0);
			}
			endStep();
	
} //private void createMaintenaceSR() throws Exception
	
	private void createTaskSecrep() throws Exception {
				
			beginStep(
					"[7] Select Task Window", 0);
			{
				forms.captureScreenshot(216);
				{
					delay(4000);
				}
				forms.tab(217, "//forms:tab[(@name='SR_CANVASES')]")
						.select("Tasks");
				{
					delay(4000);
				}
				forms.textField(218,
						"//forms:textField[(@name='CREATE_TASK_TASK_TYPE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[8] Set Task Type", 0);
			{
				forms.captureScreenshot(220);
				{
					delay(4000);
				}
				forms.listOfValues(221, "//forms:listOfValues").find(
						"%Maintenance%");
				{
					delay(4000);
				}
				forms.listOfValues(222, "//forms:listOfValues").select(
						"Maintenance");
			}
			endStep();
			beginStep(
					"[9] Select Task Priority", 0);
			{
				forms.captureScreenshot(224);
				{
					delay(4000);
				}
				forms.textField(225,
						"//forms:textField[(@name='CREATE_TASK_TASK_PRIORITY_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[10] Set Task Priority", 0);
			{
				forms.captureScreenshot(227);
				{
					delay(4000);
				}
				forms.listOfValues(228, "//forms:listOfValues").find(
						"%05 B-Urgent%");
			}
			endStep();
			beginStep(
					"[11] Select Task Owner", 0);
			{
				forms.captureScreenshot(230);
				{
					delay(4000);
				}
				forms.textField(231,
						"//forms:textField[(@name='CREATE_TASK_OWNER_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[12] Set Task Owner", 0);
			{
				forms.captureScreenshot(233);
				{
					delay(4000);
				}
				forms.listOfValues(234, "//forms:listOfValues")
						.find("%AAC-M29030%");
				{
					delay(4000);
				}
				forms.listOfValues(235, "//forms:listOfValues").select(
						"AAC-M29030|M29030 CLB 4 CLR 3 3D MLG (R/U)|118|");
			}
			endStep();
			beginStep(
					"[13] Select Assignee Type", 0);
			{
				forms.captureScreenshot(237);
				{
					delay(4000);
				}
				forms.textField(238,
						"//forms:textField[(@name='CREATE_TASK_ASSIGNEE_TYPE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[14] Set Assignee Type", 0);
			{
				forms.captureScreenshot(240);
				{
					delay(4000);
				}
				forms.listOfValues(241, "//forms:listOfValues").find(
						"%Employee Resource%");
			}
			endStep();
			beginStep(
					"[15] Select Assignee Name", 0);
			{
				forms.captureScreenshot(243);
				{
					delay(4000);
				}
				forms.textField(244,
						"//forms:textField[(@name='CREATE_TASK_ASSIGNEE_NAME_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[16] Set Assignee Name", 0);
			{
				forms.captureScreenshot(246);
				{
					delay(4000);
				}
				forms.listOfValues(247, "//forms:listOfValues").find("%TEST236%");
				{
					delay(4000);
				}
				forms.listOfValues(248, "//forms:listOfValues").select(
						"TEST236, GySgt GCSSMC A|336232|||");
			}
			endStep();
			beginStep(
					"[17] Input Task Summary", 0);
			{
				forms.captureScreenshot(250);
				{
					delay(4000);
				}
				forms.textField(251,
						"//forms:textField[(@name='CREATE_TASK_TASK_NAME_0')]")
						.setText("For Floating SECREP");
				{
					delay(4000);
				}
				forms.textField(252,
						"//forms:textField[(@name='CREATE_TASK_PLANNED_EFFORT_0')]")
						.setText("2");
				{
					delay(4000);
				}
				forms.list(253,
						"//forms:list[(@name='CREATE_TASK_PLANNED_EFFORT_UOM_0')]")
						.selectItem("Hour");
				{
					delay(4000);
				}
				forms.textField(254,
						"//forms:textField[(@name='CREATE_TASK_DURATION_0')]")
						.setText("2");
				{
					delay(4000);
				}
				forms.list(255,
						"//forms:list[(@name='CREATE_TASK_DURATION_UOM_0')]")
						.selectItem("Week");
				{
					delay(4000);
				}
				forms.textField(256,
						"//forms:textField[(@name='CREATE_TASK_DESC_FLEX_0')]")
						.setFocus();
								
			}
			endStep();
			beginStep("[18] Select Operational Status", 0);
			{
				forms.captureScreenshot(258);
				{
					delay(4000);
				}
				forms.flexWindow(259, "//forms:flexWindow").openDialog(
						"Operational Status", "");
			}
			endStep();
			beginStep("[19] Set Operational Status", 0);
			{
				forms.captureScreenshot(261);
				{
					delay(4000);
				}
				forms.listOfValues(262, "//forms:listOfValues").find("%Deadlined%");
			}
			endStep();
			beginStep("[20] View Task Information", 0);
			{
				forms.captureScreenshot(264);
				{
					delay(4000);
				}
				forms.flexWindow(265, "//forms:flexWindow").clickOk();
			}
			endStep();
			beginStep(
					"[21] Save SECREP Task", 0);
			{
				forms.captureScreenshot(267);
				{
					delay(4000);
				}
				forms.window(268,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.clickToolBarButton("Save");
				{
					delay(4000);
				}
			//	forms.statusBar(269, "//forms:statusBar")
			//			.assertText(
			//					"FormsFT AutoValidation: Verify StatusBar text value",
			//					"FRM-40400: Transaction complete: 2 records applied and saved.",
			//					MatchOption.Exact, 0);
			}
			endStep();
	} //private void createTaskSecrep() throws Exception
	
	
	private void createTaskConsumables() throws Exception {
		
				beginStep(
					"[9] Select Task Window", 0);
			{
				forms.captureScreenshot(37);
				{
					delay(4000);
				}
				forms.tab(38, "//forms:tab[(@name='SR_CANVASES')]").select("Tasks");
				{
					delay(4000);
				}
				forms.spreadTable(39,
						"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
						.focusRow(1);
				{
					delay(4000);
				}
				forms.spreadTable(40,
						"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
						.focusRow(1);
				{
					delay(4000);
				}
				
				
				//.invokeSoftKey("DOWN"); is required for creating new TASK with one present
				// for each new task after the initial assignment, use this and focus tab TASK to create new task
				
						forms.textField(41,
								"//forms:textField[(@name='CREATE_TASK_TASK_TYPE_0')]")
								.invokeSoftKey("DOWN");
						{
							delay(4000);
						}
				//end required .invokeSoftkey("DOWN");
				//end comment
						
						
				forms.window(43,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.activate(true);
				{
					delay(2000);
				}
			}
			endStep();
			beginStep("[10] Set Task Type", 0);
			{
				forms.captureScreenshot(46);
				{
					delay(4000);
				}
				forms.textField(47,
						"//forms:textField[(@name='CREATE_TASK_TASK_TYPE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[11] Select Task Priority", 0);
			{
				forms.captureScreenshot(49);
				{
					delay(4000);
				}
				forms.listOfValues(50, "//forms:listOfValues")
						.find("%Maintenance%");
				{
					delay(2000);
				}
				forms.listOfValues(51, "//forms:listOfValues").select(
						"Maintenance|");
				{
					delay(4000);
				}
			}
			endStep();
			beginStep(
					"[12] Set Task Priority", 0);
			{
				forms.captureScreenshot(396);
				{
					delay(2000);
				}
				forms.textField(397,
						"//forms:textField[(@name='CREATE_TASK_TASK_PRIORITY_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[13] Set Task Priority", 0);
			{
				forms.captureScreenshot(399);
				{
					delay(4000);
				}
				forms.listOfValues(400, "//forms:listOfValues").find(
						"%05 B-Urgent%");
			}
			endStep();
			beginStep(
					"[14] Select Task Owner Type", 0);
			{
				forms.captureScreenshot(402);
				{
					delay(4000);
				}
				forms.textField(403,
						"//forms:textField[(@name='CREATE_TASK_OWNER_TYPE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[15] Set Task Owner Type", 0);
			{
				forms.captureScreenshot(405);
				{
					delay(4000);
				}
				forms.listOfValues(406, "//forms:listOfValues").find(
						"%Group Resource%");
			}
			endStep();
			beginStep(
					"[16] Select Task Owner", 0);
			{
				forms.captureScreenshot(408);
				{
					delay(4000);
				}
				forms.textField(409,
						"//forms:textField[(@name='CREATE_TASK_OWNER_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[17] Set Task Owner", 0);
			{
				forms.captureScreenshot(411);
				{
					delay(4000);
				}
				forms.listOfValues(412, "//forms:listOfValues")
						.find("%AAC-M29030%");
				{
					delay(2000);
				}
				forms.listOfValues(413, "//forms:listOfValues").select(
						"AAC-M29030|M29030 CLB 4 CLR 3 3D MLG (R/U)|118|");
			}
			endStep();
			beginStep(
					"[18] Select Task Assignee Type", 0);
			{
				forms.captureScreenshot(415);
				{
					delay(4000);
				}
				forms.textField(416,
						"//forms:textField[(@name='CREATE_TASK_ASSIGNEE_TYPE_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[19] Set Task Assignee Type", 0);
			{
				forms.captureScreenshot(418);
				{
					delay(4000);
				}
				forms.listOfValues(419, "//forms:listOfValues").find(
						"%Employee Resource%");
			}
			endStep();
			beginStep(
					"[20] Select Task Assignee Name", 0);
			{
				forms.captureScreenshot(421);
				{
					delay(4000);
				}
				forms.textField(422,
						"//forms:textField[(@name='CREATE_TASK_ASSIGNEE_NAME_0')]")
						.openDialog();
			}
			endStep();
			beginStep("[21] Set Task Assignee Name", 0);
			{
				forms.captureScreenshot(424);
				{
					delay(4000);
				}
				forms.listOfValues(425, "//forms:listOfValues").find("%TEST236%");
				{
					delay(4000);
				}
				forms.listOfValues(426, "//forms:listOfValues").select(
						"TEST236, GySgt GCSSMC A|336232|||");
			}
			endStep();
			beginStep(
					"[22] Input Effort Duration", 0);
			{
				forms.captureScreenshot(428);
				{
					delay(4000);
				}
				forms.textField(429,
						"//forms:textField[(@name='CREATE_TASK_TASK_NAME_0')]")
						.setText("For Ordering Consumables");
				{
					delay(4000);
				}
				forms.textField(430,
						"//forms:textField[(@name='CREATE_TASK_PLANNED_EFFORT_0')]")
						.setText("2");
				{
					delay(4000);
				}
				forms.list(431,
						"//forms:list[(@name='CREATE_TASK_PLANNED_EFFORT_UOM_0')]")
						.selectItem("Hour");
				{
					delay(4000);
				}
				forms.textField(432,
						"//forms:textField[(@name='CREATE_TASK_DURATION_0')]")
						.setText("2");
				{
					delay(4000);
				}
				forms.list(433,
						"//forms:list[(@name='CREATE_TASK_DURATION_UOM_0')]")
						.selectItem("Month");
				{
					delay(4000);
				}
				forms.textField(434,
						"//forms:textField[(@name='CREATE_TASK_DESC_FLEX_0')]")
						.setFocus();
			}
			endStep();
			beginStep("[23] Tasks additional information", 0);
			{
				forms.captureScreenshot(436);
				{
					delay(4000);
				}
				forms.flexWindow(437, "//forms:flexWindow").openDialog(
						"Operational Status", "");
			}
			endStep();
			beginStep("[24] Set Operational Status", 0);
			{
				forms.captureScreenshot(439);
				{
					delay(4000);
				}
				forms.listOfValues(440, "//forms:listOfValues").find(
						"%Operational - Degraded%");
			}
			endStep();
			beginStep("[25] Verify Task Information", 0);
			{
				forms.captureScreenshot(442);
				{
					delay(4000);
				}
				forms.flexWindow(443, "//forms:flexWindow").clickOk();
			}
			endStep();
			beginStep(
					"[26] Save Task", 0);
			{
				forms.captureScreenshot(445);
				{
					delay(4000);
				}
				forms.window(446,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.clickToolBarButton("Save");
				{
					delay(2000);
				}
			//	forms.statusBar(447, "//forms:statusBar")
			//			.assertText(
			//					"FormsFT AutoValidation: Verify StatusBar text value",
			//					"FRM-40400: Transaction complete: 1 records applied and saved.",
			//					MatchOption.Exact, 0);
				{
					delay(2000);
				}
				forms.spreadTable(448,
						"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
						.focusRow(2);
			}
			
			endStep();
			
		
	} //private void createTaskConsumables() throws Exception
	
	

	public void addPart() throws Exception {
		
		
			addSinglePart();
		
	}
	
	
	
	private void partNav() throws Exception {
		
		
		beginStep("[1] Select Consumable, Add Part Navigation", 0);
		{
			forms.spreadTable(53,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.setFocus();
			{
				think(0.109);
			}
			forms.spreadTable(58,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(2);
			{
				think(16.786);
			}
			forms.window(59,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Parts Requirements");
		}
		endStep();
			
		}
		
			
			
		public void addSinglePart() throws Exception {
			
			//getDatabank("MAIN_TC_09_Parts_Data").getNextDatabankRecord();
			
			//Datafile recordcount
			int recordCount = getDatabank("MAIN_TC_09_Parts_Data").getDatabankRecordCount();
			int partsRowCount = 0; //variable used to traverse through Parts Requirements table
			
			
			for (int i=1; i<=recordCount; i++)
			{
				//input data record increment
				getDatabank("MAIN_TC_09_Parts_Data").getRecord(i);
			
			beginStep("[2] Add Part", 0);
			{
				forms.captureScreenshot(61);
				{
					delay(4000);
				}
				forms.textField(62,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_ORGANIZATION_"+ partsRowCount +"')]")
						.setFocus();
				{
					delay(3000);
				}
			//	forms.button(63,
			//			"//forms:button[(@name='CONTROL_BTN_FIND_PARTS_"+ partsRowCount +"')]")
			//			.setFocus();
				{
					delay(3000);
				}
				forms.textField(64,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_ORGANIZATION_"+ partsRowCount +"')]")
						.setFocus();
				{
					delay(3000);
				}
				forms.textField(65,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_ORGANIZATION_"+ partsRowCount +"')]")
						.setText("1CJ");
				{
					delay(2000);
				}
				forms.textField(66,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_ORGANIZATION_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(67,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_SUBINVENTORY_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(68,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_INVENTORY_ITEM_"+ partsRowCount +"')]")
						.setText("{{db.MAIN_TC_09_Parts_Data.NIIN,015179793}}");
				{
					delay(2000);
				}
				forms.textField(69,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_INVENTORY_ITEM_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(70,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_REQUIRED_QUANTITY_"+ partsRowCount +"')]")
						.setText("{{db.MAIN_TC_09_Parts_Data.Quantity,10}}");
				{
					delay(2000);
				}
				forms.textField(71,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_REQUIRED_QUANTITY_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(72,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE3_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(73,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE7_"+ partsRowCount +"')]")
						.setText("{{db.MAIN_TC_09_Parts_Data.SIGCD,D}}");
				{
					delay(2000);
				}
				forms.textField(74,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE7_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(75,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE4_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(77,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE2_"+ partsRowCount +"')]")
						.setText("AAC-MMR100");
				{
					delay(2000);
				}
				forms.textField(78,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE2_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(79,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE9_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);;
				}
				forms.textField(80,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE11_"+ partsRowCount +"')]")
						.setText("{{db.MAIN_TC_09_Parts_Data.RDD,198}}");
				{
					delay(2000);
				}
				forms.textField(81,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE11_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(82,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE10_"+ partsRowCount +"')]")
						.invokeSoftKey("NEXT_FIELD");
				{
					delay(2000);
				}
				forms.textField(83,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE5_"+ partsRowCount +"')]")
						.openDialog();
				{
					delay(2000);
				}
				forms.window(84, "//forms:window[(@name='MAIN_WIN')]").activate(
						true);
				{
					delay(2000);
				}
				forms.listOfValues(85, "//forms:listOfValues").select(
						"{{db.MAIN_TC_09_Parts_Data.JON,LV2121:PE:SP:2604:PPLH:^^^:^^^^:^^^^^^^^^^^^^^^:^}}");
				//} // if ("//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE5_"+ partsRowCount +"')]").isEmpty()
				
				partsRowCount = partsRowCount + 1;
				
				//below validation to check if we need to create another row on the screen.  The increment has to be done before, because the table starts with "0" and the DataBank record starts with "1"
				if (partsRowCount != recordCount)
				{
					forms.textField(521,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE5_"+ partsRowCount +"')]")
						.invokeSoftKey("DOWN");	
					{
						think(3.000);
					}
			}
			endStep();
			}
		}
			
}
			
			private void createOrder() throws Exception {
				
				
				
				beginStep("[8] Create and Submit Order", 0);
				{
					think(13.467);
					forms.checkBox(1091,
							"//forms:checkBox[(@name='CSP_REQUIREMENT_LINES_CREATE_ORDER_CHECKBOX_0')]")
							.setFocus();
					{
						delay(2000);
					}
					forms.checkBox(1092,
							"//forms:checkBox[(@name='CONTROL_CHECK_ALL_0')]").check(
							true);
					{
						delay(2000);
					}
					forms.checkBox(1093,
							"//forms:checkBox[(@name='CSP_REQUIREMENT_LINES_CREATE_ORDER_CHECKBOX_0')]")
							.setFocus();
					{
						delay(2000);
					}
					forms.button(1094, "//forms:button[(@name='CONTROL_ORDER_0')]")
							.click();
				}
				
				endStep();
				
				
	}
			public void collectSdnInformation() throws Exception {
				delay(2000);
				{
					delay(3000);
					forms.choiceBox(89, "//forms:choiceBox").clickButton("OK");
				}
				delay(4000);
				forms.tab(92, "//forms:tab[(@name='LINES_CNVS')]").select(
				"Document");
		{
			delay(5000);
		}
		forms.textField(93,
				"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ITEM_DESC_ORD_0')]")
				.setFocus();
		{
			delay(5000);
		}
		{
			forms.textField(
			"//forms:textField[(@name='CSP_REQUIREMENT_HEADERS_SERVICE_REQUEST_0')]")
			.setFocus();		
		}
		{
			forms.textField(
			"//forms:textField[(@name='CSP_REQUIREMENT_HEADERS_SERVICE_REQUEST_0')]")
			.storeAttribute("GLBL_ServiceRequestNumber", "text");
			info("GLBL_ServiceRequestNumber is {{GLBL_ServiceRequestNumber}}");
			
		}
		{
			delay(5000);
		}
		forms.textField(94,
				"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_0')]")
				.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_0')]")
		.storeAttribute("GLBL_SDN0", "text");
		info("SDN 0 is {{GLBL_SDN0}}");
		{
			delay(5000);
		}
		forms.textField(94,
				"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_1')]")
				.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_1')]")
		.storeAttribute("GLBL_SDN1", "text");
		info("SDN 1 is {{GLBL_SDN1}}");
		{
			delay(5000);
		}
		forms.textField(94,
				"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_2')]")
				.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_2')]")
		.storeAttribute("GLBL_SDN2", "text");
		info("SDN 2 is {{GLBL_SDN2}}");
		{
			delay(5000);
		}
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_3')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_3')]")
		.storeAttribute("GLBL_SDN3", "text");
		info("SDN 3 is {{GLBL_SDN3}}");
		{
			delay(5000);
		}	
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_4')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_4')]")
		.storeAttribute("GLBL_SDN4", "text");
		info("SDN 4 is {{GLBL_SDN4}}");
		{
			delay(5000);
		}	
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_5')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_5')]")
		.storeAttribute("GLBL_SDN5", "text");
		info("SDN 5 is {{GLBL_SDN5}}");
		{
			delay(5000);
		}	
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_6')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_6')]")
		.storeAttribute("GLBL_SDN6", "text");
		info("SDN 6 is {{GLBL_SDN6}}");
		{
			delay(5000);
		}	
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_7')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_7')]")
		.storeAttribute("GLBL_SDN7", "text");
		info("SDN 7 is {{GLBL_SDN7}}");
		{
			delay(5000);
		}	
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_8')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_8')]")
		.storeAttribute("GLBL_SDN8", "text");
		info("SDN 8 is {{GLBL_SDN8}}");
		{
			delay(5000);
		}	
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_9')]")
		.setFocus();
		forms.textField(94,
		"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SDN_9')]")
		.storeAttribute("GLBL_SDN9", "text");
		info("SDN 9 is {{GLBL_SDN9}}");
		{
			delay(5000);
		}	
			}

		private void closeEBSBrowser() throws Exception {
			
			beginStep("[6] Close EBS Form(s)", 0);
			{
				forms.window(24,
						"//forms:window")
						.selectMenu("File|Exit Oracle Applications");
			}
			endStep();
			beginStep("[7] Close Browser", 0);
			{
				forms.choiceBox(27, "//forms:choiceBox").clickButton("OK");
				{
					think(13.013);
				}
				web.image(
						28,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:img[@alt='Logout' or @index='14' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_MEDIA/signout.png']")
						.click();
			}
			endStep();	
				
}
	
			
			/*
			
			beginStep("[3] JON", 0);
			{
				forms.captureScreenshot(87);
				{
					think(15.418);
				}
				
				
			
			
				
				
				forms.textField(88,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE5_0')]")
						.invokeSoftKey("DOWN");
				{
					think(6.215);
				}
				forms.textField(89,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_ORGANIZATION_1')]")
						.setFocus();
				{
					think(4.09);
					think(5.176);
				}
				forms.textField(310,
						"//forms:textField[(@name='CSP_REQUIREMENT_LINES_SOURCE_SUBINVENTORY_1')]")
						.setFocus();
				{
					think(3.388);
				}
				forms.checkBox(311,
						"//forms:checkBox[(@name='CONTROL_CHECK_ALL_0')]").check(
						true);
				{
					think(2.038);
				}
				forms.statusBar(312, "//forms:statusBar").assertText(
						"FormsFT AutoValidation: Verify StatusBar text value",
						"FRM-40202: Field must be entered.", MatchOption.Exact, 0);
				{
					think(7.158);
				}
				forms.checkBox(313,
						"//forms:checkBox[(@name='CONTROL_CHECK_ALL_0')]").check(
						true);
				{
					think(0.456);
				}
				forms.statusBar(314, "//forms:statusBar").assertText(
						"FormsFT AutoValidation: Verify StatusBar text value",
						"FRM-40202: Field must be entered.", MatchOption.Exact, 0);
				{
					think(53.841);
					think(2.184);
					think(42.961);
				}
				forms.checkBox(755,
						"//forms:checkBox[(@name='CSP_REQUIREMENT_LINES_CREATE_ORDER_CHECKBOX_0')]")
						.setFocus();
				{
					think(0.853);
				}
				forms.checkBox(756,
						"//forms:checkBox[(@name='CONTROL_CHECK_ALL_0')]").check(
						true);
				{
					think(14.392);
				}
				forms.checkBox(757,
						"//forms:checkBox[(@name='CSP_REQUIREMENT_LINES_CREATE_ORDER_CHECKBOX_0')]")
						.setFocus();
				{
					think(3.355);
				}
				forms.button(758, "//forms:button[(@name='CONTROL_ORDER_0')]")
						.click();
			}
			endStep();
			
		*/
		

	public void finish() throws Exception {
		
	} //public void finish() throws Exception
	
} //public class script extends IteratingVUserScript
