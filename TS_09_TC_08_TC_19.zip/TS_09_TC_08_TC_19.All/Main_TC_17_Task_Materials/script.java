import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.webdom.api.elements.DOMBrowser;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		
	} //public void initialize() throws Exception

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	
	public void run() throws Exception {
		
		callFunction("debriefLaborandMaterials");

	} //public void run() throws Exception
	
	
	public void debriefLaborandMaterials() throws Exception {
		
		
		userNavigation();
		callFunction("selectConsumableTask");
		callFunction("selectDebriefButton");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"enterDebriefLaborRecord", "0", "Military", "15:00", "16:00", "", "LABOR");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"clickOnDebriefMaterialTab");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"DebriefMultipleMaterialSDN", "multiple_task_materials_db", "C:\\OracleATS\\OFT\\", "1");
		getScript("TS_09Main_TC12Bricks").callFunction("closeDebriefForm");
		
		
	/*	userNavigation(); */
		
		callFunction("selectSECREPTask");
		callFunction("selectDebriefButton");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"enterDebriefLaborRecord", "0", "Military", "15:00", "16:00", "", "LABOR");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"clickOnDebriefMaterialTab");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"enterTaskMaterialDebrief", "0", "Issue From Inventory", "014745704", "EA", "1", "1CJ", "01A", "C000001AA", "", "99", "C:\\OracleATS\\OFT", "2");
		getScript("TS_09Main_TC12Bricks").callFunction(
				"enterTaskMaterialDebrief", "1", "Issue from Inventory", "014661855", "EA", "1", "1CJ", "01A", "C000001AA", "", "99", "C:\\OracleATS\\OFT", "3");
		getScript("TS_09Main_TC12Bricks").callFunction("closeDebriefForm");
		getScript("TS_09Main_TC12Bricks").callFunction("ExitEBS");
		if (false) {
			getScript("TS_09Main_TC12Bricks").callFunction("ScreenShot",
					"false", "true", "imagetest");
		}
		browser.close();
		
		
	} //public void debriefLaborandMaterials() throws Exception
	
	
	public void userNavigation() throws Exception {
		
		browser.launch();
		DOMBrowser myBrowser = web.window("/web:window[@index='0' or @index='1']");
		myBrowser.maximize();
		
		/*
		getScript("CACI_FunctLib_EBSFunctions").callFunction(
		"EBSCertificateLogin", "{{MyURL}}", "243");
		delay(3000);
		*/
		
		beginStep("[1] GCSS-MC Warning Banner (/obrareq.cgi)", 0);
		{
			web.window(23, "/web:window[@index='0' or @title='about:blank']")
					.navigate(
							"https://gcssmc-pt-ebs.int.gcssmc.sde/OA_HTML/AppsLogin");
			
			/*
			web.window(24,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					.waitForPage(null);
			*/
			{
				delay(4000);			
			}
			web.button(
					25,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
					.click();
		}
		endStep();
		beginStep("[2] Home (/OA.jsp)", 0);
		{
			web.window(26, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(12000);
			}
			web.element(
					29,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Inventory / Supply Officer' or @index='52']")
					.click();
		}
		endStep();
		beginStep("[3] Home (/OA.jsp)", 0);
		{
			/*
			web.window(30, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			*/
			{
				delay(8000);
			}
			web.element(
					33,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Request' or @index='338']")
					.click();
		}
		endStep();
		beginStep("[4] Home (/OA.jsp)", 0);
		{
			web.window(34, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(6000);
			}
			web.element(
					37,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Requests' or @index='342']")
					.click();
		}
		endStep();
		beginStep("[5] Home (/OA.jsp)", 0);
		{
			web.window(38, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(6000);
			}
			web.element(
					41,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Find Service Requests' or @index='346']")
					.click();
			{
				delay(6000);
			}
		}
		endStep();
		beginStep("[6] Find Service Requests", 0);
		{
			forms.captureScreenshot(57);
			{
				delay(6000);
			}
			forms.textField(58,
					"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_NUMBER_0')]")
					.setText("27630330");
			/*
			 * 
			 * Insert GLBL_ServiceRequestNumber for end-to-end playthrough, setup as PARAM for integration into Master Script and use databank for {{GLBL_ServiceRequestNumber}}
			 * 
			 */
			{
				delay(6000);
			}
			forms.button(59, "//forms:button[(@name='CS_FIND_MAIN_SEARCH_0')]")
					.click();
			{
				delay(3000);
			}
			forms.spreadTable(60,
					"//forms:spreadTable[(@name='CS_FIND_GRID_ITEM_GRID_0')]")
					.focusRow(1);
			{
				delay(3000);
			}
			forms.spreadTable(61,
					"//forms:spreadTable[(@name='CS_FIND_GRID_ITEM_GRID_0')]")
					.setFocus();
				delay(3000);
		}
		endStep();
		beginStep(
				"[7] Service Request ( 27630330 - Create Maintenance SR ) . Eastern Time",
				0);
		{
			forms.captureScreenshot(63);
			{
				delay(3000);
			}
			forms.tab(64, "//forms:tab[(@name='SR_CANVASES')]").select("Tasks");
			{
				think(4.518);
			}
			forms.spreadTable(65,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			{
				delay(3000);
			}
			forms.spreadTable(66,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			
			
		}
		endStep();
		
		
	} //public void userNavigation() throws Exception
	
	
	public void selectSECREPTask() throws Exception {
		
		{
			delay(1000);
		}
		forms.spreadTable(34,
				"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
				.focusRow(1);
		{
			delay(1000);
		}
		
		
		
	} //public void selectSECREPTask() throws Exception

	
	
	public void selectDebriefButton() throws Exception {
		
		delay(1000);
		forms.button(68, "//forms:button[(@name='CREATE_TASK_DEBRIEF_0')]")
		.click();
		delay(1000);
		
		
		
	} //public void selectDebriefButton() throws Exception
	
	public void selectConsumableTask() throws Exception {
		
		{
			delay(1000);
		}
		forms.spreadTable(67,
				"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
				.focusRow(2);
		{
			delay(1000);
		}
		
		
	} //public void selectConsumableTask() throws Exception
	
	
	public void finish() throws Exception {
		
	} //public void finish() throws Exception
	
	
	
	
} //public class script extends IteratingVUserScript
