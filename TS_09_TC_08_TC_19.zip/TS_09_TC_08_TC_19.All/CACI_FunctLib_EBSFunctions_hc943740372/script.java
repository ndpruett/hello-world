import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;
import java.util.List;

import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.applet.api.*;
import oracle.oats.scripting.modules.image.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
//import oracle.oats.scripting.modules.formsFT.common.api.elements.List;
import java.awt.*;
import java.util.*;
import lib.*;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;


public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.image.api.ImageService img;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;
	public void initialize() throws Exception {
	}

	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// ++
	// ++ Change History
	// ++
	// ++ May 19, 2021 - Manny Gochuico conmmented out the erroneous one-line function and replaced it with the latest
	// ++              - version of SS_getEBSNavigationAndClickOnMenuItems()
	// ++ 
	// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	/**
	 * 
	 * @param PAR_NavigationString 
	 * @param delimiterPattern 
	 */
	//public void SS_getEBSNavigationAndClickOnMenuItems(@Arg("PAR_NavigationString") String PAR_NavigationString,@Arg("delimiterPattern") String delimiterPattern) throws Exception{boolean isThereAComma=false;int menuItemCounter=0;String myNavigation=PAR_NavigationString;String charToSearch=delimiterPattern;List<String> menuItems=new ArrayList<String>();String repeatedString=null;boolean repeatedText=false;int repeatedCount=0;for (int i=0;i < myNavigation.length();i++){;int commaLocation=myNavigation.indexOf(charToSearch,i);info("commaLocaton ===> " + commaLocation);if (commaLocation > 0){isThereAComma=true;String A=myNavigation.substring(i,commaLocation);menuItems.add(A);info(menuItems.get(menuItemCounter).toString());i=commaLocation;menuItemCounter++;info("the value of i is ==>" + i);} else {if (isThereAComma){menuItems.add(myNavigation.substring(i,myNavigation.length()));info(menuItems.get(menuItemCounter).toString());break;} else {menuItems.add(myNavigation);info("myNavigation ===> " + myNavigation);menuItemCounter++;break;}}}info("Now Click on the menu items");boolean allmenuitemsclicked=false;for (int i=0;i < menuItems.size();i++){;String menuItem=menuItems.get(i).toString();info(menuItem);while (true){if (web.element(18,"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem+"']").exists()){info("check point " + i);break;} else {think(2.0);if (forms.window(29,"//forms:window[(@name='NAVIGATOR')]").exists()){allmenuitemsclicked=true;break;}}}if (allmenuitemsclicked){break;}think(4.0);web.element(18,"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem+"']").click();info("(" + i+") clicked on ==> "+menuItem);think(2.0);info("Checkpoint " + i+"a");{think(2.0);}}}

	public void SS_getEBSNavigationAndClickOnMenuItems(String PAR_NavigationString, String delimiterPattern) throws Exception {
		/*
		 * this function will read the navigation path from the scripts
		 * spreadsheet and then use the data in th espreadsheet to navigate the
		 * menu's in EBS.
		 * 
		 * parameters:
		 * PAR_NavigationString - This is a string composed of the navigation path delimited by the delimiter pattern
		 * delimiterPattern - This is the delimiter to separate the navigation strings
		 * 
		 * usage example:
		 * SS_getEBSNavigationAndClickOnMenuItems("Purchase Orders;Query Purchase Orders" , ";");
		 * 
		 * Manny Gochuico
		 */
		// ++++++++++++ setup variables +++++++++++++++++++++
		boolean isThereAComma = false;
		int menuItemCounter = 0;
		String myNavigation = PAR_NavigationString;
		String charToSearch = delimiterPattern; // originally --> ",";
		List<String> menuItems = new ArrayList<String>();

		String repeatedString = null;
		boolean repeatedText = false;
		int repeatedCount = 0;



		// ++++++++++++ now parse the menu items +++++++++++++++++++
		for (int i = 0; i < myNavigation.length(); i++) {
			// check if ther eis a comma in the string
			int commaLocation = myNavigation.indexOf(
				charToSearch,
				i);
			info("commaLocaton ===> " + commaLocation);
			if (commaLocation > 0) {
				isThereAComma = true;
				String A = myNavigation.substring(
					i,
					commaLocation);
				menuItems.add(A);
				info(menuItems.get(
					menuItemCounter).toString());
				i = commaLocation;
				menuItemCounter++;
				info("the value of i is ==>" + i);

			} else {
				if (isThereAComma) {
					menuItems.add(myNavigation.substring(
						i,
						myNavigation.length()));
					info(menuItems.get(
						menuItemCounter).toString());
					break;
				} else {
					menuItems.add(myNavigation);
					info("myNavigation ===> " + myNavigation);
					menuItemCounter++;
					break;
				}

			}
		}

		info("Now Click on the menu items");
		boolean allmenuitemsclicked = false;

		for (int i = 0; i < menuItems.size(); i++) {
			String menuItem = menuItems.get(
				i).toString();
			// info(menuItems.get(i).toString());
			info (menuItem);
			
			

	//info("I am here - "+i); // remove after debug
			while (true) {
				if (web.element(
					18,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem
								+ "']")
				.exists())
				{
					info("check point "+i);
					break;
				}
				else
				{
					// info("XXXXXXXXXXXXX");
					think(2.0);
					if (forms.window(29, "//forms:window[(@name='NAVIGATOR')]").exists())
					{
						allmenuitemsclicked = true;
						break;
					}
				}
			}
	//info("I am here AGAIN - "+i); // remove after debufg
			if (allmenuitemsclicked) // this means that the java form is already displayed on the screen.
				break;
			
			think(4.0);
			
			web.element(
				18,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem
							+ "']").click();
			
			info("("+i+") clicked on ==> "+menuItem);				


			delay(6000);
			info("Checkpoint "+i+"a");
			// web.window(19, "/web:window[@index='0' or @title='Home']").waitForPage(null);
		{
		think(2.0);
		}
	//info("GOING BACK TO THE FOR LOOP"); // remove aftger debug
		}


		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++

		} // end of SS_getEBSNavigation	
	
	
	/**
	 * 
	 * @param PAR_Responsiblity 
	 * @param PAR_FirstMenuitem 
	 */
	public void enterResponsiblity(
			@Arg("PAR_Responsiblity") String PAR_Responsiblity,
			@Arg("PAR_FirstMenuitem") String PAR_FirstMenuitem)
			throws Exception {
		{
			web.window(1293, "/web:window[@index='0' or @title='Home']")
					.waitForPage(20, true);
			{
				think(1.0);
			}
			while (true) {
				if (web.element(
						1296,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"
								+ PAR_Responsiblity + "' or @index='58']")
						.exists()) {
					break;
				} else {
					think(1.0);
				}
			}
			web.element(
					1296,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"
							+ PAR_Responsiblity + "' or @index='58']").click();
			think(2.0);
			while (true) {
				if (web.element(
						18,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"
								+ PAR_FirstMenuitem + "']").exists()) {
					info("Found the menu item");
					break;
				} else {
					think(2.0);
				}
			}
		}
	}

	/**
	 * 
	 * @param FIleName name of the image file
	 * @param TabTime time in mSeconds to wait between tabs
	 */
	
	
	
	

	
	
	
	
	
	
	public void ProcessCert(@Arg("FIleName") String FIleName,
			@Arg("TabTime") int TabTime, @Arg("Desc") String Desc) throws Exception {
		Boolean Flag = true;
		do {
			if (img.target("{{@resourceFile(" + FIleName + ")}}", 55, 12, 0.9,
					"ItemMaster").exists()) {
				delay(TabTime);
				img.target("{{@resourceFile(" + FIleName + ")}}", 50, 11, 0.9,
						"ItemMaster").doubleClick();
				Flag = false;
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_TAB);
				delay(3000);
			}
			;
		} while (Flag);
		info(Desc + "User Logging In");
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {

	}

	/**
	 * The Screenshot function will create a .jpg image in a special sub foldernamed "ScreenShots" in the current result playback session.   The parameters passed are:Web - this is a boolean value where true is if we are capturing a web pageForms - this is a boolean value where ture is if we are capturing a Forms appletImageName - is the name we are giving the image without the file extension
	 * @param Web 
	 * @param Forms 
	 * @param ImageName 
	 */
	public void ScreenShot(@Arg("Web") Boolean Web,
			@Arg("Forms") Boolean Forms, @Arg("ImageName") String ImageName)
			throws Exception {
		
		/* Define Local Resources */
		String ResultsReport;
		String imgName = ImageName + ".jpg";
		Integer HzResolution = 1920;
		Integer VrResolution = 1080;
		
		
		
		/* Create Directory Path for Images */
		
		ResultsReport = getSettings().get("oats_session_result_dir")
				+ "\\ScreenShots";
		
			
		File newFile = new File(ResultsReport);
		
		/* Check to see if the directory already exists and if it does continue if it doesn't
		 * Then create a new directory 
		 */
		
				if(!newFile.isDirectory()){
		
						Files.createDirectory(Paths.get(ResultsReport));
		
				}
				
		/* Save screen captures */		
		
		if (Web) {
			web.window(
					"/web:window[@index='0' or @title='www.oracle.com - Bing']")
					.capturePage(ResultsReport, imgName);
		}
		if (Forms) {
			ft.getScreenCapture(0, 0, HzResolution, VrResolution, ResultsReport + "\\"
					+ imgName);
		}
	}

	/**
	 * 
	 * @param URL Target Environment
	 * @param UserCertificate See Cert Table
	 */
	public void EBSCertificateLogin(@Arg("URL") String URL,
			@Arg("UserCertificate") int UserCertificate) throws Exception {
		beginStep("[1] Navigate to EBS", 0);
		{
			web.window(10, "/web:window[@index='0' or @title='about:blank']")
					.navigate(
							"{{arg.URL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}");
			
			
			delay(20000);
			
			
			
			info("One");
			if( web.link(
				9,
				"/web:window[@index='0' or @title='This site isn’t secure']/web:document[@index='0']/web:a[@text='More information']")
				.exists()){
			
			
			
			
			
			info("two");
			web.link(
					15,
					"/web:window[@index='0' or @title='This site isn’t secure']/web:document[@index='0']/web:a[@text='More information']")
					.click();
			
			
			
			
			{
				think(6.598);
			}
			delay(3000);
			web.link(
					9,
					"/web:window[@index='0' or @title='This site isn’t secure']/web:document[@index='0']/web:a[@text='Go on to the webpage (not recommended)']")
					.click();
			{
				think(6.598);
			}
			
			
			
			delay(5000);
			if(
					web.dialog(
				10,
				"/web:dialog_unknown[@text='The current webpage is trying to open a site in your Trusted sites list. Do you want to allow this?' or @index='0']")
				.exists()
				)
			
				
			   {
			     
			    web.dialog(
				10,
				"/web:dialog_unknown[@text='The current webpage is trying to open a site in your Trusted sites list. Do you want to allow this?' or @index='0']")
				.clickButton(1);
			
			
			    }
			
			
			
			}
			
			
			for (int i = 0; i < 10; i++) {
				
				
				delay(2000);
				
				
				callFunction("CertificateExists");
				
				
				String MyResult = eval("{{CertificateThere}}");
				info("result is:  " + MyResult);
				boolean YesNo = toBoolean(MyResult);
				if (YesNo) {
					
					callFunction("ChooseCertificate", "{{arg.UserCertificate}}");
				     
					break;
				
				
				
				}
			}
			web.window(12,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					.waitForPage(null);
			{
				think(8.471);
			}
			web.button(
					13,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
					.click();
		}
		endStep();
		beginStep("[2] Home (/OA.jsp)", 0);
		{
			callFunction("CertificateExists");
			String MyResult = eval("{{CertificateThere}}");
			info("result is:  " + MyResult);
			boolean YesNo = toBoolean(MyResult);
			if (YesNo) {
				callFunction("ChooseCertificate", "{{arg.UserCertificate}}");
			}
			web.window(14, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null, true);
			{
				think(10.876);
			}
		}
		endStep();
	}

	

	/**
	 * Check to see if Certificate Exists
	 */
public void CertificateExists() throws Exception {
		
		getVariables().set("CertificateThere", "false", Variables.Scope.GLOBAL);
		
		delay(5000);
		
		if (img.target("{{@resourceFile(ImageLib/SelectCertificate.png)}}", 82, 17, 0.9,
		"SecurityCertificatePopUp").exists()){
			
			img.target("{{@resourceFile(ImageLib/SelectCertificate.png)}}", 82, 17, 0.9,
			"SecurityCertificatePopUp").click();
			
			getVariables().set("CertificateThere", "true", Variables.Scope.GLOBAL);
			
			info("Certficate found");
			info("{{CertificateThere}}");
		
		}
		
	}

	/**
	 * Cancels Security Certificate
	 */
	public void CancelCert() throws Exception {
		if (img.target("{{@resourceFile(ImageLib/SelectCertificate.png)}}", 82,
				17, 0.9, "SecurityCertificatePopUp").exists()) {
			img.target("{{@resourceFile(ImageLib/CancelButton.png)}}", 97, 18,
					0.9, "ClickCancelButton").click();
		}
	}

	/**
	 * ChoosCertificate fuction uses a java case statement to select the proper user certificate by translating the cert number to 
	 * the image event that clicks on the nice name the list of certs to nice names is:
	 *
	 *		201		Supply Financial
	 *		203		Warranty
	 *		221		Advanced Search
	 *		223		EATO, Material Redistribution
	 *		243		System Admin
	 *
	 * @param User CertNumber
	 */
	public void ChooseCertificate(@Arg("User") int User) throws Exception {
		
		img.target("{{@resourceFile(ImageLib/MoreChoices.png)}}", 59, 17, 0.95,
		"ClickMoreChoices").click();

		
		Integer Login = User;
		Boolean Flag = true;
		Integer TabbingTIme =1000;
		
		
		switch (Login){
			
		
		
		case 200:
			/* ImageLib/ItemMaster.png */
			
			getVariables().set("MyImage", "ImageLib/ItemMaster.png",
				Variables.Scope.GLOBAL);
			
			getVariables().set("MyDescription", "Item Master ",
				Variables.Scope.GLOBAL);
	
			callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
			break;
		
		
		
		
		
		case 201:
			
			/* ImageLib/SupplyFinancial.png */
			
			getVariables().set("MyImage", "ImageLib/SupplyFinancial.png",
				Variables.Scope.GLOBAL);
			
			getVariables().set("MyDescription", "Supply Financial ",
				Variables.Scope.GLOBAL);
	
			callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
			
			
		break;
		
		
			
			
		case 203:
			
			/* ImageLib/WarranteCert.png */
			
			
			getVariables().set("MyImage", "ImageLib/WarranteCert.png",
				Variables.Scope.GLOBAL);
			getVariables().set("MyDescription", "Warranty ",
					Variables.Scope.GLOBAL);
				
			callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
				
		break;	
			
			
			
			
			
			
			
		case 211:
			
			
			/* ImageLib/UnitAccountManager.png */
			
			getVariables().set("MyImage", "ImageLib/UnitAccountManager.png",
				Variables.Scope.GLOBAL);
			
			getVariables().set("MyDescription", "Unit Account Manager ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
      case 213:
			
    	  /* ImageLib/InventorySupplyNCO.png */
    	  
    	  
    	  getVariables().set("MyImage", "ImageLib/InventorySupplyNCO.png",
				Variables.Scope.GLOBAL);
			
    	  getVariables().set("MyDescription", "Inventory Supply NCO ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
			
			
        case 221:
        	
        	
        	 /* ImageLib/AdvancedSearch.png */
        	
        	getVariables().set("MyImage", "ImageLib/AdvancedSearch.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "Advanced Search ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
        case 223:
        	
        	 /* ImageLib/EATO.png */
			

        	getVariables().set("MyImage", "ImageLib/EATO.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "EATO ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
		
			
			
        case 236:
			

        	/* ImageLib/MaintenanceChief.png */
        	
        	
        	
        	getVariables().set("MyImage", "ImageLib/MaintenanceChief.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "Maintenance Chief ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
				
			
			
			
			
		
        case 238:
			

        	/* ImageLib/ShippingReceivingNCO.png */
        	
        	
        	getVariables().set("MyImage", "ImageLib/ShippingReceivingNCO.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "Shipping Receiving NCO ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
			
			
			
		case 243: 
			
			
			/* ImageLib/SysAdmin.png */
			
				getVariables().set("MyImage", "ImageLib/SysAdmin.png",
				Variables.Scope.GLOBAL);
			
				getVariables().set("MyDescription", "Sys Admin ",
					Variables.Scope.GLOBAL);
				
			    callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
				
		break;	
			
		
		
		
		default:
			info("Error No Such User Exists");
		break;
			
		}
		
		delay(2000);
		img.target("{{@resourceFile(ImageLib/OKButton.png)}}", 15, 8, 0.91,
				"ClickOKonCert").click();
		
		}
		
	/**
	 * 
	 * @param InputString 
	 * @param FileName 
	 * @param ParamName 
	 */
	public void GenerateEDIFile(@Arg("InputString") String InputString,
			@Arg("FileName") String FileName, @Arg("ParamName") String ParamName)
			throws Exception {
		beginStep("[8] Navigator - GCSS-MC Help Desk Concurrent Manager", 0);
		{
			forms.captureScreenshot(16);
			{
				think(17.161);
			}
			forms.treeList(18,
					"//forms:treeList[(@name='NAVIGATOR_HOTLIST_0')]")
					.focusItem("");
			{
				think(0.479);
				think(2.484);
			}
			forms.treeList(19, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem("Run Requests");
			{
				think(0.076);
				think(3.499);
			}
			forms.button(20, "//forms:button[(@name='NAV_CONTROLS_OPEN_0')]")
					.click();
		}
		endStep();
		beginStep("[9] Submit a New Request", 0);
		{
			forms.captureScreenshot(21);
			{
				think(91.306);
			}
			forms.button(22, "//forms:button[(@name='WHAT_TYPE_OK_0')]")
					.click();
		}
		endStep();
		beginStep("[10] Submit Request", 0);
		{
			forms.captureScreenshot(23);
			{
				think(61.094);
			}
			forms.textField(24,
					"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]")
					.setText("XXMC Automated Test File Generation");
			{
				think(0.005);
			}
			forms.button(25, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
					.click();
		}
		endStep();
		beginStep("[11] Error", 0);
		{
			forms.captureScreenshot(26);
			{
				think(13.124);
			}
			forms.choiceBox(27, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		beginStep("[12] Parameters", 0);
		{
			forms.captureScreenshot(28);
			{
				think(22.722);
			}
			forms.flexWindow(29, "//forms:flexWindow").setText("Name", "",
					"{{arg.ParamName}}");
			{
				think(57.592);
			}
			forms.flexWindow(30, "//forms:flexWindow").setTextAndClickOk(
					"Value", "", "{{arg.InputString}}");
		}
		endStep();
		beginStep("[13] Submit Request", 0);
		{
			forms.captureScreenshot(31);
			{
				think(312.427);
			}
			forms.button(32, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
					.click();
			{
				think(0.03);
			}
			if (false) {
				forms.statusBar(33, "//forms:statusBar")
						.verifyText(
								"FormsFT AutoValidation: Verify StatusBar text value",
								"FRM-40400: Transaction complete: 1 records applied and saved.",
								MatchOption.Exact, 0);
			}
		}
		endStep();
		beginStep("[14] Decision", 0);
		{
			forms.captureScreenshot(34);
			{
				think(27.067);
			}
			String message = forms.choiceBox(118, "//forms:choiceBox")
					.getAlertMessage();
			String ReqID = message;
			Integer startpos = message.indexOf("Request ID");
			Integer endpos = ReqID.indexOf(")", (startpos + 6));
			String thesub = ReqID.substring(startpos + 12, endpos);
			getVariables().set("RequestID", thesub, Variables.Scope.GLOBAL);
			delay(3000);
			info("{{RequestID}}");
			info("Baseline");
			forms.choiceBox(35, "//forms:choiceBox").clickButton("No");
			{
				think(1.274);
			}
			forms.window(36, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
		}
		endStep();
		beginStep("[15] Navigator - GCSS-MC Help Desk Concurrent Manager", 0);
		{
			forms.captureScreenshot(37);
			{
				think(4.87);
			}
			forms.treeList(38, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem("View Requests");
			{
				think(0.075);
				think(2.955);
			}
			forms.button(39, "//forms:button[(@name='NAV_CONTROLS_OPEN_0')]")
					.click();
		}
		endStep();
		beginStep("[16] Find Requests", 0);
		{
			forms.captureScreenshot(40);
			{
				think(24.132);
			}
			forms.radioButton(41,
					"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]")
					.select();
			{
				think(17.395);
			}
			forms.textField(42,
					"//forms:textField[(@name='JOBS_QF_REQUEST_ID_0')]")
					.setText("{{RequestID,121116391}}");
			{
				think(0.008);
			}
			forms.button(43, "//forms:button[(@name='JOBS_QF_FIND_0')]")
					.click();
			{
				think(0.343);
			}
			forms.window(44, "//forms:window[(@name='JOBS')]").activate(true);
		}
		endStep();
		beginStep("[17] Requests", 0);
		{
			forms.captureScreenshot(45);
			{
				think(7.23);
			}
			String RunningStatus;
			do {
				delay(20000);
				String Status = forms.textField(89,
						"//forms:textField[(@name='JOBS_PHASE_0')]")
						.getAttribute("text");
				RunningStatus = Status;
				forms.textField(46,
						"//forms:textField[(@name='JOBS_REQUEST_ID_0')]")
						.setFocus();
				{
					think(0.171);
				}
				forms.button(47, "//forms:button[(@name='JOBS_REFRESH_0')]")
						.click();
				{
					think(4.248);
				}
			} while (!RunningStatus.equals("Completed"));
			forms.button(48, "//forms:button[(@name='JOBS_VIEW_REPORT_0')]")
					.click();
			{
				think(190.638);
			}
			forms.window(49, "//forms:window[(@name='JOBS')]").close();
			{
				think(1.674);
			}
			forms.window(50, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
		}
		endStep();
		getVariables().set("MyFileName", "{{arg.FileName}}",
				Variables.Scope.GLOBAL);
		delay(15000);
		
		
		
		img.target("{{@resourceFile(ImageLib/0.png)}}", 16, 27, 0.9,
		"FindNotePadonDesktop").click();
img.target("{{@resourceFile(ImageLib/1.png)}}", 17, 10, 0.9,
		"ClickFile").click();
img.target("{{@resourceFile(ImageLib/2.png)}}", 97, 12, 0.9,
		"ClickSaveAs").click();

delay(3000);


Robot r = new Robot();
r.keyPress(KeyEvent.VK_DELETE);
r.keyRelease(KeyEvent.VK_DELETE);

delay(3000);


img.target("{{@resourceFile(ImageLib/3.png)}}", 73, 21, 0.9).input(
		"\"{{MyFileName,MyFile999}}.dat\"");
img.target("{{@resourceFile(ImageLib/4.png)}}", 54, 24, 0.9, "SAVE it")
		.click();
img.target("{{@resourceFile(ImageLib/1.png)}}", 17, 10, 0.9,
		"ClickFile").click();
img.target("{{@resourceFile(ImageLib/5.png)}}", 33, 13, 0.9, "exit")
		.click();
		
		
		
		
		
		
		
		
		
		
		
		delay(15000);
	}	

	public void finish() throws Exception {

		
		
		
	}
}
