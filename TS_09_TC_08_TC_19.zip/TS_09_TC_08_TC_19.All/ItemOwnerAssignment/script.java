import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		itemAOROAssignment("Accountable Officer","TEST236%");
		
		// The following Unit test must be executed after the XXMC_CREATE_MI_IB_REL_SKD Concurrent Job completes
		boolean returnValue = validatePCNExistsOnItem("161122334613");
	}

	public void finish() throws Exception {
	}
	
	/*
	 * itemAOROAssignment can be used to add AO / RO assignment
	 * partyName values can be "Accountable Officer" or "Responsible Officer"
	*/
	public void itemAOROAssignment(String PAR_PartyName, String PAR_Assignee_Name) throws Exception {
		
	try
	{
		beginStep("[8] Item Instance Details (/OA.jsp)", 0);
		{
			
			web.window(1966,
				"/web:window[@index='0' or @title='Item Instance Details']")
				.waitForPage(20, true);
			{
				delay(3000);
			}
			web.element(
				1969,
					"/web:window[@index='0' or @title='Item Instance Details']/web:document[@index='0']/web:label[@innerText='Associations' and @text='Associations' and @index='2']")
					.click();
			{
				delay(5000);
			}
				
		} //		beginStep("[8] Item Instance Details (/OA.jsp)", 0);
		endStep();
		

		beginStep(
				"[9] Item Instance Details (/InstanceDetailsPG&InstanceId=317459652&ProductNumber=317459652&ItemDescription=RECEIVER-TRANSMITTE&retainAM=Y&addBreadCrumb=Y&_ti=456859458&oapc=7&oas=wSExoSWyZj0xt3EX6_Nkkw..)",
				0);
		{
			web.window(37,
					"/web:window[@index='0' or @title='Item Instance Details']")
					.waitForPage(20, true);
			{
				delay(2000);
			}
			web.button(
					40,
					"/web:window[@index='0' or @title='Item Instance Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='AddParty' or @index='5']")
					.click();
		}
		endStep();
		beginStep(
				"[10] Add Association (/InstanceDetailsPG&InstanceId=317459652&ProductNumber=317459652&ItemDescription=RECEIVER-TRANSMITTE&OA_SubTabIdx=2&_ti=456859458&retainAM=Y&addBreadCrumb=S&oapc=9&oas=oqNLd-zo9yi8VxgSzzQ1hA..)",
				0);
		{
			web.window(41,
					"/web:window[@index='0' or @title='Add Association']")
					.waitForPage(20, true);
			{
				delay(2000);
			}
			web.selectBox(
					44,
					"/web:window[@index='0' or @title='Add Association']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:select[(@id='RelationshipTypeCode' or @name='RelationshipTypeCode' or @index='1') and multiple mod 'False']")
					.selectOptionByText(PAR_PartyName);
		}
		endStep();

		beginStep(
				"[11] Add Association (/PartyCreatePG&ReturnToPageFunc=CSI_OA_INST_DETAILS&_ti=456859458&retainAM=N&addBreadCrumb=Y&oapc=11&oas=51G8ovbYNnkWmXCLiamV3A..)",
				0);
		{
			web.window(45,
					"/web:window[@index='0' or @title='Add Association']")
					.waitForPage(20, true);
			{
				think(0.942);
			}
			web.textBox(
					48,
					"/web:window[@index='0' or @title='Add Association']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='PartyName' or @name='PartyName' or @index='0']")
					.click();
			{
				think(1.784);
			}
			web.textBox(
					49,
					"/web:window[@index='0' or @title='Add Association']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='PartyName' or @name='PartyName' or @index='0']")
					.setText(PAR_Assignee_Name);
			{
				delay(11000);
			}
			web.image(
					50,
					"/web:window[@index='0' or @title='Add Association']/web:document[@index='0']/web:img[@alt='Search: Party Name' or @index='32' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/cabo/images/alta/func_search_16_ena.png']")
					.click();
		}
		endStep();

		beginStep(
				"[12] Add Association (/PartyCreatePG&ReturnToPageFunc=CSI_OA_INST_DETAILS&_ti=456859458&retainAM=N&addBreadCrumb=Y&oapc=12&oas=ppH3LTiPegNyDP1W9p5rdA..)",
				0);
		{
			web.window(51,
				"/web:window[@index='1' or @title='Search and Select List of Values']")
				.waitForPage(null);
			{
				delay(10000);
			}
			web.radioButton(
				57,
				"/web:window[@index='1' or @title='Search and Select List of Values']/web:document[@index='1']/web:form[@id='_LOVResFrm' or @name='_LOVResFrm' or @index='0']/web:input_radio[@id='N1:N8:0' or (@name='N1:selected' and @value='0') or @index='0']")
				.select();
			{
				delay(2000);
			}
			web.button(
				58,
				"/web:window[@index='1' or @title='Search and Select List of Values']/web:document[@index='1']/web:button[@index='1']")
				.click();
		}
		endStep();
		

		beginStep(
				"[13] Add Association (/PartyCreatePG&ReturnToPageFunc=CSI_OA_INST_DETAILS&_ti=456859458&retainAM=N&addBreadCrumb=Y&oapc=12&oas=ppH3LTiPegNyDP1W9p5rdA..)",
				0);
		{
			web.window(59,
					"/web:window[@index='0' or @title='Add Association']")
					.waitForPage(20, true);
			{
				delay(3000);
			}

			                                                                                     
			web.image(
					62,
					"/web:window[@index='0' or @title='Add Association']/web:document[@index='0']/web:img[@index='35' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/cabo/images/alta/input_date.png']")
					.click();
			{
				delay(6000);
			}
			web.element(
					63,
					"/web:window[@index='1' or @title='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/cabo/jsps/a.jsp?_t=fred&_red=cd&value=1607823721060&configName=OAConfig&loc=en-US-ORACLE9I&enc=UTF-8&contextURI=/OA_HTML&tzOffset=-300&tzId=America%2FNew_York&_minWidth=420&_minHeight=380&firstDOW=1']/web:document[@index='1']/web:span[@text='12' or @index='1']")
					.click();
			{
				delay(5000);
			}
			
			
			beginStep("Create AO/RO Assignment");
			{
				String AOROScreenShotFile = "{{GLBL_Prefix_AORO_File_Name}}"+"_"+PAR_PartyName+"_1";
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", AOROScreenShotFile);
				delay(3000);
				AOROScreenShotFile = null;
			}

			
			web.button(
					64,
					"/web:window[@index='0' or @title='Add Association']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='CSI_APPLY' or @index='1']")
					.click();
		}
		endStep();
		
		delay(5000); // wait for Save to complete
		
		
		beginStep("Saved AO/RO Assignment");
		{
			String AOROScreenShotFile = "{{GLBL_Prefix_AORO_File_Name}}"+"_"+PAR_PartyName+"_2";
			getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", AOROScreenShotFile);
			delay(3000);
			AOROScreenShotFile = null;
		}
		

		beginStep("[15] Click on General tab", 0);
		{
		
			web.window(1966,
				"/web:window[@index='0' or @title='Item Instance Details']")
				.waitForPage(20, true);
			{
				delay(4000);
			}
			web.element(
					1969,
					"/web:window[@index='0' or @title='Item Instance Details']/web:document[@index='0']/web:label[@innerText='General' and @text='General' and @index='0']")
					.click();
			{
				delay(5000);
			}
			
		}
		endStep();
	}
	catch (Exception e)
	{
		info ("itemAOROAssignment(String PAR_PartyName, String PAR_Assignee_Name)" + e.getMessage());
		throw e;
	}

	}  // public void itemAOROAssignment(String partyName)
	
	/*
	 * *
	 * validatePCNExistsOnItem takes PCN Number as string and return a boolean value"
	 * @assumption/Pre-Req - The assumption is you are on the "General" tab of the Item Detail page before calling this function
	 * @param PAR_itemNumber - String value which is an itemNumber that must be searched
	*/
	public boolean validatePCNExistsOnItem(String PAR_itemNumber) throws Exception {
		try
		{
			boolean itemConfigExists = false;
		
			beginStep("[1] Item Instance Details (/OA.jsp)", 0);
			{
				web.window(2077,
						"/web:window[@index='0' or @title='Item Instance Details']")
						.waitForPage(null);
				{
					think(3.145);
				}
				web.element(
						2080,
						"/web:window[@index='0' or @title='Item Instance Details']/web:document[@index='0']/web:label[@innerText='Configuration' and @text='Configuration' and @index='3']")
						.click();
					think(5.145);
			}
			endStep();
			beginStep("Configuration Tab to confirm PCN Association Successfull");
			{
				web.window("/web:window[@index='0' or @title='Item Instance Details']").capturePage();
				delay(3000);
			}
			
			try
			{
				int rowCount = 1;
				boolean continueUntilFound = true;  // to support do / while loop to continue
				String rowElementId;
				String rowElementItemNumber;
				do
				{

			
					rowElementId = "N388:ItemNumber:" + String.valueOf(rowCount);
					rowElementItemNumber = web.findElementById(rowElementId).getDisplayText(); 

					if (rowElementItemNumber != null) {
						
						// even thought it is not needed since initiated as true but still keeping it for ease of flow when viewing the code
						continueUntilFound = true;

						// validate the parameter value matches with itemNumber found on the current row
						if (rowElementItemNumber.equals(PAR_itemNumber)) {
							web.findElementById(rowElementId).dblClick();
							itemConfigExists = true;
							continueUntilFound = false;  // false will exit while loop
							info ("Found the itemNumber : " + PAR_itemNumber);
							beginStep("PCN Association Exists Confirmation");
							{
								web.window("/web:window[@index='0' or @title='Item Instance Details']").capturePage();
								delay(3000);
							}
							endStep();
						}
						
						rowCount ++;
					}
					else{
						continueUntilFound = false; // while (true)
						info("Not found the itemNumber : " + PAR_itemNumber + " rowElementId : " + rowElementId);
					}
						
				}while (continueUntilFound);
			} // try inside try block
			catch(NullPointerException npe)
			{
				info ("validatePCNExistsOnItem(String PAR_itemNumber) : NullPointerException : " + npe.getMessage());
				return false;
			}
			
			return itemConfigExists;
		}
		catch (Exception e)
		{
			info ("validatePCNExistsOnItem(String PAR_itemNumber) : " + e.getMessage());
			throw e;
		}
	}

}
