import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;
import java.util.*;
import java.util.concurrent.TimeUnit;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		//browser.launch();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	
	/*
	 * call these Functions:
	 * 1) EnterSDNNumberAndClickFindButton(String PAR_SDNNumber)
	 * DEscription - This function will enter ther SDN number you want to receive and click on the Find button
	 * Pre-Requisite
	 * A) You get to this form after you have selected the inventory Org
	 * 
	 * 2) clickOnEnterReceiptButton()
 	 * Description" this is used so that you can enter the SDN Receipt
 	 * Pre-requisite:
 	 * A) This must be run after calling EnterSDNNumberAndClickFindButton
 	 * 
	 * 3) enterSDNReceipt(int PAR_LineNumber,String PAR_SDNNumberToReceive,String PAR_ManifestQuantity,String PAR_ReceiptQuantity,String PAR_ReceiptSubinventory,String PAR_ReceiptLocator,String PAR_ReceiptItemSerialNumber)
	 * Description: This function allows you to enter an SDN Receipt.  you muxt provide the parameters in order for it to run
	 * NOTE: 
	 * PAR_LineNumber is a zero-index field which means that when receiving line 1 of the receipt form, PAR_LineNumber = 0. 
	 * when processing multiple receipts, you have to increment this number as you receive multiple lines 
	 * pre-requisite:
	 * A) This must be done AFTER calling clickOnEnterReceiptButton()
	 * 
	 *  
	 * 4) closeEnterReceiptWindow()
	 * Description: After the receipt has been done and the carcass and replacement numbers have been determined, then you have to close the receipt window
	 * Pre-requisite:
	 * A) Receipt should have been completed.
	 * 
	 * 5) selectInventoryOrganization(String PAR_InventoryOrg)
	 * Description: This will select the inventory org if that form presents itself
	 * 
	 */
	public void run() throws Exception {
		
}


	public void finish() throws Exception {
	}
	
	private void testOnly(String PAR_parameter) throws Exception
	{
		info("my name is "+PAR_parameter);
	} // end of testOnly
	
	public boolean enterSDNReceipt(int PAR_LineNumber,
			String PAR_SDNNumberToReceive,
			String PAR_ReceiptSubinventory,
			String PAR_ReceiptLocator,
			String PAR_ReceiptItemSerialNumber,
			String PAR_ImageName) throws Exception
	/*
	 * Use this function to pick up the Due Quantity and then use that to populate the manifest quantity, and the receipt quantity	
	 * PAR_Imagename is the name that you want to give to the screenshot	
	 */
	{
	boolean receiptCompleted = false;

	String myReceiptQuantity=getReceiptDueQuantity(0);

	enterManifestQuantity(PAR_LineNumber, myReceiptQuantity);
	enterReceiptQuantity( PAR_LineNumber,  myReceiptQuantity);
	enterReceiptQuantity( PAR_LineNumber,  myReceiptQuantity); // the receipt quantity is entered twice
	enterReceiptSubinventory( PAR_LineNumber,  PAR_ReceiptSubinventory);
	enterReceiptLocator( PAR_LineNumber,  PAR_ReceiptLocator);
	if (Integer.parseInt(myReceiptQuantity)==1)
		enterReceiptItemSerialNumber( PAR_LineNumber,  PAR_ReceiptItemSerialNumber);


	/*//take a screenshot
	ScreenShot(false,true, "03_"+PAR_ImageName);
	*/

	clickOnEnterReceiptSubmitButton();
	pauseForAMoment(5);

	/*
	//take a screenshot
	ScreenShot(false,true, PAR_ImageName);
	*/

	getRequestIDThenClickButton( "OK");
	receiptCompleted = checkIfDRAandD6TExist(PAR_SDNNumberToReceive);
	info("receipt completed ===> "+receiptCompleted);

	return receiptCompleted;

	} // end of enterSDNReceipt
	
	public void ScreenShot(boolean Web,boolean Forms, String ImageName) throws Exception 
	{
		/** 
		*
		* The Screenshot function will create a .jpg image in a special sub folder
		* named "ScreenShots" in the current result playback session.   The parameters 
		* passed are:
		* Web - this is a boolean value where true is if we are capturing a web page
		* Forms - this is a boolean value where true is if we are capturing a Forms applet
		* ImageName - is the name we are giving the image without the file extension.  You have to concatenate the image path and the file extension. (see sample usage) 
		* 
		* the following OpenScript Global variables must have been set to a string value prior to calling this function
		* GLBL_IC_Left 
		* GLBL_IC_Top
		* GLBL_IC_HorizontalRes
		* GLBL_IC_VerticalRes
		* 
		* Dependencies:
		* You must call setupScreenshotParameters() at the top of your program before you run this function
		* 
		* Sample usage:
		* ScreenShot(false,true,GLBL_IC_ImagePath+"01_EnterMaterialRedistributionParameters"+a+".jpg");
		*/
		String ResultsReport = getSettings().get("oats_session_result_dir")+"\\ScreenShots";
		String imgName = ImageName + ".jpg";
		int local_GLBL_IC_Left = Integer.valueOf(getVariables().get("GLBL_IC_Left"));
		int local_GLBL_IC_Top = Integer.valueOf(getVariables().get("GLBL_IC_Top"));
		int local_GLBL_IC_HorizontalRes = Integer.valueOf(getVariables().get("GLBL_IC_HorizontalRes"));
		int local_GLBL_IC_VerticalRes = Integer.valueOf(getVariables().get("GLBL_IC_VerticalRes"));

		if(Web)
		{
			web.window(
				"/web:window[@index='0' or @title='www.oracle.com - Bing']")
				.capturePage(ResultsReport, imgName);
		}
		if(Forms)
		{
		ft.getScreenCapture(local_GLBL_IC_Left, 
			local_GLBL_IC_Top, 
			local_GLBL_IC_HorizontalRes, 
			local_GLBL_IC_VerticalRes, 
			ImageName);

		info("Completed Screenshot");
		}
	} // end of ScreenShot


	public String setupScreenshotParameters(String PAR_GLBL_IC_Left,String PAR_GLBL_IC_Top, String PAR_GLBL_IC_HorizontalRes, String PAR_GLBL_IC_VerticalRes ) throws Exception
	{
		/*
		 * This function is needed to setup the variables for the ScreenShot function.
		 * This function sets up the global OpenScript Variables that is being used by ScreenShot():
		 * GLBL_IC_Left 
		 * GLBL_IC_Top
		 * GLBL_IC_HorizontalRes
		 * GLBL_IC_VerticalRes
		 * 
		 * Returns:
		 * String GLBL_IC_ImagePath = This is the path where the Screenshots are being saved.  This is the results folder for the specific run
		 * 
		 * usage:
		 * String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980")
		 */
		// setup screenshot related global variables
		String GLBL_IC_Left = PAR_GLBL_IC_Left;
		String GLBL_IC_Top = PAR_GLBL_IC_Top; 
		String GLBL_IC_HorizontalRes = PAR_GLBL_IC_HorizontalRes; 
		String GLBL_IC_VerticalRes = PAR_GLBL_IC_VerticalRes ;

		getVariables().set("GLBL_IC_Left", GLBL_IC_Left, Variables.Scope.GLOBAL);
		getVariables().set("GLBL_IC_Top", GLBL_IC_Top, Variables.Scope.GLOBAL);
		getVariables().set("GLBL_IC_HorizontalRes", GLBL_IC_HorizontalRes, Variables.Scope.GLOBAL);
		getVariables().set("GLBL_IC_VerticalRes", GLBL_IC_VerticalRes, Variables.Scope.GLOBAL);
		// this is old code - String GLBL_IC_ImagePath = "c:\\oracle\\OracleATS\\OFT\\GCSS-MC\\TS_04-MaterialDistribution\\results\\";
		String GLBL_IC_ImagePath = getSettings().get("oats_session_result_dir")+"\\";
		getVariables().set("GLBL_IC_ImagePath", GLBL_IC_ImagePath, Variables.Scope.GLOBAL);
		
		return GLBL_IC_ImagePath;
	} // end of setupScreenshotParameters
	
	
	public String getReceiptDueQuantity(int PAR_LineNumber) throws Exception
	{
		/*
		 * this gets the due quantity in the receipt form and returns that number as a string value
		 */
		String myReceiptDueQuantity = "0";
		
		// first check if the field is alredy on the screen
		while(true)
		{
		if(forms.textField(71,
		"//forms:textField[(@name='RCPT_BLK_DUE_IN_QTY_"+PAR_LineNumber+"')]").exists())
			break;
		else
			think(1.0);
		}
		
		myReceiptDueQuantity = forms.textField(71,
			"//forms:textField[(@name='RCPT_BLK_DUE_IN_QTY_"+PAR_LineNumber+"')]").getText().toString();
		
		return myReceiptDueQuantity;
	} // end of getReceiptDueQuantity
	
	
	public void clickOnEnterReceiptButton() throws Exception
	{
		while(true)
		{
			if (forms.button(68,
				"//forms:button[(@name='XXMC_DOCUMENT_HISTORY_V1_PERFORM_RECEIPT_0')]")
				.exists())
				break;
			else
				think(1.0);
		}
		forms.captureScreenshot(67);
		{
			think(1.0);
		}
		forms.button(68,
				"//forms:button[(@name='XXMC_DOCUMENT_HISTORY_V1_PERFORM_RECEIPT_0')]")
				.click(); // click on Enter Receipt button
		
		think(1.0);
	} // end of clickONEnterReceiptButton
	

	





private void enterManifestQuantity(int PAR_LineNumber, String PAR_ManifestQuantity) throws Exception
{
	// first check if manifest quantity is populated, if yes, then just invoike next_field
	String myCurrentManifestQuantity = null;
	
	while(true)
	{
	if(forms.textField(71,
	"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]").exists())
		break;
	else
		think(1.0);
	}
	
	myCurrentManifestQuantity = forms.textField(71,
		"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
		.getText();
	
	if (!myCurrentManifestQuantity.isEmpty())
	{
		forms.textField(71,
			"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD");
	
		return; // this means that a quantity was autmatically populated
	}
	else
	{
	forms.textField(71,
	"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
	.setText(PAR_ManifestQuantity);
	
	forms.textField(71,
			"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // manifest quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
	} // end of else
	
} // end of enterManifestQuantity

private void enterReceiptQuantity(int PAR_LineNumber, String PAR_ReceiptQuantity) throws Exception
{

	forms.textField(72,
		"//forms:textField[(@name='RCPT_BLK_REC_QTY_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptQuantity);
	
	forms.textField(72,
		"//forms:textField[(@name='RCPT_BLK_REC_QTY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptQuantity

public void enterReceiptSubinventory(int PAR_LineNumber, String PAR_ReceiptSubinventory) throws Exception
{

	forms.textField(76,
		"//forms:textField[(@name='RCPT_BLK_SUBINV_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptSubinventory);
	
	forms.textField(76,
		"//forms:textField[(@name='RCPT_BLK_SUBINV_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptQuantity


public void enterReceiptLocator(int PAR_LineNumber, String PAR_ReceiptLocator) throws Exception
{

	forms.textField(78,
		"//forms:textField[(@name='RCPT_BLK_LOCATOR_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptLocator);
	
	forms.textField(78,
		"//forms:textField[(@name='RCPT_BLK_LOCATOR_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptLocator

public void enterReceiptItemSerialNumber(int PAR_LineNumber, String PAR_ReceiptItemSerialNumber) throws Exception
{
	// check first if the serial number field is editable.  if yes then use the parameter serial number
	// if the serial number is not editable, it means that there is a serial number already entered.
	forms.textField(80,
	"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
	.click(); // serial number field
	
	if (!forms.textField(80,
	"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]").isEditable())
		return;
	
	/*
	forms.textField(80,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptItemSerialNumber);
	*/
	generateMaterialReceiptSerialNumber(0);
	
	forms.textField(80,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptLocator

public String generateMaterialReceiptSerialNumber(int PAR_LineNumber) throws Exception
{
	String mySerialNumber = null;
	
	/*
	 * This function is for the Meterial Receipt function 
	 * 
	 * 	this function clicks on the generate serial number menu item (actions|Generate SerialNumber) that will generate 
	 * a serial number.
	 * 
	 * by this using function, a serial number populates the serial number of the current material line.
	 * 
	 * Parameters:
	 * PAR_LineNumber = this is the line number of the receipt you are processing. Typically, 0
	 * 
	 * returns the generate serial number
	 * usage:
	 * String mySerialNumber = generateMaterialReceiptSerialNumber(0);

	 */
	

	{
		think(1.0);
	}
	/*
	forms.window(2279, "//forms:window[(@name='MAIN_WINDOW')]")
			.clickToolBarButton("Generate Serial Number"); // I click on the generate serial number
	*/
	forms.window(46, "//forms:window[(@name='RCPT_WIN')]").selectMenu(
    "Actions|Generate Serial Number");
    
	{
		think(1.0);
	}
	// make sure that the serial number has been generated.
	forms.textField(
		2278,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	forms.textField(
		2278,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.setFocus();
	 mySerialNumber = forms.textField(
			2278,
			"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
			.getText();
	 info("serial number generated ===>"+mySerialNumber);
	while(true)
	{
	 mySerialNumber = forms.textField(
					2278,
					"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
					.getText();
	 
	 
	if (!mySerialNumber.isEmpty())
	{
		getVariables().set("GLBL_SerialNumber", mySerialNumber);
		break;
	}
	else
		think(1.0);
	}
	
	return mySerialNumber;
	
}// end of generateMaterialReceiptSerialNumber

public void clickOnEnterReceiptSubmitButton() throws Exception
{
	{
		think(1.0);
	}
	forms.button(82, "//forms:button[(@name='BTN_BLK_DONE_BTN_0')]")
			.click(); // this is the submit button
	{
		think(1.0);
	}
}

private void pauseForAMoment(int timeInSeconds) throws Exception {
	int myWaitTime = timeInSeconds / 5;
	do {
		think(5.0);
		myWaitTime--;
	} while (myWaitTime >= 0);

} // end of pauseForAMoment

public boolean checkIfDRAandD6TExist(String GLBL_SDNNumber) throws Exception
{
	// use this function to check if DRA and D6T exists in the receipt line
	// usage: checkIfDRAandD6TExist()
	// returns true when the lines already were created
	boolean CodeIdentifierExist = false;
	
	while(!CodeIdentifierExist)
	{
		// close the receipt window first
		closeEnterReceiptWindow();
		// wait for a moment
		delay(5000);
		// search for the SDN number
		EnterSDNNumberAndClickFindButton(GLBL_SDNNumber);
		// wait for a moment
		delay(5000);
		CodeIdentifierExist = checkIfCodeIdentifierExist(0, "DRA");
		if (!CodeIdentifierExist)
			CodeIdentifierExist=checkIfCodeIdentifierExist(1, "DRA");
		
		if (CodeIdentifierExist)
			CodeIdentifierExist=checkIfCodeIdentifierExist(0, "D6T");
		if (!CodeIdentifierExist)
			CodeIdentifierExist=checkIfCodeIdentifierExist(1, "D6T");
		
		think(1.0);
	}
	
	forms.captureScreenshot(32);
	{
		think(1.0);
	}
	{
		closeEnterReceiptWindow();
	}
	
	return CodeIdentifierExist;
} // end of checkIfDRAandD6TExist

private boolean checkIfCodeIdentifierExist(int PAR_LineNumber, String PAR_DocumentIdentifier) throws Exception
{
	// use this function to check if DRA or D6T or any code exists in the receipt line
	// usage: checkIfCodeIdentifierExist(PAR_LineNumber,PAR_DocumentIdentifier)
	// checkIfCodeIdentifierExist(0, "DRA")
	// checkIfCodeIdentifierExist(1, "D6T")
	// checkIfCodeIdentifierExist(99,"AST"
	boolean CodeIdentifierExist = false;
	String myDocumentIdentifier = null;
	
	if (PAR_LineNumber==99)
	{
		PAR_LineNumber=0;
		while (true)
		{
			myDocumentIdentifier = forms.textField(33,
				"//forms:textField[(@name='XXMC_DOCUMENT_HISTORY_V2_DOCUMENT_IDENTIFIER_"+PAR_LineNumber+"')]")
				.getText();
			if (myDocumentIdentifier.isEmpty())
			{
				CodeIdentifierExist = false;
				PAR_LineNumber = 99;
				break;
			}
			if(myDocumentIdentifier.equals(PAR_DocumentIdentifier))
			{
				CodeIdentifierExist = true;
				PAR_LineNumber = 99;
				break;
			}
			else
			{
				PAR_LineNumber++;
			}
		}
	}
	if (PAR_LineNumber==99)
		return CodeIdentifierExist;

	myDocumentIdentifier = forms.textField(33,
			"//forms:textField[(@name='XXMC_DOCUMENT_HISTORY_V2_DOCUMENT_IDENTIFIER_"+PAR_LineNumber+"')]")
			.getText();
	
	if(myDocumentIdentifier.equals(PAR_DocumentIdentifier))
		CodeIdentifierExist = true;
	

	forms.captureScreenshot(32);
	{
		think(1.0);
	}
	
	return CodeIdentifierExist;
} // end of checkIfCodeIdentifierExist

public void closeEnterReceiptWindow() throws Exception
{
	{
		think(1.0);
	}
	forms.window(35, "//forms:window[(@name='MAIN_WIN')]").close(); // close the receipt window
	{
		think(1.0);
	}
} // end of closeEnterReceiptWindow

public void EnterSDNNumberAndClickFindButton(String PAR_SDNNumber) throws Exception
{
	while(true)
	{
	if (forms.textField(63, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.exists())
		break;
	else
		think(1.0);
	}
	
			forms.textField(63, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.setText(PAR_SDNNumber); // enter the carcass number
			{
				think(0.003);
			}
			forms.textField(64, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(1.0);
			}
			forms.captureScreenshot(62);
			{
				think(1.0);
			}
			forms.button(65, "//forms:button[(@name='FIND_BLK_FIND_0')]")
					.click(); // click on the find button
			
			think(1.0);
}	// end of EnterSDNNumberAndClickFindButton

private String getRequestIDNumber(String PAR_myString) throws Exception {
	/*
	 * Synopsis this function parses the requestIDNumber from the alert
	 * message that has the request id number this is normally called by the
	 * function getRequestIDThenClickButton() but it can be used whenever
	 * you need to parse a number from any string
	 * 
	 * @param PAR_myString - This is a string to parse the number from
	 * 
	 * @return requestID or the number in the string in String type
	 * 
	 * manny gochuico for CACI
	 */
	final StringBuilder requestID = new StringBuilder(PAR_myString.length());
	for (int i = 0; i < PAR_myString.length(); i++) {
		final char x = PAR_myString.charAt(i);
		if (x > 47 && x < 58) {
			requestID.append(x);
		}
	}
	return requestID.toString();
} // end of getRequestIDNumber

private String getRequestIDThenClickButton(String PAR_buttonLabel) throws Exception {
	/*
	 * Synopsis Whenever you submit a concurrent request, Oracle EBS
	 * displays a choice dialog box with the concurrent Request ID and 1 or 2
	 * buttons, Yes or No or OK. Use this function to save the request ID in a
	 * global variable GLBL_myRequestID and also return the value of
	 * requestID that you can use locally from the calling program
	 * 
	 * this function calls another function called
	 * getRequestIDNumber(myAlertmessage) that Septemberarates the request number
	 * from the rest of the string text.
	 * 
	 * call this function to replace the clicking of the Yes or No button in
	 * the choice dialog box
	 * 
	 * @param: PAR_buttonLabel - valid values "Yes" to click on the Yes
	 * button and "No" to click on the "No" button
	 * 
	 * @return: the RequestID number and also sets the global variable
	 * GLBL_myRequestID to the value of the requestID
	 * 
	 * You would normally add your actions for either No button Click or Yes
	 * button click after calling this function. 
	 * Manny Gochuico 
	 */
	String myRequestID = null;

	beginStep(
		"[1] get RequestID then click button",
		0);
	{

		forms.captureScreenshot(80);
		{
			think(1.0);
		}
		String myAlertMessage = forms.choiceBox(81, "//forms:choiceBox").getAlertMessage();
		
		myRequestID = getRequestIDNumber(myAlertMessage);
		
		info("Request Number is " + myRequestID);
		
		getVariables().set( "GLBL_myRequestID",myRequestID,Variables.Scope.GLOBAL);
		forms.choiceBox(81,"//forms:choiceBox").clickButton(PAR_buttonLabel);

		think(2.0);

	}
	endStep();

	return myRequestID;
} // end of getRequestIDThenClickButton

public void selectInventoryOrganization(String PAR_InventoryOrg) throws Exception
{
	/*
	 * selects the inventory org from the popup dialog box
	 * 
	 * usage:selectInventoryOrganization("MRA|MMFAF7");
	 */
	
	
	while(true)
	{
		if (forms.listOfValues(21, "//forms:listOfValues").exists(20,TimeUnit.SECONDS))
			break;
		else
			delay(2000);
	}
	

	
	forms.captureScreenshot(20);
	{
		think(1.0);
	}

	//forms.listOfValues(21, "//forms:listOfValues").select(PAR_InventoryOrg); // select organization list of values
	forms.listOfValues(20, "//forms:listOfValues").find("%"+PAR_InventoryOrg+"%");
	
	delay(1000);
} // end of selectInventoryOrganization
	

}
