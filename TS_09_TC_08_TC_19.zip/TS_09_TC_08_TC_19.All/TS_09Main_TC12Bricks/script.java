import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;
	@ScriptService oracle.oats.scripting.modules.datatable.api.DataTableService datatable;

	public void initialize() throws Exception {
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
	

	}

	public void finish() throws Exception {
	}
	
	public void workingBanner() throws Exception
	{
		{
			web.window(1290,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					.waitForPage(null);
			{
				think(1.0);
			}
			web.button(
					1292,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
					.click();
			
			think(1.0);
		}
	} // end of workingBanner
	
	public boolean waitForEBSFormsToShowUp() throws Exception
	{
		// after clicking on the navigation items, there could be a wait for more than 2 minutes
		// this will loop until the navigator form shows up 
		
		while(true)
		{
			if (forms.window(31, "//forms:window[(@name='NAVIGATOR')]").exists())
				break;
			else
				think(5.0);
		}
		
		return true;
	} // end of waitForEBSFormsToShowUp
	
	public void closeFindRequestForm() throws Exception
	{
				forms.captureScreenshot(1279);
				{
					think(1.0);
				}
				forms.window(1280,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.close(); // close find service request form
				{
					think(1.0);
				}
	}	 // end closeFindRequestForm
	
	public void closeDebriefForm() throws Exception
	{
				{
					think(1.0);
				}
				forms.window(86, "//forms:window[(@name='MAIN_WINDOW')]").close(); // close debrief window
				{
					think(1.0);
				}
				forms.window(87,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.activate(true); // Ths is the SR tracking form
	}	 // end of closeDebriefForm	
	
	public void closeSRTrackingForm() throws Exception
	{
				{
					think(1.0);
				}
				forms.window(869,
				"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]").close(); // close debrief window
				{
					think(1.0);
				}
				forms.window(870, "//forms:window[(@name='NAVIGATOR')]")
						.activate(true); // activate the navigator 
	}	 // end of closeSRTrackingForm	
	
	public void activateSRTrackingForm() throws Exception
	{

				{
					think(1.0);
				}
				forms.window(866,
				"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.activate(true); // activate the navigator 
	}	 // end of activateSRTrackingForm	
	
	

	
	public void enterDebriefServiceActivityCode(String PAR_ServiceActivityCode, int PAR_LineNumber) throws Exception
	{
				{
					think(1.0);
				}
				while (true)
				{
				if (forms.textField(
						65,
						"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
						.exists())
					break;
				else
					think(1.0);
				}
				
				// set focus on the service activity code
				forms.textField(
					65,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
					.click();
					delay(1000);
				// make sure the service activity code is editable
				while(true)
				{
					if (forms.textField(
					65,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
					.isEditable())
						break;
					else
						delay(2000);
				}
				// the field is now editable so start filling it up.
				forms.textField(
					65,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
					.setText(PAR_ServiceActivityCode);
				
				forms.textField(
						65,
						"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
						.invokeSoftKey("NEXT_FIELD"); // Service Activity Cod
				think(1.0);
				
	} // end of enterServiceActivityCode
	
	public void clickOnMaterialTab() throws Exception
	{
				{
					think(1.0);
				}
				while(true)
				{
				if (forms.tab(63, "//forms:tab[(@name='DEBRIEF_LINES')]").exists())
					break;
				else
					think(1.0);
				}
				
				forms.tab(63, "//forms:tab[(@name='DEBRIEF_LINES')]").select(
						"Material"); // click on material tab
				{
					think(1.0);
				}
				while(true)
				{
					if (forms.textField(
					1532,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_0')]")
					.exists())
						break;
					else
						think(1.0);
				}
				forms.textField(
					1532,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_0')]")
					.setFocus();

	} // end of clickOnMaterialTab
	
	public void clickOnDebriefMaterialTab() throws Exception
	{
				{
					think(1.0);
				}
				while(true)
				{
				if (forms.tab(63, "//forms:tab[(@name='DEBRIEF_LINES')]").exists())
					break;
				else
					think(1.0);
				}
				
				forms.tab(63, "//forms:tab[(@name='DEBRIEF_LINES')]").select(
						"Material"); // click on material tab
				{
					think(1.0);
				}
				while(true)
				{
					if (forms.textField(
					1532,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_0')]")
					.exists())
						break;
					else
						think(1.0);
				}
				forms.textField(
					1532,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_0')]")
					.setFocus();

	} // end of clickOnDebriefMaterialTab
	
	public void clickOnDebriefLaborTab() throws Exception
	{
				{
					think(1.0);
				}
				while(true)
				{
				if (forms.tab(63, "//forms:tab[(@name='DEBRIEF_LINES')]").exists())
					break;
				else
					think(1.0);
				}
				
				forms.tab(81, "//forms:tab[(@name='DEBRIEF_LINES')]").select(
				"Labor"); // click on labor tab
				{
					think(2.0);
				}
				while(true)
				{
					if (forms.textField(199,
					"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_TRANSACTION_TYPE_0')]")
					.exists())
						break;
					else
						think(1.0);
				}
				forms.textField(199,
				"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_TRANSACTION_TYPE_0')]")
				.setFocus();

	} // end of clickOnDebriefLaborTab
	
	public void enterLaborServiceActivityCode(String PAR_LaborServiceActivityCode, int PAR_LineNumber) throws Exception
	{
		/*
		 * usage:
		 * enterLaborServiceActivityCode("Military",0);
		 * 
		 */
		// check if the field is editable
		while (true)
			{
			if (forms.textField(199,
			"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
			.isEditable())
				break;
			else
			{
				info("waiting for Service Activity Type to be editable...");
				delay(2000);
			}
			} // end while (true)
		
		forms.textField(199,
		"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_TRANSACTION_TYPE_"+PAR_LineNumber+"')]")
		.setText(PAR_LaborServiceActivityCode);
		
		delay(1000);
	} // end of enterLaborServiceActivityCode
	
public void enterLaborStartTime(String PAR_LaborStartTime, int PAR_LineNumber) throws Exception
	{
		/*
		 * parameters
		 * PAR_LaborStartTime - must be rendered in 24 hour format
		 * 
		 * usage:
		 * enterLaborStartTime("08:15",0);
		 * 
		 */
		// check if the field is editable
		while (true)
			{
			if (forms.textField(200,
			"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_LABOR_START_DATE_"+PAR_LineNumber+"')]")
			.isEditable())
				break;
			else
			{
				info("waiting for Start time Field to be editable...");
				delay(2000);
			}
			} // end while (true)
		
		forms.textField(200,
		"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_LABOR_START_DATE_"+PAR_LineNumber+"')]")
		.setText(PAR_LaborStartTime);
		
		delay(1000);
	} // end of enterLaborStartTime
	
public void enterLaborEndTime(String PAR_LaborEndTime, int PAR_LineNumber) throws Exception
{
	/*
	 * parameters
	 * PAR_LaborEndTime - must be rendered in 24 hour format
	 * 
	 * usage:
	 * enterLaborEndTime("15:30",0);
	 * 
	 */
	// check if the field is editable
	while (true)
		{
		if (forms.textField(202,
		"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_LABOR_END_DATE_"+PAR_LineNumber+"')]")
		.isEditable())
			break;
		else
		{
			info("waiting for End time Field to be editable...");
			delay(2000);
		}
		} // end while (true)
	
	forms.textField(202,
	"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_LABOR_END_DATE_"+PAR_LineNumber+"')]")
	.setText(PAR_LaborEndTime);
	
	delay(1000);
} // end of enterLaborEndTime

public boolean enterLaborDuration(String PAR_LaborDuration, int PAR_LineNumber) throws Exception
{
	/*
	 * parameters
	 * PAR_LaborDuration - must be rendered in 24 hour format
	 * 
	 * usage:
	 * enterLaborDuration("7:25",0);
	 * 
	 * Note:
	 * Labor duration is automatically calculated if start time and end time had been entered. Befor populating
	 * this field, it will check if the Duration field has a value, if yes,that value will not be replaced
	 * and this function exits with a return value of false.
	 * 
	 * If the Duration field was populated by this function, then the return value will be true
	 */
	
	boolean DurationAlreadyExist = false;
	
	// check if the field is editable
	while (true)
		{
		if (forms.textField(205,
		"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_QUANTITY_"+PAR_LineNumber+"')]")
		.isEditable())
			break;
		else
		{
			info("waiting for Duration Field to be editable...");
			delay(2000);
		}
		} // end while (true)
	
	// check if there is a value in the field
	String myCurrentDuration = forms.textField(205,
	"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_QUANTITY_"+PAR_LineNumber+"')]").getText();
	
	if (!myCurrentDuration.isEmpty())
	{
		info("There is an existing calculated Duration - "+myCurrentDuration);
		return DurationAlreadyExist;
	}
	
	// to get here means that Duration field is empty so replace it with the parameter
	forms.textField(205,
	"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_QUANTITY_"+PAR_LineNumber+"')]")
	.setText(PAR_LaborDuration);
	
	info("Duration field replaced by parameter - "+PAR_LaborDuration);
	delay(1000);
	DurationAlreadyExist = true;
	
	return DurationAlreadyExist;
} // end of enterLaborDuration


public void enterLaborItemType(String PAR_LaboritemType, int PAR_LineNumber) throws Exception
{
	/*
	 * parameters
	 * PAR_LaborEndTime - must be rendered in 24 hour format
	 * 
	 * usage:
	 * enterLaborItemType("LABOR",0);
	 * 
	 */
	// check if the field is editable
	while (true)
		{
		if (forms.textField(202,
		"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_ITEM_NUMBER_"+PAR_LineNumber+"')]")
		.isEditable())
			break;
		else
		{
			info("waiting for Item Type Field to be editable...");
			delay(2000);
		}
		} // end while (true)
	
	forms.textField(202,
		"//forms:textField[(@name='CSF_DEBRIEF_LABOR_LINES_ITEM_NUMBER_"+PAR_LineNumber+"')]")
		.setText(PAR_LaboritemType);
	
	delay(1000);
} // end of enterLaborItemType


public void enterDebriefLaborRecord(int PAR_LineNumber,
									String PAR_LaborServiceActivityCode,
									String PAR_LaborStartTime,
									String PAR_LaborEndTime,
									String PAR_LaborDuration,
									String PAR_LaboritemType) throws Exception
	{
	/*
	 * This is for TC_17 - step 2 and step 6
	 * 
	 * usage:
	 * enterDebriefLaborRecord(0, "Military", "08:50", "15:30", "7:25", "LABOR"
	 */
	enterLaborServiceActivityCode( PAR_LaborServiceActivityCode,  PAR_LineNumber);
	enterLaborStartTime( PAR_LaborStartTime,  PAR_LineNumber);
	enterLaborEndTime( PAR_LaborEndTime,  PAR_LineNumber);
	enterLaborDuration( PAR_LaborDuration,  PAR_LineNumber);
	enterLaborItemType( PAR_LaboritemType,  PAR_LineNumber);
	
	// click on the Save button
	clickOnDebriefMaterialSaveButton();
	
	} // end of enterDebriefLaborRecord

	
	public void clickOnDebriefButton() throws Exception
	{
				{
					think(1.0);
					
				}
				forms.button(57, "//forms:button[(@name='CREATE_TASK_DEBRIEF_0')]")
						.click(); // click on the debrief button
				{
					think(1.0);
				}
				while(true)
				{
				if (forms.spreadTable(61,"//forms:spreadTable[(@name='MASTER_GRID_0')]").exists())
					break;
				else
					think(1.0);
				}
				forms.spreadTable(61,"//forms:spreadTable[(@name='MASTER_GRID_0')]").focusRow(1);
	} // end of clickOnDebriefButton
	
	public void clickOnTaskTab() throws Exception
	{
				forms.captureScreenshot(36);
				{
					think(1.0);
				}
				forms.tab(37, "//forms:tab[(@name='SR_CANVASES')]").select("Tasks"); // click on the task tab
				{
					think(1.0);
				}
				
				while(true)
				{
					if (forms.spreadTable(38,
						"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
						.exists())
						break;
					else
						think(1.0);
				}
				forms.spreadTable(38,
						"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
						.focusRow(1);
				{
					think(1.0);
				}
	} // end of clickOnTaskTab
	
	public boolean FindServiceRequest(String PAR_ServiceRequestNumber) throws Exception
	{
		// returns true if SR exist
		// return false if SR does not exist
	
				forms.captureScreenshot(23);
				{
					think(1.0);
				}

				// ++++++++++ ENTER SEARCH CRITERIA HERE +++++++++++++++++++++++
				enterFindSRSearchCriteriaBy_SRNumber(PAR_ServiceRequestNumber);
				// ++++++++++ END OF SEARCH CRITERIA ++++++++++++++++++++++++++
				// click on the Search button
				forms.captureScreenshot(31);
				{
					think(1.0);
				}
				forms.button(32, "//forms:button[(@name='CS_FIND_MAIN_SEARCH_0')]")
						.click(); // click on the search button
				{
					think(1.0);
				}
				while(true)
				{
				if (forms.spreadTable(39,
				"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]").exists())
					break;
				else
					think(1.0);
				}
				if (forms.spreadTable(39,
				"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]").isEnabled())
					return true;
				else
					return false;
	} // end of FindServiceRequest
	
	public boolean FindServiceRequest(String PAR_ServiceRequestNumber, String PAR_GLBL_IC_ImagePath) throws Exception
	{
		// This version of FindServiceRequest saves the screenshot in the folder defined by PAR_GLBL_IC_ImagePath parameter
		
		
		/*
		 * returns true if SR exist
		 * return false if SR does not exist
		 * parameters:
		 * String PAR_ServiceRequestNumber - SR Number to be searched
		 * String PAR_GLBL_IC_ImagePath - The path of the folder where the images will be saved
		 */
	
				forms.captureScreenshot(23);
				{
					think(201.33);
				}
				forms.textField(24,
						"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_NUMBER_0')]")
						.setText(PAR_ServiceRequestNumber);
				
				// click on the Search button
				forms.captureScreenshot(31);
				{
					think(1.0);
				}
				
				ScreenShot(false,true,PAR_GLBL_IC_ImagePath+"01_SearchServiceRequest.jpg");
				
				forms.button(32, "//forms:button[(@name='CS_FIND_MAIN_SEARCH_0')]")
						.click(); // click on the search button
				{
					think(1.0);
				}
				while(true)
				{
				if (forms.spreadTable(39,
				"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]").exists())
					break;
				else
					think(1.0);
				}
				if (forms.spreadTable(39,
				"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]").isEnabled())
					return true;
				else
					return false;
	} // end of FindServiceRequest

	public void enterFindSRSearchCriteriaBy_SRNumber(String PAR_SRNumber) throws Exception
	{
		forms.textField(34,
		"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_NUMBER_0')]").setText(PAR_SRNumber);
		
		think(1.0);
	}
	public void enterFindSRSearchCriteriaBy_IncidentType(String PAR_IncidentType) throws Exception
	{
		forms.textField(35,
		"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_TYPE_0')]").setText(PAR_IncidentType);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_IncidentStatus(String PAR_IncidentStatus) throws Exception
	{
		forms.textField(36,
		"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_STATUS_0')]").setText(PAR_IncidentStatus);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_OwnerType(String PAR_OwnerType) throws Exception
	{
		forms.textField(37,
		"//forms:textField[(@name='SR_BSC_QUERY_RESOURCE_TYPE_NAME_0')]").setText(PAR_OwnerType);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_Owner(String PAR_Owner) throws Exception
	{
		forms.textField(225,
		"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_OWNER_0')]").setText(PAR_Owner);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_GroupName(String PAR_GroupName) throws Exception
	{
		forms.textField(226,
		"//forms:textField[(@name='SR_BSC_QUERY_GROUP_NAME_0')]").setText(PAR_GroupName);
		
		think(1.0);
	}
	public void enterFindSRSearchCriteriaBy_SiteName(String PAR_SiteName) throws Exception
	{
		forms.textField(229,
		"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_ADDR_SITE_NAME_0')]").setText(PAR_SiteName);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_SiteNumber(String PAR_SiteNumber) throws Exception
	{
		forms.textField(230,
		"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_ADDR_SITE_NUMBER_0')]").setText(PAR_SiteNumber);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_SubjectItem(String PAR_SubjectItem) throws Exception
	{
		forms.textField(234,
		"//forms:textField[(@name='SR_BSC_QUERY_PRODUCT_NAME_0')]").setText(PAR_SubjectItem);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_Description(String PAR_Description) throws Exception
	{
		forms.textField(235,
		"//forms:textField[(@name='SR_BSC_QUERY_PRODUCT_DESCRIPTION_0')]").setText(PAR_Description);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_Instance(String PAR_Instance) throws Exception
	{
		forms.textField(235,
		"//forms:textField[(@name='SR_BSC_QUERY_PRODUCT_DESCRIPTION_0')]").setText(PAR_Instance);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_SerialNumber(String PAR_SerialNumber) throws Exception
	{
		forms.textField(237,
		"//forms:textField[(@name='SR_BSC_QUERY_SERIAL_NUMBER_0')]").setText(PAR_SerialNumber);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_TaskNumber(String PAR_TaskNumber) throws Exception
	{
		forms.textField(238,
		"//forms:textField[(@name='SR_BSC_QUERY_TASK_NUM_0')]").setText(PAR_TaskNumber);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_TaskStatus(String PAR_TaskStatus) throws Exception
	{
		forms.textField(424,
		"//forms:textField[(@name='SR_BSC_QUERY_TASK_STATUS_0')]").setText(PAR_TaskStatus);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_TaskType(String PAR_TaskType) throws Exception
	{
		forms.textField(425,
		"//forms:textField[(@name='SR_BSC_QUERY_TASK_TYPE_0')]").setText(PAR_TaskType);
		
		think(1.0);
	}
	
	public void enterFindSRSearchCriteriaBy_TaskOwnerType(String PAR_TaskOwnerType) throws Exception
	{
		forms.textField(611,
		"//forms:textField[(@name='SR_BSC_QUERY_TASK_OWNER_TYPE_0')]").setText(PAR_TaskOwnerType);
		
		think(1.0);
	}
	
	
public boolean enterDebriefMaterialNIINNumber(String PAR_itemNumber, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the item number is not editable and function did not do its correct function
	 */
	// first make sure that the item number field is editable before continuing this function
	if (!forms.textField(1533,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+PAR_LineNumber+"')]")
			.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1533,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+PAR_LineNumber+"')]")
			.setText(PAR_itemNumber);
	{
		think(1.0);
	}
	forms.textField(1534,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // enterDebriefMaterialNIINNumber

public boolean enterDebriefMaterialUnitOfMeasure(String PAR_UnitOfMeasure, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the Field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(1772,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1772,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+PAR_LineNumber+"')]")
	.setText(PAR_UnitOfMeasure);
	{
		think(1.0);
	}
	forms.textField(1772,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+PAR_LineNumber+"')]")
	.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // enterDebriefMaterialUnitOfMeasure

public boolean enterDebriefMaterialQuantity(String PAR_Quantity, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the Field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(1773,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1773,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+PAR_LineNumber+"')]")
	.setText(PAR_Quantity);
	{
		think(1.0);
	}
	forms.textField(1773,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+PAR_LineNumber+"')]")
	.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterDebriefMaterialQuantity

public boolean enterDebriefMaterialOrg(String PAR_Org, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(1776,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1776,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+PAR_LineNumber+"')]")
	.setText(PAR_Org);
	{
		think(1.0);
	}
	forms.textField(1776,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+PAR_LineNumber+"')]")
	.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterDebriefMaterialOrg

public boolean enterDebriefMaterialSubinventoryCode(String PAR_SubinventoryCode, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(
		1778,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(
		1778,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+PAR_LineNumber+"')]")
	.setText(PAR_SubinventoryCode);
	{
		think(1.0);
	}
	forms.textField(
		1778,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterDebriefMaterialSubinventoryCode

public boolean enterDebriefMaterialLocator(String PAR_Locator, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(2009,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(2009,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+PAR_LineNumber+"')]")
	.setText(PAR_Locator);
	{
		think(1.0);
	}
	forms.textField(2009,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterDebriefMaterialLocator



public boolean enterDebriefMaterialSerialNumber(String PAR_SerialNumber, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(
		2276,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	info("Serial number checkpoint 1");
	// check if the serial number pass is blank.  if it is blank then we have to generate a serial number by 
	// clicking on the generate serial number
	if (PAR_SerialNumber == null)
	{
		generateMaterialReceiptSerialNumber(PAR_LineNumber);
		info("Serial Number checkpoint 2");
	}
	else
	{
		forms.textField(
			2276,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
			.setText(PAR_SerialNumber);
		info("Serial Number checkpoint #3");
	}
	{
		think(1.0);
	}
	forms.textField(
		2276,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterMaterialSerialNumber

public boolean enterDebriefMaterialWRSCode(String PAR_WRSCode, int PAR_LineNumber) throws Exception
{
	/*
	 * usage:
	 * enterDebriefMaterialWRSCode("99",0);
	 * 
	 * returns true aftger completion
	 */
	// first make sure that the field is editable before continuing this function
	while(true)
	{
	if (forms.textField(
		2276,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_MATERIAL_MEANING_"+PAR_LineNumber+"')]")
		.isEditable())
		break;
	else
	{
		info("WRS Code field is not yet editable");
		delay(1000);
	}
	} // end of while(true)

	forms.textField(
		2276,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_MATERIAL_MEANING_"+PAR_LineNumber+"')]")
		.setText(PAR_WRSCode);
	{
		think(1.0);
	}
	return true;
} // end of enterDebriefMaterialWRSCode



public void generateMaterialSerialNumber(int PAR_LineNumber) throws Exception
{
	String mySerialNumber = null;
	
	// This is for the DEBRIEF functionlaity only
	// this function clicks on the generate serial number function that will generate a serial number.
	// by clicking on this function, a serial number opulates the serial number of the current material line.
	{
		think(1.0);
	}
	forms.window(2279, "//forms:window[(@name='MAIN_WINDOW')]")
			.clickToolBarButton("Generate Serial Number"); // I click on the generate serial number
	{
		think(1.0);
	}
	// make sure that the serial number has been generated.
	forms.textField(
		2278,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	forms.textField(
		2278,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.setFocus();
	 mySerialNumber = forms.textField(
			2278,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
			.getText();
	 info("serial number generated ===>"+mySerialNumber);
	while(true)
	{
	 mySerialNumber = forms.textField(
					2278,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
					.getText();
	 
	 
	if (!mySerialNumber.isEmpty())
	{
		getVariables().set("GLBL_SerialNumber", mySerialNumber);
		break;
	}
	else
		think(1.0);
	}
}// end of generateMaterialSerialNumber

public String generateMaterialReceiptSerialNumber(int PAR_LineNumber) throws Exception
{
	String mySerialNumber = null;
	
	/*
	 * This function is for the Meterial Receipt function 
	 * 
	 * 	this function clicks on the generate serial number menu item (actions|Generate SerialNumber) that will generate 
	 * a serial number.
	 * 
	 * by this using function, a serial number populates the serial number of the current material line.
	 * 
	 * Parameters:
	 * PAR_LineNumber = this is the line number of the receipt you are processing. Typically, 0
	 * 
	 * returns the generate serial number
	 * usage:
	 * String mySerialNumber = generateMaterialReceiptSerialNumber(0);

	 */
	

	{
		think(1.0);
	}
	/*
	forms.window(2279, "//forms:window[(@name='MAIN_WINDOW')]")
			.clickToolBarButton("Generate Serial Number"); // I click on the generate serial number
	*/
	forms.window(46, "//forms:window[(@name='RCPT_WIN')]").selectMenu(
    "Actions|Generate Serial Number");
    
	{
		think(1.0);
	}
	// make sure that the serial number has been generated.
	forms.textField(
		2278,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	forms.textField(
		2278,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
		.setFocus();
	 mySerialNumber = forms.textField(
			2278,
			"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
			.getText();
	 info("serial number generated ===>"+mySerialNumber);
	while(true)
	{
	 mySerialNumber = forms.textField(
					2278,
					"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
					.getText();
	 
	 
	if (!mySerialNumber.isEmpty())
	{
		getVariables().set("GLBL_SerialNumber", mySerialNumber);
		break;
	}
	else
		think(1.0);
	}
	
	return mySerialNumber;
	
}// end of generateMaterialReceiptSerialNumber


public void clickOnDebriefMaterialSaveButton() throws Exception
{
	{
		think(1.0);
	}
	forms.window(2280, "//forms:window[(@name='MAIN_WINDOW')]")
			.clickToolBarButton("Save");
	{
		delay(6000);
	}
} // clickOnMaterialSaveButton



public void saveDebriefCarcassAndReplacementSDN(int PAR_LineNumber) throws Exception
{
	/*
	 * this is called immediately after clicking the save button.  when you call this function, there are two global variables
	 * that are set:
	 * GLBL_CarcassNumber
	 * GLBL_ReplacementNumber
	 * 
	 * Save these numbers into arrays so that you can just call them when you need it.
	 */
	String myCarcassNumber = null;
	String myReplacementNumber = null;
	
	while(true)
	{
		// keep on doing this loop until the green bar shows up.  when the green bar shows up, save the carcass and
		// replacement SDN numbers and save them in openscript global variables that can be used for the next step 
		// after saving
		myCarcassNumber = forms.textField(2283,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_"+PAR_LineNumber+"')]")
		.getText();
		
		if (!myCarcassNumber.isEmpty())
			break;
		else
			think(1.0);
				
	}
	// save the carcass number
	myCarcassNumber = forms.textField(2283,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_"+PAR_LineNumber+"')]")
	.getText();
	getVariables().set("GLBL_CarcassNumber", myCarcassNumber);
	
	myReplacementNumber = forms.textField(2285,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORDER_SDN_"+PAR_LineNumber+"')]")
	.getText();
	getVariables().set("GLBL_ReplacementNumber", myReplacementNumber);
	

} // end of saveCarcassAndReplacementSDN

public void saveDebriefCarcassAndReplacementSDN(int PAR_LineNumber,
		String PAR_GLBL_IC_ImagePath,
		String PAR_ImageNumber) throws Exception
{
	/*
	 * this is called immediately after clicking the save button.  when you call this function, there are two global variables
	 * that are set:
	 * GLBL_CarcassNumber
	 * GLBL_ReplacementNumber
	 * 
	 * Save these numbers into arrays so that you can just call them when you need it.
	 * 
	 * This version of saveDebriefCarcassAndReplacementSDN incldes Screenshot processing
	 */
	String myCarcassNumber = null;
	String myReplacementNumber = null;
	
	while(true)
	{
		// keep on doing this loop until the green bar shows up.  when the green bar shows up, save the carcass and
		// replacement SDN numbers and save them in openscript global variables that can be used for the next step 
		// after saving
		myCarcassNumber = forms.textField(2283,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_"+PAR_LineNumber+"')]")
		.getText();
		
		if (!myCarcassNumber.isEmpty())
		{
			ScreenShot(false,true,PAR_GLBL_IC_ImagePath+PAR_ImageNumber+"_Carcass&Replacement.jpg");
			break;
		}
		else
			think(1.0);
				
	}
	// save the carcass number
	myCarcassNumber = forms.textField(2283,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_"+PAR_LineNumber+"')]")
	.getText();
	getVariables().set("GLBL_CarcassNumber", myCarcassNumber);
	
	myReplacementNumber = forms.textField(2285,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORDER_SDN_"+PAR_LineNumber+"')]")
	.getText();
	getVariables().set("GLBL_ReplacementNumber", myReplacementNumber);
	

} // end of saveCarcassAndReplacementSDN

public void enterTaskMaterialDebrief(int PAR_LineNumber,
									String PAR_ServiceActivityCode,
									String PAR_itemNumber,
									String PAR_UnitOfMeasure,
									String PAR_Quantity,
									String PAR_Org,
									String PAR_SubinventoryCode,
									String PAR_Locator,
									String PAR_SerialNumber) throws Exception
{
	enterDebriefServiceActivityCode( PAR_ServiceActivityCode,PAR_LineNumber );
	enterDebriefMaterialNIINNumber( PAR_itemNumber,  PAR_LineNumber);
	enterDebriefMaterialUnitOfMeasure( PAR_UnitOfMeasure,  PAR_LineNumber);
	enterDebriefMaterialQuantity( PAR_Quantity,  PAR_LineNumber);
	enterDebriefMaterialOrg( PAR_Org,  PAR_LineNumber);
	enterDebriefMaterialSubinventoryCode( PAR_SubinventoryCode,  PAR_LineNumber);
	enterDebriefMaterialLocator( PAR_Locator,  PAR_LineNumber);
	enterDebriefMaterialSerialNumber( PAR_SerialNumber,  PAR_LineNumber);
	clickOnDebriefMaterialSaveButton();
	saveDebriefCarcassAndReplacementSDN( PAR_LineNumber);
	
} // end of enterTaskMaterialDebrief

public void enterTaskMaterialDebrief(int PAR_LineNumber,
		String PAR_ServiceActivityCode,
		String PAR_itemNumber,
		String PAR_UnitOfMeasure,
		String PAR_Quantity,
		String PAR_Org,
		String PAR_SubinventoryCode,
		String PAR_Locator,
		String PAR_SerialNumber,
		String PAR_GLBL_IC_ImagePath,
		String PAR_ImageNumber) throws Exception
{
	/*
	 * use this function to get the screenshot of the screens and save it in the folder defined by the 
	 * PAR_GLBL_IC_ImagePath parameter
	 */
enterDebriefServiceActivityCode( PAR_ServiceActivityCode,PAR_LineNumber );
enterDebriefMaterialNIINNumber( PAR_itemNumber,  PAR_LineNumber);
enterDebriefMaterialUnitOfMeasure( PAR_UnitOfMeasure,  PAR_LineNumber);
enterDebriefMaterialQuantity( PAR_Quantity,  PAR_LineNumber);
enterDebriefMaterialOrg( PAR_Org,  PAR_LineNumber);
enterDebriefMaterialSubinventoryCode( PAR_SubinventoryCode,  PAR_LineNumber);
enterDebriefMaterialLocator( PAR_Locator,  PAR_LineNumber);
enterDebriefMaterialSerialNumber( PAR_SerialNumber,  PAR_LineNumber);
ScreenShot(false,true,PAR_GLBL_IC_ImagePath+PAR_ImageNumber+"_TaskMaterialDebrief.jpg");
clickOnDebriefMaterialSaveButton();
saveDebriefCarcassAndReplacementSDN( PAR_LineNumber,PAR_GLBL_IC_ImagePath,PAR_ImageNumber);

} // end of enterTaskMaterialDebrief

public void enterTaskMaterialDebrief(int PAR_LineNumber,
		String PAR_ServiceActivityCode,
		String PAR_itemNumber,
		String PAR_UnitOfMeasure,
		String PAR_Quantity,
		String PAR_Org,
		String PAR_SubinventoryCode,
		String PAR_Locator,
		String PAR_SerialNumber,
		String PAR_WRSCode,
		String PAR_GLBL_IC_ImagePath,
		String PAR_ImageNumber) throws Exception
{
	/*
	 * This is normally used by TC_17, steps 8 and step 9
	 * 
	 * use this material debrief function when including WRS code in the debrief.
	 * 
	 * If the NIIN is not serialized, enter null for PAR_Serial number
	 * 
	 * usage: 
	 * enterTaskMaterialDebrief(0, "Issue from Inventory, "014745704","EA", "!","1CJ","01A","C000001AA",null,"99","C:\\OracleATS\\OFT\\Databank\\","05");
	 * function to get the screenshot of the screens and save it in the folder defined by the 
	 * PAR_GLBL_IC_ImagePath parameter
	 */
enterDebriefServiceActivityCode( PAR_ServiceActivityCode,PAR_LineNumber );
enterDebriefMaterialNIINNumber( PAR_itemNumber,  PAR_LineNumber);
enterDebriefMaterialUnitOfMeasure( PAR_UnitOfMeasure,  PAR_LineNumber);
enterDebriefMaterialQuantity( PAR_Quantity,  PAR_LineNumber);
enterDebriefMaterialOrg( PAR_Org,  PAR_LineNumber);
enterDebriefMaterialSubinventoryCode( PAR_SubinventoryCode,  PAR_LineNumber);
enterDebriefMaterialLocator( PAR_Locator,  PAR_LineNumber);
enterDebriefMaterialSerialNumber( PAR_SerialNumber,  PAR_LineNumber);
enterDebriefMaterialWRSCode( PAR_WRSCode,  PAR_LineNumber);
ScreenShot(false,true,PAR_GLBL_IC_ImagePath+PAR_ImageNumber+"_TaskMaterialDebrief.jpg");
clickOnDebriefMaterialSaveButton();
saveDebriefCarcassAndReplacementSDN( PAR_LineNumber,PAR_GLBL_IC_ImagePath,PAR_ImageNumber);

} // end of enterTaskMaterialDebrief

public void DebriefMultipleMaterialSDN(String PAR_DatabankName,
											String PAR_GLBL_IC_ImagePath,
											String PAR_ImageNumber) throws Exception
	{
	/*
	 * This is for TC_17 - step 4
	 * 
	 * This function allows multiple task material entry.
	 * it requires a databank to be read with the data to be used
	 * The databank must have the following fields
	 * - Service Activity Code (ServiceActivityCode)
	 * - NIIN (NIIN)
	 * - Unit of Measure (UnitOfMeasure)
	 * - Quantity (Quantity)
	 * - Inventory Org (InventoryOrg)
	 * - Subinventory Code (SubinventoryCode)
	 * - Subinventory locator (InventoryLocator)
	 * - WRS (WRS_Code)
	 * 
	 * your databank must look similar to this below (see MaterialsToDebrief.csv from manny's databank folder)
	 * ServiceActivityCode,NIIN,UnitOfMeasure,Quantity,InventoryOrg,SubinventoryCode,InventoryLocator,WRS_Code
	 * Issue from Inventory,014745704,EA,1,1CJ,01F,C000001AF,99
	 * Issue from Inventory,014787314,EA,1,1CJ,01F,X000001AF,99
	 * 
	 * parameters
	 * PAR_DatabankName - name of your .csv databank.  This must be located in a recognized repository
	 * PAR_GLBL_IC_ImagePath - this is the path where the images will be saved.  usually the results folder
	 * 
	 * dependencies
	 * 1) make sure you setup the screenshot environment to setup the global variable GLBL_IC_ImagePath 
	 * at the beginning of your script by calling:
	 * String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980");
	 * 2) your must have the Screenshot function in your program. (ScreenShot(boolean Web,boolean Forms, String ImageName))
	 * 
	 * psuedo code
	 * 1) read the databank and get the number of records to process
	 * 2) while there are records to process:
	 * 2.a) get the record values and assign them to an opensript variable
	 * 2.b) save the openscript variable into a java variable
	 * 2.c) enter the record
	 * 2.d) save the record and wait until the green bar comes on
	 * 2.e) loop and get the next record
	 * 
	 * many gochuico 6-21-2021
	 */

/*
* get the number of records in the databank
* 
*/
getDatabank(PAR_DatabankName).getNextDatabankRecord();
int numberOfRecordsToProcess = getDatabank(PAR_DatabankName).getDatabankRecordCount();
int MaterialLineNumber = 0;
String PAR_ServiceActivityCode = null;
String PAR_NIIN=null;
String PAR_UnitOfMeasure= null;
String PAR_Quantity= null;
String PAR_Org= null;
String PAR_SubinventoryCode = null;
String PAR_Locator= null;
String PAR_WRSCode=null;

int PAR_LineNumber = 0;

for (int currentRecord=1;currentRecord<=numberOfRecordsToProcess;currentRecord++)
{
	// get the record from the databank
	getDatabank(PAR_DatabankName).getRecord(currentRecord); // gets the first record
	// get the quantity and other information from the databank
	
	info("ServiceActivityCode Record beign read ---> "+String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}"));

	PAR_ServiceActivityCode=String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}");
	PAR_NIIN = String.valueOf("{{db."+PAR_DatabankName+".NIIN}}");
	PAR_UnitOfMeasure = String.valueOf("{{db."+PAR_DatabankName+".UnitOfMeasure}}");
	PAR_Quantity = String.valueOf("{{db."+PAR_DatabankName+".Quantity}}");
	PAR_Org = String.valueOf("{{db."+PAR_DatabankName+".InventoryOrg}}");
	PAR_SubinventoryCode = String.valueOf("{{db."+PAR_DatabankName+".PAR_SubinventoryCode}}");
	PAR_Locator = String.valueOf("{{db."+PAR_DatabankName+".InventoryLocator}}");
	PAR_WRSCode = String.valueOf("{{db."+PAR_DatabankName+".WRS_Code}}");


	// Manifest Quantity
	getVariables().set(PAR_ServiceActivityCode,
		String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}"), Variables.Scope.GLOBAL);
	// Receipt Quantity
	getVariables().set(PAR_NIIN,
		String.valueOf("{{db."+PAR_DatabankName+".NIIN}}"), Variables.Scope.GLOBAL);
	// Receipt Subinventory
	getVariables().set(PAR_UnitOfMeasure,
		String.valueOf("{{db."+PAR_DatabankName+".UnitOfMeasure}}"), Variables.Scope.GLOBAL);
	// Receipt Locator
	getVariables().set(PAR_Quantity,
		String.valueOf("{{db."+PAR_DatabankName+".Quantity}}"), Variables.Scope.GLOBAL);
	// Receipt Serial Number or null
	getVariables().set(PAR_Org,
		String.valueOf("{{db."+PAR_DatabankName+".InventoryOrg}}"), Variables.Scope.GLOBAL);
	getVariables().set(PAR_SubinventoryCode,
		String.valueOf("{{db."+PAR_DatabankName+".SubinventoryCode}}"), Variables.Scope.GLOBAL);
	getVariables().set(PAR_Locator,
		String.valueOf("{{db."+PAR_DatabankName+".InventoryLocator}}"), Variables.Scope.GLOBAL);
	getVariables().set(PAR_WRSCode,
		String.valueOf("{{db."+PAR_DatabankName+".WRS_Code}}"), Variables.Scope.GLOBAL);

	PAR_ServiceActivityCode=getVariables().get(PAR_ServiceActivityCode);
	PAR_NIIN = getVariables().get(PAR_NIIN);
	PAR_UnitOfMeasure = getVariables().get(PAR_UnitOfMeasure);
	PAR_Quantity = getVariables().get(PAR_Quantity);
	PAR_Org = getVariables().get(PAR_Org);
	PAR_SubinventoryCode = getVariables().get(PAR_SubinventoryCode);
	PAR_Locator = getVariables().get(PAR_Locator);
	PAR_WRSCode = getVariables().get(PAR_WRSCode);


	enterDebriefServiceActivityCode( PAR_ServiceActivityCode,PAR_LineNumber );
	enterMaterialNIINNumber( PAR_NIIN,  PAR_LineNumber);
	enterMaterialUnitOfMeasure( PAR_UnitOfMeasure,  PAR_LineNumber);
	enterMaterialQuantity( PAR_Quantity,  PAR_LineNumber);
	enterMaterialOrg( PAR_Org,  PAR_LineNumber);
	enterMaterialSubinventoryCode( PAR_SubinventoryCode,  PAR_LineNumber);
	enterMaterialLocator( PAR_Locator,  PAR_LineNumber);
	enterDebriefMaterialWRSCode( PAR_WRSCode,  PAR_LineNumber);
	ScreenShot(false,true,PAR_GLBL_IC_ImagePath+currentRecord+"_MultipleMaterialDebrief.jpg");


	PAR_LineNumber = PAR_LineNumber+1;
	
	// you have to take note that if more than 7 rows will be entered, the table should be scrolled up to accommodate
	// the new line
	if (PAR_LineNumber>7)
	{
	forms.textField(
		65,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_TRANSACTION_TYPE_7')]")
		.invokeSoftKey("NEXT_RECORD");
	// reset line number back to 7 after the scroll up
	PAR_LineNumber = 7;
	} // end of if ((PAR_LineNumber>7)
		
} // end of for 


clickOnDebriefMaterialSaveButton();
delay (10000); // wait for 10 seconds. 
// checkIfRecordIsGreen( PAR_LineNumber,PAR_GLBL_IC_ImagePath,Integer.toString(currentRecord));

// close debrief form
closeDebriefForm();
} // end of DebriefMultipleMaterialSDN
									
public void enterResponsiblity(String PAR_Responsiblity) throws Exception
{
	{
		web.window(1293, "/web:window[@index='0' or @title='Home']")
				.waitForPage(null);
		{
			think(1.0);
		}
		while (true)
		{
			if(web.element(
				1296,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"+PAR_Responsiblity+"' or @index='58']")
				.exists())
				break;
			else
				think(1.0);
		}
		web.element(
				1296,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"+PAR_Responsiblity+"' or @index='58']")
				.click();
	}
} // end of enterResponsiblity 
									


public void printDD_1348(String PAR_CarcassNumber) throws Exception
{
	// refresh the web page first to make sure the carcass number link is ready for clicking
	// check if the link already exist
	while (true)
	{
	web.window(8, "/web:window[@index='0' or @title='Home']").refresh();
	{
		delay(3000);
	}
	

	if (web.link(
			2291,
			"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:a[@text='DD-1348 for Document Number "+PAR_CarcassNumber+" is Ready for Printing' or @href='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/OA.jsp?OAFunc=FND_WFNTF_DETAILS&NtfId=648064979&addBreadCrumb=Y&retainAM=Y&_ti=1994290352&oapc=3&oas=Ed8bVUYIqRRYUWuUvI08rg..' or @index='277']")
			.exists())
		break;
	else
		delay(1000);
	}
	
	{
		think(1.0);
	}
	web.link(
			2291,
			"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:a[@text='DD-1348 for Document Number "+PAR_CarcassNumber+" is Ready for Printing' or @href='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/OA.jsp?OAFunc=FND_WFNTF_DETAILS&NtfId=648064979&addBreadCrumb=Y&retainAM=Y&_ti=1994290352&oapc=3&oas=Ed8bVUYIqRRYUWuUvI08rg..' or @index='277']")
			.click(); // click on the DD-1348 link (TC_12 5)
	
		web.window(2292,
			"/web:window[@index='0' or @title='Notification Details']")
			.waitForPage(null);
		{
			think(1.0);
		}
		
		while(true)
		{
			if (web.button(
				2295,
			"/web:window[@index='0' or @title='Notification Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='NtfClose' or @index='0']")
			.exists())
				break;
			else
				think(1.0);
		}
			web.button(
				2295,
			"/web:window[@index='0' or @title='Notification Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@id='NtfClose' or @index='0']")
			.click(); // click on the OK button to print (TC_12 5)
			
			think(1.0);
} // end of printDD_1348

public void printDD_1348(String PAR_CarcassNumber, String delimiterPattern) throws Exception {
	/*
	 * this function will parse the carcass number from a string delimited by a delimniter and then perform the printDD_1348 
	 * 
	 * usage
	 * printDD_1348(GLBL_CarcassNumberS, String delimiterPattern)
	 * 
	 * Manny Gochuico (CACI Intellectual Property) 2021
	 */
	// ++++++++++++ setup variables +++++++++++++++++++++
	boolean isThereAComma = false;
	int menuItemCounter = 0;
	String myNavigation = PAR_CarcassNumber;
	String charToSearch = delimiterPattern; // originally --> ",";
	List<String> menuItems = new ArrayList<String>();

	String repeatedString = null;
	boolean repeatedText = false;
	int repeatedCount = 0;



	// ++++++++++++ now parse the menu items +++++++++++++++++++
	for (int i = 0; i < myNavigation.length(); i++) {
		// check if ther eis a comma in the string
		int commaLocation = myNavigation.indexOf(
			charToSearch,
			i);
		info("commaLocaton ===> " + commaLocation);
		if (commaLocation > 0) {
			isThereAComma = true;
			String A = myNavigation.substring(
				i,
				commaLocation);
			menuItems.add(A);
			info(menuItems.get(
				menuItemCounter).toString());
			i = commaLocation;
			menuItemCounter++;
			info("the value of i is ==>" + i);

		} else {
			if (isThereAComma) {
				menuItems.add(myNavigation.substring(
					i,
					myNavigation.length()));
				info(menuItems.get(
					menuItemCounter).toString());
				break;
			} else {
				menuItems.add(myNavigation);
				info("NumberParsed ===> " + myNavigation);
				menuItemCounter++;
				break;
			}

		}
	}

	info("Now print each Carcass number");
	boolean allCarcassNumbersPrinted = false;

	for (int i = 0; i < menuItems.size(); i++) {
		String menuItem = menuItems.get(
			i).toString();
		// info(menuItems.get(i).toString());
		info (menuItem);
		
		


		printDD_1348(menuItem);
		
		info("("+i+") printed DD_1348 for ==> "+menuItem);				


		delay(18000);
		info("Checkpoint "+i+"a");
		// web.window(19, "/web:window[@index='0' or @title='Home']").waitForPage(null);
	{
	think(2.0);
	}
//info("GOING BACK TO THE FOR LOOP"); 
	}


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	} // end of printDD_1348


public boolean clickOnRedDD_1348DocumentIcon() throws Exception
{
	/*
	 * This brick clicks on the the Red document icon that is available when you are in the Shipping Transaction form
	 * 
	 * returns
	 * true - if the icon does exist, enabled  and it was successfully clicked
	 * false - if the red document icon does not exist or is not enabled
	 * 
	 * An equivalent function clickOnToolsGenerateDD1348 can be used instead of this
	 */
	// ensure that the icon button exist
	boolean redDocumentIconExist = false;
	
	if (!forms.window(665, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
		.exists())
			return redDocumentIconExist;
	
	// ensure that the icon is clickable
	if (!forms.window(665, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.isEnabled())
				return redDocumentIconExist;
	
	
	forms.window(665, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
	.clickToolBarButton("Generate DD-1348"); // click on red document icon
	{
		delay(2000);
	}
	
	redDocumentIconExist = true;
	
	return redDocumentIconExist;
} // end of clickOnRedDD_1348DocumentIcon


public boolean clickOnToolsGenerateDD1348() throws Exception
{
	/*
	 * This brick clicks on Tools>Generate DD-1348 that is available when you are in the Shipping Transaction form
	 * 
	 * returns
	 * true - if the icon does exist, enabled  and it was successfully clicked
	 * false - if the red document icon does not exist or is not enabled
	 * 
	 * An equivalent function clickOnRedDD_1348DocumentIcon can be used instead of this
	 */
	// ensure that the icon button exist
	boolean redDocumentIconExist = false;
	
	if (!forms.window(664, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
		.exists())
			return redDocumentIconExist;
	
	// ensure that the icon is clickable
	if (!forms.window(665, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.isEnabled())
				return redDocumentIconExist;
	
	
	forms.window(664, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
	.selectMenu("Tools|Generate DD-1348");
	{
		delay(2000);
	}
	
	redDocumentIconExist = true;
	
	return redDocumentIconExist;
} // end of clickOnToolsGenerateDD1348





public void selectInventoryOrganization(String PAR_InventoryOrg) throws Exception
{
	/*
	 * selects the inventory org from the popup dialog box
	 * 
	 * usage:selectInventoryOrganization("MRA|MMFAF7");
	 */
	if (!forms.listOfValues(21, "//forms:listOfValues").exists())
		return;
	
	forms.captureScreenshot(20);
	{
		think(1.0);
	}
	forms.listOfValues(21, "//forms:listOfValues").select(PAR_InventoryOrg); // select organization list of values
} // end of selectInventoryOrganization

public void selectInventoryOrganization(String PAR_InventoryOrg, String PAR_ImageName) throws Exception
{
	/*
	 * selects the inventory org from the popup dialog box then takes a screenshot
	 * 
	 * usage:selectInventoryOrganization("MRA|MMFAF7","01_SelectIventoryOrg");
	 */
	if (!forms.listOfValues(21, "//forms:listOfValues").exists())
		return;
	
	forms.captureScreenshot(20);
	{
		think(1.0);
	}
	forms.listOfValues(21, "//forms:listOfValues").select(PAR_InventoryOrg); // select organization list of values
	
	// take a screenshot
	
	ScreenShot(false,true,PAR_ImageName);
} // end of selectInventoryOrganization

public void EnterSDNNumberAndClickFindButton(String PAR_SDNNumber) throws Exception
{
	/*
	 * This function is used by the enter receipt process.  This is the form where the user enters the SDN number
	 * to recieve and then click on the find button
	 */
	forms.window(38, "//forms:window[(@name='FIND_WIN')]").activate(
		true); // this is the Find Document (Supply) form
	
	while(true)
	{
	if (forms.textField(63, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.exists())
		break;
	else
		think(1.0);
	}
	
			forms.textField(63, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.setText(PAR_SDNNumber); // enter the carcass number
			{
				think(0.003);
			}
			forms.textField(64, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.invokeSoftKey("NEXT_FIELD");
			{
				think(1.0);
			}
			forms.captureScreenshot(62);
			{
				think(1.0);
			}
			forms.button(65, "//forms:button[(@name='FIND_BLK_FIND_0')]")
					.click(); // click on the find button
			
			think(1.0);
}	// end of EnterSDNNumberAndClickFindButton

public void clickOnEnterReceiptButton() throws Exception
{
	/*
	 * This function is used to click on the Enter Receipt button in the Document Status supply form
	 */
	while(true)
	{
		if (forms.button(68,
			"//forms:button[(@name='XXMC_DOCUMENT_HISTORY_V1_PERFORM_RECEIPT_0')]")
			.exists())
			break;
		else
			think(1.0);
	}
	forms.captureScreenshot(67);
	{
		think(1.0);
	}
	forms.button(68,
			"//forms:button[(@name='XXMC_DOCUMENT_HISTORY_V1_PERFORM_RECEIPT_0')]")
			.click(); // click on Enter Receipt button
	
	think(1.0);
} // end of clickONEnterReceiptButton

public void enterReceiptSource(int PAR_LineNumber, String PAR_ReceiptSource) throws Exception
{
	// first check if Receipt Source is populated, if yes, then check if the value is the same as the parameter
	// if not then enter the PAR_ReceiptSource
	String myCurrentSource = null;
	
	while(true)
	{
	if(forms.textField(71,
	"//forms:textField[(@name='RCPT_BLK_SOURCE_"+PAR_LineNumber+"')]").exists())
		break;
	else
		think(1.0);
	}
	
	myCurrentSource = forms.textField(71,
		"//forms:textField[(@name='RCPT_BLK_SOURCE_"+PAR_LineNumber+"')]")
		.getText();
	
	if (!myCurrentSource.isEmpty())
	{
		// check the value of the Source. if equal to the parameter then tab to the next field. if no, then change
		if (myCurrentSource.equalsIgnoreCase(PAR_ReceiptSource))
			forms.textField(71,
			"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD");
	
		return; // this means that a quantity was autmatically populated
	}
	else
	{

	forms.textField(72,
		"//forms:textField[(@name='RCPT_BLK_SOURCE_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptSource);
	
	forms.textField(72,
		"//forms:textField[(@name='RCPT_BLK_SOURCE_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt Source
	}
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptSource

public String getReceiptDueQuantity(int PAR_LineNumber) throws Exception
{
	/*
	 * this gets the due quantity in the receipt form and returns that number as a string value
	 */
	String myReceiptDueQuantity = "0";
	
	// first check if the field is alredy on the screen
	while(true)
	{
	if(forms.textField(71,
	"//forms:textField[(@name='RCPT_BLK_DUE_IN_QTY_"+PAR_LineNumber+"')]").exists())
		break;
	else
		think(1.0);
	}
	
	myReceiptDueQuantity = forms.textField(71,
		"//forms:textField[(@name='RCPT_BLK_DUE_IN_QTY_"+PAR_LineNumber+"')]").getText().toString();
	
	return myReceiptDueQuantity;
} // end of getReceiptDueQuantity

public void enterManifestQuantity(int PAR_LineNumber, String PAR_ManifestQuantity) throws Exception
{
	/*
	 * This is the Enter Receipt Fomm Manifest Quantity
	 */
	// first check if manifest quantity is populated, if yes, then just invoike next_field
	String myCurrentManifestQuantity = null;
	
	while(true)
	{
	if(forms.textField(71,
	"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]").exists())
		break;
	else
		think(1.0);
	}
	
	myCurrentManifestQuantity = forms.textField(71,
		"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
		.getText();
	
	if (!myCurrentManifestQuantity.isEmpty())
	{
		forms.textField(71,
			"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD");
	
		return; // this means that a quantity was autmatically populated
	}
	else
	{
	forms.textField(71,
	"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
	.setText(PAR_ManifestQuantity);
	
	forms.textField(71,
			"//forms:textField[(@name='RCPT_BLK_MANIFEST_QUANTITY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // manifest quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
	} // end of else
	
} // end of enterManifestQuantity

public void enterReceiptQuantity(int PAR_LineNumber, String PAR_ReceiptQuantity) throws Exception
{
	/*
	 * This is used in the enter receipt Form
	 */

	forms.textField(72,
		"//forms:textField[(@name='RCPT_BLK_REC_QTY_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptQuantity);
	
	forms.textField(72,
		"//forms:textField[(@name='RCPT_BLK_REC_QTY_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptQuantity

public void enterReceiptSubinventory(int PAR_LineNumber, String PAR_ReceiptSubinventory) throws Exception
{

	forms.textField(76,
		"//forms:textField[(@name='RCPT_BLK_SUBINV_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptSubinventory);
	
	forms.textField(76,
		"//forms:textField[(@name='RCPT_BLK_SUBINV_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptQuantity


public void enterReceiptLocator(int PAR_LineNumber, String PAR_ReceiptLocator) throws Exception
{

	forms.textField(78,
		"//forms:textField[(@name='RCPT_BLK_LOCATOR_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptLocator);
	
	forms.textField(78,
		"//forms:textField[(@name='RCPT_BLK_LOCATOR_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptLocator

public void enterReceiptItemSerialNumber(int PAR_LineNumber, String PAR_ReceiptItemSerialNumber) throws Exception
{
	// check first if the serial number field is editable.  if yes then use the parameter serial number
	// if the serial number is not editable, it means that there is a serial number already entered.
	forms.textField(80,
	"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
	.click(); // serial number field
	
	if (!forms.textField(80,
	"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]").isEditable())
		return;
	
	/*
	forms.textField(80,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
	.setText(PAR_ReceiptItemSerialNumber);
	*/
	generateMaterialReceiptSerialNumber(0);
	
	forms.textField(80,
		"//forms:textField[(@name='LOT_SERIAL_BLK_SERIAL_NUMBER_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD"); // Receipt quantity
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterReceiptLocator

public void clickOnEnterReceiptSubmitButton() throws Exception
{
	{
		think(1.0);
	}
	forms.button(82, "//forms:button[(@name='BTN_BLK_DONE_BTN_0')]")
			.click(); // this is the submit button
	{
		think(1.0);
	}
}

public String getRequestIDNumber(String PAR_myString) throws Exception {
	/*
	 * Synopsis this function parses the requestIDNumber from the alert
	 * message that has the request id number this is normally called by the
	 * function getRequestIDThenClickButton() but it can be used whenever
	 * you need to parse a number from any string
	 * 
	 * @param PAR_myString - This is a string to parse the number from
	 * 
	 * @return requestID or the number in the string in String type
	 * 
	 * manny gochuico for CACI
	 */
	final StringBuilder requestID = new StringBuilder(PAR_myString.length());
	for (int i = 0; i < PAR_myString.length(); i++) {
		final char x = PAR_myString.charAt(i);
		if (x > 47 && x < 58) {
			requestID.append(x);
		}
	}
	return requestID.toString();
} // end of getRequestIDNumber

public String getRequestIDThenClickButton(String PAR_buttonLabel) throws Exception {
	/*
	 * Synopsis Whenever you submit a concurrent request, Oracle EBS
	 * displays a choice dialog box with the concurrent Request ID and 1 or 2
	 * buttons, Yes or No or OK. Use this function to save the request ID in a
	 * global variable GLBL_myRequestID and also return the value of
	 * requestID that you can use locally from the calling program
	 * 
	 * this function calls another function called
	 * getRequestIDNumber(myAlertmessage) that Septemberarates the request number
	 * from the rest of the string text.
	 * 
	 * call this function to replace the clicking of the Yes or No button in
	 * the choice dialog box
	 * 
	 * @param: PAR_buttonLabel - valid values "Yes" to click on the Yes
	 * button and "No" to click on the "No" button
	 * 
	 * @return: the RequestID number and also sets the global variable
	 * GLBL_myRequestID to the value of the requestID
	 * 
	 * You would normally add your actions for either No button Click or Yes
	 * button click after calling this function. 
	 * Manny Gochuico 
	 */
	String myRequestID = null;

	beginStep(
		"[1] get RequestID then click button",
		0);
	{

		forms.captureScreenshot(80);
		{
			think(1.0);
		}
		String myAlertMessage = forms.choiceBox(81, "//forms:choiceBox").getAlertMessage();
		
		myRequestID = getRequestIDNumber(myAlertMessage);
		
		info("Request Number is " + myRequestID);
		
		getVariables().set( "GLBL_myRequestID",myRequestID,Variables.Scope.GLOBAL);
		forms.choiceBox(81,"//forms:choiceBox").clickButton(PAR_buttonLabel);

		think(2.0);

	}
	endStep();

	return myRequestID;
} // end of getRequestIDThenClickButton

public String checkRequestIDStatus(int PAR_clickIntervalSeconds) throws Exception {
	/*
	 * this returns the completion status of a concurrent program. This
	 * function continues to click on the refresh button until the phase
	 * reaches "Completed" valid return values are: Normal Error Warning
	 * 
	 * @param - PAR_clickIntervalSeconds - number of seconds to wait before
	 * clicking the refresh button again 
	 * Manny Gochuico for CACI
	 */
	String myCurrentPhase = null;
	String myCurrentStatus = null;

	while (true) {

		forms.button(
			58,
			"//forms:button[(@name='JOBS_REFRESH_0')]").click();

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

		think(PAR_clickIntervalSeconds);

		forms.textField(
			64,
			"//forms:textField[(@name='JOBS_PHASE_0')]").setFocus();

		forms.textField(
			64,
			"//forms:textField[(@name='JOBS_PHASE_0')]").setFocus();
		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

		myCurrentPhase = forms.textField(
			64,
			"//forms:textField[(@name='JOBS_PHASE_0')]").getText();

		forms.textField(
			70,
			"//forms:textField[(@name='JOBS_STATUS_0')]").setFocus();
		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

		myCurrentStatus = forms.textField(
			70,
			"//forms:textField[(@name='JOBS_STATUS_0')]").getText();

		if (myCurrentPhase.equalsIgnoreCase("Completed"))
			break;

		think(1.0);
	} // end while(true)
	forms.captureScreenshot(57);
	{
		think(1.0);
	}

	return myCurrentStatus;

} // end of checkRequestIDStatus

public String findTheSpecificRequestByProgramName(String PAR_myConcurrentProgram) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function calls checkRequestStatus that will continue to click
	 * the Refresh button until the phase is Completed. that function
	 * returns a string value of either Normal, Warning, or Error to this
	 * function which in turn is returned by this function.
	 * 
	 * Calls checkRequestStatus() returns: String run result of one of the
	 * following results values "Normal", "Error", "Warning"
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.textField(
			48,
			"//forms:textField[(@name='JOBS_QF_PROGRAM_0')]").setText(
			PAR_myConcurrentProgram);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();

	String myCompletedRequestStatus = checkRequestIDStatus(5);

	return myCompletedRequestStatus;

} // end of findTheSpecificRequestByProgramName

public String findTheSpecificRequestByRequestID(String PAR_myConcurrentRequestID) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function calls checkRequestStatus that will continue to click
	 * the Refresh button until the phase is Completed. that function
	 * returns a string value of either Normal, Warning, or Error to this
	 * function which in turn is returned by this function.
	 * 
	 * Calls checkRequestStatus() returns: String run result of one of the
	 * following results values "Normal", "Error", "Warning"
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.textField(104,
		"//forms:textField[(@name='JOBS_QF_REQUEST_ID_0')]").setText(
			PAR_myConcurrentRequestID);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();

	String myCompletedRequestStatus = checkRequestIDStatus(5);

	return myCompletedRequestStatus;

} // end of findTheSpecificRequestByRequestID

public void findTheSpecificRequestByRequestor(String PAR_myConcurrentProgramRequestorName) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function finds all the requests made by a specific requestor
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.textField(109,
		"//forms:textField[(@name='JOBS_QF_REQUESTOR_0')]")
		.setText(PAR_myConcurrentProgramRequestorName);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();



} // end of findTheSpecificRequestByRequestor

public void findTheSpecificRequestByDateSubmitted(String PAR_myConcurrentProgramDateSubmitted) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function finds all the requests made by a specific Date Submitted
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.textField(106,
		"//forms:textField[(@name='JOBS_QF_DATE_SUBMITTED_0')]")
		.setText(PAR_myConcurrentProgramDateSubmitted);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();



} // end of findTheSpecificRequestByDateSubmitted

public void findTheSpecificRequestByDateCompleted(String PAR_myConcurrentProgramDateCompleted) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function finds all the requests made by a specific date completed
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.textField(107,
		"//forms:textField[(@name='JOBS_QF_DATE_COMPLETED_0')]")
		.setText(PAR_myConcurrentProgramDateCompleted);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();



} // end of findTheSpecificRequestByDateCompleted

public void findTheSpecificRequestByJobStatus(String PAR_myConcurrentProgramJobStatus) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function finds all the requests made by a specific Job Status
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.list(108, "//forms:list[(@name='JOBS_QF_STATUS_0')]")
		.selectItem(PAR_myConcurrentProgramJobStatus);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();



} // end of findTheSpecificRequestByJobStatus

public void findTheSpecificRequestByJobPhase(String PAR_myConcurrentProgramJobPhase) throws Exception {
	/*
	 * Synopsis: This function uses the View/Request form to find the status
	 * of the concurrent program that was just ran. when a concurrent
	 * program is executed, the request id is provided by Oracle EBS in a
	 * modal window with a Yes and a No button. once you click on the No
	 * button, the View Request window will be displayed. you call this
	 * function immediately after clicking on the No button.
	 * 
	 * this function finds all the requests made by a specific Job Status
	 * 
	 * manny gochuico developed for CACI
	 */
	beginStep(
		"[1] Find Requests",
		0);
	{

		forms.captureScreenshot(83);
		{
			think(1.0);
		}
		while (true) {
			if (forms.radioButton(
				84,
				"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").exists())
				break;
			else
				think(2.0);
		}
		// click on the specific request radio button
		forms.radioButton(
			84,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]").select();
		{
			think(1.0);
		}
		forms.list(110, "//forms:list[(@name='JOBS_QF_PHASE_0')]")
		.selectItem(PAR_myConcurrentProgramJobPhase);
		{
			think(0.016);
		}
		forms.button(
			86,
			"//forms:button[(@name='JOBS_QF_FIND_0')]").click();

		think(1.0);

		if (forms.choiceBox(
			67,
			"//forms:choiceBox").exists())
			forms.choiceBox(
				67,
				"//forms:choiceBox").clickButton(
				"OK");

	}
	endStep();

} // end of findTheSpecificRequestByJobPhase

public void closeViewRequestsJobsWindow() throws Exception
{
	try {
		if (forms.window(120, "//forms:window[(@name='JOBS')]").exists())
		{
		{
			think(1.0);
		}
		forms.window(120, "//forms:window[(@name='JOBS')]").close(); // close Jobs window
		{
			think(1.0);
		}
		} // end if
	} catch (Exception e)
	{
		info("error executing closeViewRequestsJobsWindow ");
		info ("error message: "+e);
	}
} // end of closeViewRequestsJobsWindow

public boolean checkIfCodeIdentifierExist(int PAR_LineNumber, String PAR_DocumentIdentifier) throws Exception
{
	// use this function to check if DRA or D6T or any code exists in the receipt line
	// usage: checkIfCodeIdentifierExist(PAR_LineNumber,PAR_DocumentIdentifier)
	// checkIfCodeIdentifierExist(0, "DRA")
	// checkIfCodeIdentifierExist(1, "D6T")
	// checkIfCodeIdentifierExist(99,"AST"
	boolean CodeIdentifierExist = false;
	String myDocumentIdentifier = null;
	
	if (PAR_LineNumber==99)
	{
		PAR_LineNumber=0;
		while (true)
		{
			myDocumentIdentifier = forms.textField(33,
				"//forms:textField[(@name='XXMC_DOCUMENT_HISTORY_V2_DOCUMENT_IDENTIFIER_"+PAR_LineNumber+"')]")
				.getText();
			if (myDocumentIdentifier.isEmpty())
			{
				CodeIdentifierExist = false;
				PAR_LineNumber = 99;
				break;
			}
			if(myDocumentIdentifier.equals(PAR_DocumentIdentifier))
			{
				CodeIdentifierExist = true;
				PAR_LineNumber = 99;
				break;
			}
			else
			{
				PAR_LineNumber++;
			}
		}
	}
	if (PAR_LineNumber==99)
		return CodeIdentifierExist;

	myDocumentIdentifier = forms.textField(33,
			"//forms:textField[(@name='XXMC_DOCUMENT_HISTORY_V2_DOCUMENT_IDENTIFIER_"+PAR_LineNumber+"')]")
			.getText();
	
	if(myDocumentIdentifier.equals(PAR_DocumentIdentifier))
		CodeIdentifierExist = true;
	

	forms.captureScreenshot(32);
	{
		think(1.0);
	}
	
	return CodeIdentifierExist;
} // end of checkIfCodeIdentifierExist

public boolean checkIfDRAandD6TExist(String GLBL_SDNNumber) throws Exception
{
	// use this function to check if DRA and D6T exists in the receipt line
	// usage: checkIfDRAandD6TExist()
	// returns true when the lines already were created
	boolean CodeIdentifierExist = false;
	
	while(!CodeIdentifierExist)
	{
		// close the receipt window first
		closeEnterReceiptWindow();
		// wait for a moment
		delay(5000);
		// search for the SDN number
		EnterSDNNumberAndClickFindButton(GLBL_SDNNumber);
		// wait for a moment
		delay(5000);
		CodeIdentifierExist = checkIfCodeIdentifierExist(0, "DRA");
		if (!CodeIdentifierExist)
			CodeIdentifierExist=checkIfCodeIdentifierExist(1, "DRA");
		
		if (CodeIdentifierExist)
			CodeIdentifierExist=checkIfCodeIdentifierExist(0, "D6T");
		if (!CodeIdentifierExist)
			CodeIdentifierExist=checkIfCodeIdentifierExist(1, "D6T");
		
		think(1.0);
	}
	
	forms.captureScreenshot(32);
	{
		think(1.0);
	}
	
	closeEnterReceiptWindow();
	return CodeIdentifierExist;
} // end of checkIfDRAandD6TExist


public boolean enterSDNReceipt(int PAR_LineNumber,
		String PAR_SDNNumberToReceive,
		String PAR_ManifestQuantity,
		String PAR_ReceiptQuantity,
		String PAR_ReceiptSubinventory,
		String PAR_ReceiptLocator,
		String PAR_ReceiptItemSerialNumber) throws Exception
{
boolean receiptCompleted = false;

enterManifestQuantity(PAR_LineNumber, PAR_ManifestQuantity);
enterReceiptQuantity( PAR_LineNumber,  PAR_ReceiptQuantity);
enterReceiptQuantity( PAR_LineNumber,  PAR_ReceiptQuantity); // the receipt quantity is entered twice
enterReceiptSubinventory( PAR_LineNumber,  PAR_ReceiptSubinventory);
enterReceiptLocator( PAR_LineNumber,  PAR_ReceiptLocator);
enterReceiptItemSerialNumber( PAR_LineNumber,  PAR_ReceiptItemSerialNumber);
clickOnEnterReceiptSubmitButton();
pauseForAMoment(5);
getRequestIDThenClickButton( "OK");
receiptCompleted = checkIfDRAandD6TExist(PAR_SDNNumberToReceive);
info("receipt completed ===> "+receiptCompleted);

return receiptCompleted;

} // end of enterSDNReceipt

public boolean enterSDNReceipt(int PAR_LineNumber,
		String PAR_SDNNumberToReceive,
		String PAR_ManifestQuantity,
		String PAR_ReceiptQuantity,
		String PAR_ReceiptSubinventory,
		String PAR_ReceiptLocator,
		String PAR_ReceiptItemSerialNumber,
		String PAR_ImageName) throws Exception
{
boolean receiptCompleted = false;

enterManifestQuantity(PAR_LineNumber, PAR_ManifestQuantity);
enterReceiptQuantity( PAR_LineNumber,  PAR_ReceiptQuantity);
enterReceiptQuantity( PAR_LineNumber,  PAR_ReceiptQuantity); // the receipt quantity is entered twice
enterReceiptSubinventory( PAR_LineNumber,  PAR_ReceiptSubinventory);
enterReceiptLocator( PAR_LineNumber,  PAR_ReceiptLocator);
enterReceiptItemSerialNumber( PAR_LineNumber,  PAR_ReceiptItemSerialNumber);

//take a screenshot
ScreenShot(false,true, "03_"+PAR_ImageName);

clickOnEnterReceiptSubmitButton();
pauseForAMoment(5);

//take a screenshot
ScreenShot(false,true, "getRequestID");

getRequestIDThenClickButton( "OK");
receiptCompleted = checkIfDRAandD6TExist(PAR_SDNNumberToReceive);
info("receipt completed ===> "+receiptCompleted);

return receiptCompleted;

} // end of enterSDNReceipt

public boolean enterSDNReceipt(int PAR_LineNumber,
		String PAR_SDNNumberToReceive,
		String PAR_ReceiptSubinventory,
		String PAR_ReceiptLocator,
		String PAR_ReceiptItemSerialNumber,
		String PAR_ImageName) throws Exception
/*
 * Use this function to pick up the Due Quantity and then use that to populate the manifest quantity, and the receipt quantity	
 * PAR_Imagename is the name that you want to give to the screenshot	
 */
{
boolean receiptCompleted = false;

String myReceiptQuantity=getReceiptDueQuantity(0);

enterManifestQuantity(PAR_LineNumber, myReceiptQuantity);
enterReceiptQuantity( PAR_LineNumber,  myReceiptQuantity);
enterReceiptQuantity( PAR_LineNumber,  myReceiptQuantity); // the receipt quantity is entered twice
enterReceiptSubinventory( PAR_LineNumber,  PAR_ReceiptSubinventory);
enterReceiptLocator( PAR_LineNumber,  PAR_ReceiptLocator);
if (Integer.parseInt(myReceiptQuantity)==1)
	enterReceiptItemSerialNumber( PAR_LineNumber,  PAR_ReceiptItemSerialNumber);


//take a screenshot
ScreenShot(false,true, "03_"+PAR_ImageName);

clickOnEnterReceiptSubmitButton();
pauseForAMoment(5);

//take a screenshot
ScreenShot(false,true, PAR_ImageName);

getRequestIDThenClickButton( "OK");
receiptCompleted = checkIfDRAandD6TExist(PAR_SDNNumberToReceive);
info("receipt completed ===> "+receiptCompleted);

return receiptCompleted;

} // end of enterSDNReceipt

public boolean multipleQtyReceiptBySDN(String PAR_DatabankName,String PAR_SDNNumberToReceive) throws Exception
{
	/*
	 * Abstract:
	 * This function supports multiple quantity receipt for a specific SDN number. This supports any number of quantity receipts for a specific 
	 * SDN number.  This function checks the number of records in the databank and then executes the quantity receipt based on the number of 
	 * records read.
	 * 
	 * It is assumed that there is a databank that holds the information for the quantity to be received.  your databank must have at least one record
	 * with the following field header information: (case sensitive)
	 * receiptSubinventory, 
	 * receiptLocator,
	 * receiptSerialNumber
	 * 
	 * Parameters:
	 * String PAR_DatabankName - name of your databank in a recognized repository
	 * String PAR_SDNNumberToReceive - the SDN Number to Receive
	 * 
	 * Databank
	 * your databank record field header must be rendered as follows:
	 * manifestQuantity,receiptQuantity,receiptSubinventory, receiptLocator
	 * 
	 * example databank
	 * receiptSubinventory, receiptLocator, receiptSerialNumber
	 * A1C,AA,12345678
	 * A1F,BB,null
	 * 
	 * Return Value (optional)
	 * boolan value 
	 * 	true = if receipt was successful
	 * 	false = if receipt failed
	 * 
	 * Sample usage
	 * multipleSDNReceipt(myReceiptQuantityDatabank,M29003011540017);
	 * or
	 * boolean wasReceiptSuccessful = multipleSDNReceipt(myReceiptQuantityDatabank,M29003011540017);
	 * 
	 * Manny Gochuico (CACI)
	 */
boolean receiptCompleted = false;

getDatabank(PAR_DatabankName).getNextDatabankRecord();
int numberOfRecordsToProcess = getDatabank(PAR_DatabankName).getDatabankRecordCount();
int receiptLineNumber = 0;
String PRV_ManifestQuantity= null;
String PRV_ReceiptQuantity= null;
String PRV_ReceiptSubinventory= null;
String PRV_ReceiptLocator= null;
String PRV_ReceiptItemSerialNumber= null;
String  DueInQuantity = null;

for (int currentRecord=1;currentRecord<=numberOfRecordsToProcess;currentRecord++)
{
	// get the record from the databank
	getDatabank(PAR_DatabankName).getRecord(currentRecord); // gets the first record
	// Receipt Subinventory
	getVariables().set(PRV_ReceiptSubinventory,
		"{{db."+PAR_DatabankName+".receiptSubinventory}}", Variables.Scope.GLOBAL);
	// Receipt Locator
	getVariables().set(PRV_ReceiptLocator,
		"{{db."+PAR_DatabankName+".receiptLocator}}", Variables.Scope.GLOBAL);
	// Receipt Serial Number or null
	getVariables().set(PRV_ReceiptItemSerialNumber,
		"{{db."+PAR_DatabankName+".receiptSerialNumber}}", Variables.Scope.GLOBAL);
	
	DueInQuantity = getReceiptDueQuantity(receiptLineNumber);
	
	enterManifestQuantity(receiptLineNumber, DueInQuantity);
	enterReceiptQuantity( receiptLineNumber,   DueInQuantity);
	enterReceiptQuantity( receiptLineNumber,   DueInQuantity); // the receipt quantity is entered twice
	enterReceiptSubinventory( receiptLineNumber,   getVariables().get(PRV_ReceiptSubinventory));
	enterReceiptLocator( receiptLineNumber,   getVariables().get(PRV_ReceiptLocator));
	enterReceiptItemSerialNumber( receiptLineNumber,   getVariables().get(PRV_ReceiptItemSerialNumber));
	clickOnEnterReceiptSubmitButton();
	pauseForAMoment(5);
	getRequestIDThenClickButton( "OK");
	/* if DRA and D6T checking is required for each receipt, then enable the next two lines
	 * 	receiptCompleted = checkIfDRAandD6TExist(PAR_SDNNumberToReceive);
	 *  info("receipt completed ===> "+receiptCompleted);
	 */

// enable the following line if needed
// receiptLineNumber++;

} // end of for
/* if DRA and D6T checking is required after all receipt (Default) , otherwise disable the next two lines */
	receiptCompleted = checkIfDRAandD6TExist(PAR_SDNNumberToReceive);
	info("receipt completed ===> "+receiptCompleted);
	
return receiptCompleted;

} // end of multipleQtyReceiptBySDN


public void pauseForAMoment(int timeInSeconds) throws Exception {
	int myWaitTime = timeInSeconds / 5;
	do {
		think(5.0);
		myWaitTime--;
	} while (myWaitTime >= 0);

} // end of pauseForAMoment

public void closeEnterReceiptWindow() throws Exception
{
	{
		think(1.0);
	}
	forms.window(35, "//forms:window[(@name='MAIN_WIN')]").close(); // close the receipt window
	{
		think(1.0);
	}
} // end of closeEnterReceiptWindow

public void closeFindSDNWindow() throws Exception
{
	beginStep("[10] Close Find Documents Form ", 0);
	{
		forms.captureScreenshot(38);
		{
			think(1.0);
		}
		forms.window(39, "//forms:window[(@name='FIND_WIN')]").close(); // close the find doucment window
		{
			think(1.0);
		}

	}
	endStep();
} // end of closeFindSDNWindow

public void closePickReleaseOrderSubmissionForm() throws Exception
{
	forms.captureScreenshot(403);
	{
		think(1.0);
	}
	forms.window(404, "//forms:window[(@name='RELEASE')]").close(); // close pick release form
	{
		think(1.0);
	}
} // end of closePickReleaseOrderSubmissionForm

public void clickOnPickReleaseOrderformConcurrentButton() throws Exception
{
	forms.captureScreenshot(396);
	{
		think(1.0);
	}
	forms.button(397, "//forms:button[(@name='RELEASE_CONCURRENT_0')]")
			.click(); // click concufrrent button
	
	think(1.0);
} // end of clickOnPickReleaseOrderformConcurrentButton


public void enterPickReleaseOrderformOrderNumber(String PAR_orderNumber) throws Exception
{
	while(true)
	{
	if (forms.textField(392,
			"//forms:textField[(@name='RELEASE_ORDER_NUMBER_0')]").exists())
		break;
	else
		think(1.0);
	}

	forms.textField(392,
			"//forms:textField[(@name='RELEASE_ORDER_NUMBER_0')]").setText(PAR_orderNumber);
			
	forms.captureScreenshot(396);
	{
		think(1.0);
	}
	forms.textField(392,
	"//forms:textField[(@name='RELEASE_ORDER_NUMBER_0')]").invokeSoftKey("NEXT_FIELD");
	
	think(1.0);
} // end of enterPickReleaseOrderformOrderNumber

public void enterPickReleaseOrderformPickingRule(String PAR_PickingRule) throws Exception
{
	while(true)
	{
	if (forms.textField(384,
	"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]").exists())
		break;
	else
		think(1.0);
	}

	forms.textField(384,
	"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]").setText(PAR_PickingRule);

			
	forms.captureScreenshot(396);
	{
		think(1.0);
	}
	forms.textField(384,
	"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]").invokeSoftKey("NEXT_FIELD");
	
	think(1.0);
} // end of enterPickReleaseOrderformPickingRule

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ++++++++++++++++++++++++++++++++++++++++ common objects +++++++++++++++++++++++++++++++++++++
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
public void ExitEBS() throws Exception
{
beginStep("[999] Close Navigator", 0);
{
	forms.captureScreenshot(95);
	{
		think(2.0);
	}
	forms.window(96, "//forms:window[(@name='NAVIGATOR')]").selectMenu(
			"File|Exit Oracle Applications");
}
endStep();
beginStep("[99921] Caution", 0);
{
	forms.captureScreenshot(98);
	{
		think(2.0);
	}
	ClickOnChoiceBox("OK");

	{
		think(2.0);
	}


}
endStep();
} // end of ExitEBS

public void ExitEBSandAllWebforms() throws Exception
{
	beginStep("[999] Close Navigator", 0);
	{
	forms.captureScreenshot(95);
	{
		think(2.0);
	}
	forms.window(96, "//forms:window[(@name='NAVIGATOR')]").selectMenu(
			"File|Exit Oracle Applications");
	}
	endStep();
	beginStep("[99921] Caution", 0);
	{
	forms.captureScreenshot(98);
	{
		think(2.0);
	}
	ClickOnChoiceBox("OK");

	{
		think(2.0);
	}

	closeWebWindow("Oracle E-Business Suite R12");
	{
		think(2.0);
	}
	clickOnLogoutIcon();
	}
	endStep();
} // end of ExitEBSandAllWebforms

public void clickOnFormFlexWindowOkButton() throws Exception
{
	forms.flexWindow(344, "//forms:flexWindow").clickOk();
	think(1.0);
} // end of clickOnFormFlexWindowOkButton

public void clickOnCheckBox(String PAR_CheckBoxName, boolean PAR_CheckboxValue)	throws Exception
{
	forms.checkBox(367,
		"//forms:checkBox[(@name='"+PAR_CheckBoxName+"')]").check(PAR_CheckboxValue);
	{
		think(1.0);
	}
} // end of clickOnCheckBox

public void closeWebWindow(String PAR_WebWindowTitleToClose) throws Exception
{
	web.window(381,
		"/web:window[@index='1' or @title='"+PAR_WebWindowTitleToClose+"']")
		.close();
	{
		think(1.0);
	}
} // end of closeWebWindow

public void clickOnLogoutIcon() throws Exception
{
	web.image(
		382,
		"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:img[@alt='Logout' or " +
		"@index='14' " +
		"]")
		.click();
} // end of clickOnLogoutIcon

public void closeLoginFormWebWindow() throws Exception
{
	while(true)
	{
		if(!web.window(383, "/web:window[@index='0' or @title='Login']").exists())
			think(1.0);
		else
			break;
	}
	// web.window(383, "/web:window[@index='0' or @title='Login']").waitForPage(null);
	{
		think(1.0);
	}
	closeWebWindow("Login");
	
	// web.window(384, "/web:window[@index='0' or @title='Login']").close();
} // end of closeLoginFormWebWindow

public void ClickOnChoiceBox(String PAR_whatButtonToClick) throws Exception
{
	if (!forms.choiceBox(313, "//forms:choiceBox").exists())	
		return;
	
	forms.captureScreenshot(312);
			{
				think(1.0);
			}
			forms.choiceBox(313, "//forms:choiceBox").clickButton(PAR_whatButtonToClick);
} // end of ClickOnChoiceBox

public void activateNavigator() throws Exception
{
	{
		think(1.0);
	}
	forms.window(20, "//forms:window[(@name='NAVIGATOR')]").activate(
			true); // activate the navigator
	
	while(true)
	{
		if(forms.window(20, "//forms:window[(@name='NAVIGATOR')]").exists())
			break;
		else
			think(1.0);
	}
	
	// click on the collapse button
	forms.button(21,
	"//forms:button[(@name='NAV_CONTROLS_COLLAPSE_ALL_0')]")
	.click();
	
} // end of activateNavigator

public void clickOnViewRequests(String PAR_formName) throws Exception {
	/*
	 * @parameter PAR_formName refers to the EBS form displayed on the
	 * screen . for example:
	 *  "ORDER" to perform a view-request action on a sales order form
	 *  "NAVIGATOR" to perform a view-request action from the NAVIGATOR
	 *  
	 *  clickOnViewRequests("NAVIGATOR");
	 */
	beginStep(
		"[1] Click on View | Requests",
		0);
	{

		forms.captureScreenshot(25);
		{
			think(1.0);
		}
		forms.window(
			26,
			"//forms:window[(@name='" + PAR_formName + "')]").selectMenu(
			"View|Requests");


	}
	endStep();
} // end of clickonViewRequests

public void clickOnSubmitNewRequestsButton() throws Exception {
	/*
	 * when you click on View-Request, this function clicks on the
	 * "Submit New Requests" button on the view-Request form
	 */
	beginStep(
		"[1] Click on Submit a new Request",
		0);
	{

		forms.captureScreenshot(28);
		{
			think(1.0);
		}
		forms.radioButton(
			29,
			"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_MY_COMPLETED_JOBS_0')]").setFocus();
		{
			think(0.0);
		}
		forms.button(
			30,
			"//forms:button[(@name='JOBS_QF_NEW_0')]").click();

		{
			think(2.0);

		}
	}
	endStep();
} // end of clickOnSubmitNewRequestsButton

public void enterConcurrentOrReportName(String PAR_concurrentProgramName) throws Exception {
	/*
	 * In the Submit new Request Form, this is the function where you enter
	 * the concurrent program name and then press the tab button. if there
	 * are parameters for the report or concurrent program, then you must
	 * record that options form and call that function after this function.
	 */
	beginStep(
		"[1] Submit New Request",
		0);
	{

		forms.captureScreenshot(64);
		{
			think(1.0);
		}
		forms.textField(
			65,
			"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]").setText(
			PAR_concurrentProgramName);

		{
			think(1.0);
		}
		forms.textField(
			66,
			"//forms:textField[(@name='WORK_ORDER_USER_CONCURRENT_PROGRAM_NAME_0')]").invokeSoftKey(
			"NEXT_FIELD");
	}
	endStep();
} // end of enterConcurrentOrReportName

public boolean checkIfTheRecordWasSaved(String PAR_Message) throws Exception
{
	/*
	 * usage checkIfTheRecordWasSaved("records applied and saved")
	 */
	boolean recordWasSaved = false;
	String statusBarMessage = null;
	
	try
	{

	{
		think(1.0);
	}
	statusBarMessage = forms.statusBar(96, "//forms:statusBar").getText();
	
	if(statusBarMessage.indexOf(PAR_Message)>0)
		recordWasSaved = true;

	{
		think(1.0);
	}

	} catch (Exception e){
		{
		info("ERROR executing checkIfTheRecordWasSaved");
		info("error message: "+e);
		}
	}
	return recordWasSaved;
	
} // end of checkIfTheRecordWasSaved

public void enterReportParameter(String PAR_ParameterLabel, String PAR_ParameterValue) throws Exception
{
	
	{
		think(1.0);
	}
	forms.flexWindow(88, "//forms:flexWindow").setText(PAR_ParameterLabel,
			"", PAR_ParameterValue);
	{
		think(1.0);
	}
	forms.captureScreenshot(87);
} // end of enterReportParameter

public void clickOKOnParameterWindow() throws Exception
{
	{
		think(1.0);
	}
	forms.flexWindow(92, "//forms:flexWindow").clickOk(); // click OK on parameter window
} // end of clickOKOnParameterWindow

public void clickOKOnSubmitRequestButton() throws Exception
{
	{
		think(1.0);
	}
	forms.button(95, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
	.click(); // click on submit request Submit button
	{
		think(1.0);
	}
	
} // end of clickOKOnSubmitRequestButton

public void changeNavigationPathInEBSForms(String PAR_NavigationString, String delimiterPattern) throws Exception
{

		/*
		 * this function will parse the navigation string parameter and  and click on the menu items in the NAVIGATOR to navigate the
		 * menus in EBS Forms.
		 * 
		 * Note:  This will activate the Navigator Window so it is suggested that all your EBS forms are closed before you 
		 * call this function 
		 * 
		 * usage examples: 
		 * changeNavigationPathInEBSForms("Change Organization",";")
		 * changeNavigationPathInEBSForms("Shipping;Release Sales Orders;Release Sales Orders",";")
		 * 
		 * Manny Gochuico CACI copyright(c) 2021
		 */
		// ++++++++++++ setup variables +++++++++++++++++++++
	
		// First Activate the navigatore
		activateNavigator();
		
		
		boolean isThereAComma = false;
		int menuItemCounter = 0;
		String myNavigation = PAR_NavigationString;
		String charToSearch = delimiterPattern; // originally --> ",";
		List<String> menuItems = new ArrayList<String>();

		String repeatedString = null;
		boolean repeatedText = false;
		int repeatedCount = 0;
		String menuItemToSelect = null;

		// collapse the current menu selection
		forms.button(27,
		"//forms:button[(@name='NAV_CONTROLS_COLLAPSE_ALL_0')]")
		.click();

		// ++++++++++++ now parse the menu items +++++++++++++++++++
		for (int i = 0; i < myNavigation.length(); i++) {
			// check if ther eis a comma in the string
			int commaLocation = myNavigation.indexOf(
				charToSearch,
				i);
			info("commaLocaton ===> " + commaLocation);
			if (commaLocation > 0) {
				isThereAComma = true;
				String A = myNavigation.substring(
					i,
					commaLocation);
				if (i==0)
				{
					menuItems.add(A);
					menuItemToSelect = A;
				}
				else
				{
					menuItemToSelect=menuItemToSelect+"|"+A;
					menuItems.add(menuItemToSelect);
				}
				info(menuItems.get(
					menuItemCounter).toString());
				i = commaLocation;
				menuItemCounter++;
				info("the value of i is ==>" + i);


			} else {
				if (isThereAComma) {
					menuItemToSelect=menuItemToSelect+"|"+(myNavigation.substring(i,myNavigation.length()));
					/*
					menuItems.add(myNavigation.substring(
						i,
						myNavigation.length()));
						*/
					menuItems.add(menuItemToSelect);
					info(menuItems.get(
						menuItemCounter).toString());
					break;
				} else {
					menuItems.add(myNavigation);
					info("myNavigation ===> " + myNavigation);
					menuItemCounter++;
					break;
				}

			}
		}

		info("Now Click on the menu items");
		
		// active the navigator form
		forms.window(324, "//forms:window[(@name='NAVIGATOR')]").activate(
			true);
		
		boolean allmenuitemsclicked = false;

		for (int i = 0; i < menuItems.size(); i++) {
			String menuItem = menuItems.get(
				i).toString();
			info(menuItems.get(
				i).toString());
			
			


			while (true) {
				
				
				if (forms.treeList(327, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
						.exists())
				{
					info("check point 1");
					break;
				}
				else
				{
					think(2.0);
					/* use this routine to check thenext form that will show up
					if (forms.window(29, "//forms:window[(@name='PO_HEADERS')]").exists())
					{
						allmenuitemsclicked = true;
						break;
					}
					*/
					allmenuitemsclicked = true;
					break;
				}
			}

			if (allmenuitemsclicked) // this means that the java form is already displayed on the screen.
				break;
			
			think(1.0);
			/*
			web.link(
				18,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:a[@text='" + menuItem
							+ "']")
							*/
			forms.treeList(225, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
			.focusItem(menuItem);
			
			delay(1000);
			
			forms.treeList(327, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
			.selectItem(
				menuItem);				

			delay(1000);

			think(2.0);
			info("Checkpoint 2 **");
			forms.captureScreenshot(326);
			{
				think(1.0);
			}
		{
		think(2.0);
		}

		}


		// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++


	
} // end of changeNavigationPathInEBSForms


public void changeResponsibilityInEBSForms(String PAR_WindowName, String PAR_Responsibility) throws Exception
{
	/*
	 * use this function to change responsiblity while inside EBS.  this will click the Top Hat icon from any open window.
	 * for example, if you want to change the responsiblity while the navigator is showing then enter:
	 * changeResponsibilityInEBSForms("NAVIGATOR")
	 * 
	 * suggested usage: 
	 * 1) make sure there is no pending saves.  you either have to clear the form or save the form before calling this function
	 * 2) you can also close all forms until you reach the navigator and then call this function with "NAVIGATOR" as your parameter
	 * 
	 * example usage:
	 * changeResponsibilityInEBSForms("NAVIGATOR", "GCSS-MC Inventory / Supply Shipping & Receiving NCO")
	 * 
	 */
	
	forms.captureScreenshot(872);
	{
		think(1.0);
	}
	forms.window(873, "//forms:window[(@name='"+PAR_WindowName+"')]")
			.clickToolBarButton("Switch Responsibility..."); // click on the Top hat button for responsiblity 
	
	think(1.0);
	{
		think(0.111);
	}
	forms.listOfValues(85, "//forms:listOfValues").select(PAR_Responsibility);
	
} // end of changeResponsibilityInEBSForms

// +++++++++++++++++++ end of common objects

// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
// ++++++++++++++++++++++++++ TRANSACT MOVE ORDER OBJECTS +++++++++++++++++++++++++++++++++++++++++++++++++++
// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


public void clickOnTransactMoveOrderFindButton() throws Exception
{
	forms.button(49, "//forms:button[(@name='TOLINES_QF_BLK_FIND_0')]")
	.click();  // click on the find button
	think(1.0);
}

public void selectTheItemToTransact(int PAR_LineNumber) throws Exception
{
	PAR_LineNumber = PAR_LineNumber-1;
	
	forms.checkBox(52,
		"//forms:checkBox[(@name='TOLINES_BLK_SUBMIT_"+PAR_LineNumber+"')]").check(
		true); // select the iem to transact
	think(1.0);
}

public void clickOnTransactMoveOrderViewUpdateAllocationsButton() throws Exception
{
	forms.button(55, "//forms:button[(@name='TOLINES_CONTROL_OPEN_0')]")
	.click(); // click on View/Update Allocatins button
	think(1.0);
} // end of clickOnTransactMoveOrderViewUpdateAllocationsButton

public void clickOnWorkOrderCheckBox(boolean PAR_CheckWorkOrderCheckBoxStatus) throws Exception
{
// check the current status of the checkbox
  
// if the checkbox is currently checked and PAR_CheckBoxStatus = true then do not do anything
if( forms.checkBox(691,
"//forms:checkBox[(@name='TOLINES_QF_BLK_WORK_ORDER_0')]").isSelected() && PAR_CheckWorkOrderCheckBoxStatus)
	return;
// if the checkbox is currently unchecked and PAR_CheckBoxStatus = false then do not do anything
if( !forms.checkBox(691,
"//forms:checkBox[(@name='TOLINES_QF_BLK_WORK_ORDER_0')]").isSelected() && !PAR_CheckWorkOrderCheckBoxStatus)
	return;

// if the checkbox is currently checked and PAR_CheckBoxStatus = false then uncheck it
if( forms.checkBox(691,
"//forms:checkBox[(@name='TOLINES_QF_BLK_WORK_ORDER_0')]").isSelected() && !PAR_CheckWorkOrderCheckBoxStatus)
	{
	forms.checkBox(691,
	"//forms:checkBox[(@name='TOLINES_QF_BLK_WORK_ORDER_0')]")
	.check(false); // uncheck work order check box
	return;
	}
// if the checkbox is currently unchecked and PAR_CheckBoxStatus = true then uncheck it
if( !forms.checkBox(691,
"//forms:checkBox[(@name='TOLINES_QF_BLK_WORK_ORDER_0')]").isSelected() && PAR_CheckWorkOrderCheckBoxStatus)
	{	
	forms.checkBox(691,
	"//forms:checkBox[(@name='TOLINES_QF_BLK_WORK_ORDER_0')]")
	.check(true); // work order check box
	return;
	}
}

public void enterPickWaveWOJobType(String PAR_JobType) throws Exception
{
if (PAR_JobType==null)
	return;

{
	think(1.0);
}

forms.list(693, "//forms:list[(@name='TOLINES_QF_BLK_TYPE_0')]")
.selectItem(PAR_JobType);

forms.list(693, "//forms:list[(@name='TOLINES_QF_BLK_TYPE_0')]")
.invokeSoftKey("NEXT_FIELD"); // job type
{
	think(1.0);
}
}  // end of enterPickWaveWOJobType

public void enterPickWaveWOJobNumbers(String PAR_FromJob, String PAR_ToJob) throws Exception
{
if(PAR_FromJob == null && PAR_ToJob==null)
	return;

forms.textField(694,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_JOB_NUM_0')]")
.setText(PAR_FromJob);

forms.textField(694,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_JOB_NUM_0')]")
.invokeSoftKey("NEXT_FIELD"); // rom Job number
{
	think(1.0);
}
forms.textField(695,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_JOB_NUM_0')]")
.setText(PAR_ToJob);

forms.textField(695,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_JOB_NUM_0')]")
.invokeSoftKey("NEXT_FIELD"); // to job number
{
	think(1.0);
}
} // end of enterPickWaveWOJobNumbers

public void enterPickWaveWOLineNumbers(String PAR_fromLineNumber, String PAR_ToLineNumber) throws Exception
{

if(PAR_fromLineNumber == null && PAR_ToLineNumber== null)
	return;

forms.textField(696,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_LINE_0')]")
.setText(PAR_fromLineNumber);

forms.textField(696,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_LINE_0')]")
.invokeSoftKey("NEXT_FIELD"); // work order from line number
{
	think(1.0);
}
forms.textField(697,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_LINE_0')]")
.setText(PAR_ToLineNumber);

forms.textField(697,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_LINE_0')]")
.invokeSoftKey("NEXT_FIELD"); // work order to line number
{
	think(1.0);
}
} // end of enterPickWaveWOLineNumbers

public void enterPickWaveWOStart_EndDates(String PAR_startDate, String PAR_endDate) throws Exception
{

if(PAR_startDate == null && PAR_endDate== null)
	return;


forms.textField(698,
"//forms:textField[(@name='TOLINES_QF_BLK_START_DATE_0')]")
.setText(PAR_startDate);

forms.textField(698,
"//forms:textField[(@name='TOLINES_QF_BLK_START_DATE_0')]")
.invokeSoftKey("NEXT_FIELD"); // work order from start date
{
	think(1.0);
}

forms.textField(699,
"//forms:textField[(@name='TOLINES_QF_BLK_END_DATE_0')]")
.setText(PAR_endDate);

forms.textField(699,
"//forms:textField[(@name='TOLINES_QF_BLK_END_DATE_0')]")
.invokeSoftKey("NEXT_FIELD"); // work order to start date
{
	think(1.0);
}
} // end of enterPickWaveWOStart_EndDates

public void enterPickWaveWOAssembly(String PAR_WOAssemby) throws Exception
{
if(PAR_WOAssemby == null )
	return;

forms.textField(700,
"//forms:textField[(@name='TOLINES_QF_BLK_ASSEMBLY_0')]")
.setText(PAR_WOAssemby);

forms.textField(700,
"//forms:textField[(@name='TOLINES_QF_BLK_ASSEMBLY_0')]")
.invokeSoftKey("NEXT_FIELD"); // work order assembly
{
	think(1.0);
}
} // end of enterPickWaveWOAssembly

public void enterPickWaveWODepartment(String PAR_WODepartment) throws Exception
{
if(PAR_WODepartment == null )
	return;

forms.textField(701,
"//forms:textField[(@name='TOLINES_QF_BLK_DEPARTMENT_0')]")
.setText(PAR_WODepartment);

forms.textField(701,
"//forms:textField[(@name='TOLINES_QF_BLK_DEPARTMENT_0')]")
.invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}
} // end of enterPickWaveWODepartment

public void clickOnTransactMoveOrderTab(String PAR_Tabname) throws Exception 
{

forms.tab(686, "//forms:tab[(@name='TOLINES_QF_TAB_CAN')]").select(
	PAR_Tabname); 

{
	think(1.5);
}

} // end of clickOnTransactMoveOrderTab

public void TransactMoveOrder(String PickWaveTabName,
									boolean PAR_CheckWorkOrderCheckBoxStatus,
									String PAR_JobType,
									String PAR_FromJob, 
									String PAR_ToJob,
									String PAR_fromLineNumber, 
									String PAR_ToLineNumber,
									String PAR_startDate, 
									String PAR_endDate,
									String PAR_WOAssemby,
									String PAR_WODepartment,
									int PAR_LineNumberToProcess) throws Exception
{
/*
 * valid tab names are:
 * "Pick Wave"
 * 
 */

switchResponsibility("GCSS-MC Inventory / Supply Shipping & Receiving NCO");

navigateToTransactMoveOrders("MRA|MMFAF7");

clickOnTransactMoveOrderTab(PickWaveTabName);

clickOnWorkOrderCheckBox( PAR_CheckWorkOrderCheckBoxStatus);

enterPickWaveWOJobType( PAR_JobType);

enterPickWaveWOJobNumbers( PAR_FromJob,  PAR_ToJob);

enterPickWaveWOLineNumbers( PAR_fromLineNumber,  PAR_ToLineNumber);

enterPickWaveWOStart_EndDates( PAR_startDate,  PAR_endDate);

enterPickWaveWOAssembly( PAR_WOAssemby);

enterPickWaveWODepartment(PAR_WODepartment);

clickOnTransactMoveOrderFindButton();

selectTheItemToTransact(PAR_LineNumberToProcess);

clickOnMoveOrderTransactButton();

} // end of TransactMoveOrder

public void TransactMoveOrder(String PAR_FindMoveOrderTabName,
	boolean PAR_CheckSalesOrderCheckBoxStatus,
	String PAR_FromSalesOrderNumber, 
	String PAR_ToSalesOrderNumber,
	int PAR_LineNumberToProcess
	) throws Exception
{
/*
* valid PAR_FindMoveOrderTabName value is:
* "Pick Wave"
* 
*/

switchResponsibility("GCSS-MC Inventory / Supply Shipping & Receiving NCO");

navigateToTransactMoveOrders("MRA|MMFAF7");

clickOnTransactMoveOrderTab(PAR_FindMoveOrderTabName);

clickOnSalesOrderCheckBox( PAR_CheckSalesOrderCheckBoxStatus);

enterPickWaveSalesorderNumber( PAR_FromSalesOrderNumber,  PAR_ToSalesOrderNumber );

clickOnTransactMoveOrderFindButton();

selectTheItemToTransact(PAR_LineNumberToProcess);

clickOnMoveOrderTransactButton();

} // end of TransactMoveOrder

public void TransactMoveOrder(String PAR_FindMoveOrderTabName,
							String PAR_ItemNumber, 
							String PAR_FromDateRequired, 
							String PAR_ToDateRequired, 
							String PAR_projectNumber,
							String PAR_TransactionType,
							String PAR_LineStatus, 
							String PAR_AlocationType,
							int PAR_LineNumberToProcess
						) throws Exception
{
/*
* valid PAR_FindMoveOrderTabName value is:
* 
* "Lines"

* 
*/

switchResponsibility("GCSS-MC Inventory / Supply Shipping & Receiving NCO");

navigateToTransactMoveOrders("MRA|MMFAF7");

clickOnTransactMoveOrderTab(PAR_FindMoveOrderTabName);

enterTransactMoveOrderLinesTab( PAR_ItemNumber,  PAR_FromDateRequired,  PAR_ToDateRequired,  PAR_projectNumber,
 PAR_TransactionType, PAR_LineStatus,  PAR_AlocationType);

clickOnTransactMoveOrderFindButton();

selectTheItemToTransact(PAR_LineNumberToProcess);

clickOnMoveOrderTransactButton();

} // end of TransactMoveOrder

public void TransactMoveOrder(String PAR_FindMoveOrderTabName,
	String PAR_SourceSubinventory, 
	String PAR_DestinationSubinventory, 
	String PAR_LotNumber, 
	String PAR_DestinationAccount ,
	int PAR_LineNumberToProcess
) throws Exception
{
/*
* valid PAR_FindMoveOrderTabName value is:
* 
* "Source and Destination"

* 
*/

switchResponsibility("GCSS-MC Inventory / Supply Shipping & Receiving NCO");

navigateToTransactMoveOrders("MRA|MMFAF7");

clickOnTransactMoveOrderTab(PAR_FindMoveOrderTabName);

enterSourceAndDestinationSubinventory( PAR_SourceSubinventory,  PAR_DestinationSubinventory,  PAR_LotNumber,  PAR_DestinationAccount );

clickOnTransactMoveOrderFindButton();

selectTheItemToTransact(PAR_LineNumberToProcess);

clickOnMoveOrderTransactButton();

} // end of TransactMoveOrder

public void TransactMoveOrder(String PAR_FindMoveOrderTabName,
	String PAR_FromDocumentNumber,  
	String PAR_ToDocumentNumber, 
	String PAR_DocumentDescription, 
	String PAR_DocumentOrderType ,
	String PAR_DocumentCreatedBy,
	int PAR_LineNumberToProcess
) throws Exception
{
/*
* valid PAR_FindMoveOrderTabName value is:
* 
* "Headers"

* 
*/

switchResponsibility("GCSS-MC Inventory / Supply Shipping & Receiving NCO");

navigateToTransactMoveOrders("MRA|MMFAF7");

clickOnTransactMoveOrderTab(PAR_FindMoveOrderTabName);

enterHeadersDocumentNumbers( PAR_FromDocumentNumber,  PAR_ToDocumentNumber);

enterHeadersDescription( PAR_DocumentDescription);

enterHeadersOrderType( PAR_DocumentOrderType);

enterHeadersCreatedBy( PAR_DocumentCreatedBy);

clickOnTransactMoveOrderFindButton();

selectTheItemToTransact(PAR_LineNumberToProcess);

clickOnMoveOrderTransactButton();


} // end of TransactMoveOrder

public void clickOnSalesOrderCheckBox(boolean PAR_CheckSalesOrderCheckBoxStatus) throws Exception
{
// check the current status of the checkbox
  
// if the checkbox is currently checked and PAR_CheckSalesOrderCheckBoxStatus = true then do not do anything
if( forms.checkBox(687,
"//forms:checkBox[(@name='TOLINES_QF_BLK_SALES_ORDER_0')]").isSelected() && PAR_CheckSalesOrderCheckBoxStatus)
	return;
// if the checkbox is currently unchecked and PAR_CheckSalesOrderCheckBoxStatus = false then do not do anything
if( !forms.checkBox(687,
"//forms:checkBox[(@name='TOLINES_QF_BLK_SALES_ORDER_0')]").isSelected() && !PAR_CheckSalesOrderCheckBoxStatus)
	return;

// if the checkbox is currently checked and PAR_CheckSalesOrderCheckBoxStatus = false then uncheck it
if( forms.checkBox(687,
"//forms:checkBox[(@name='TOLINES_QF_BLK_SALES_ORDER_0')]").isSelected() && !PAR_CheckSalesOrderCheckBoxStatus)
	{
	forms.checkBox(687,
	"//forms:checkBox[(@name='TOLINES_QF_BLK_SALES_ORDER_0')]")
	.check(false); // uncheck sales order check box
	return;
	}
// if the checkbox is currently unchecked and PAR_CheckSalesOrderCheckBoxStatus = true then uncheck it
if( !forms.checkBox(687,
"//forms:checkBox[(@name='TOLINES_QF_BLK_SALES_ORDER_0')]").isSelected() && PAR_CheckSalesOrderCheckBoxStatus)
	{	
	forms.checkBox(687,
	"//forms:checkBox[(@name='TOLINES_QF_BLK_SALES_ORDER_0')]")
	.check(true); // check sales order check box
	return;
	}
}

public void enterPickWaveSalesorderNumber(String PAR_FromSalesOrderNumber, String PAR_ToSalesOrderNumber ) throws Exception
{
if(PAR_FromSalesOrderNumber == null )
	return;

forms.textField(689,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_SALES_ORDER_NUM_0')]").setText(PAR_FromSalesOrderNumber);

forms.textField(689,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_SALES_ORDER_NUM_0')]").invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}
forms.textField(690,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_SALES_ORDER_NUM_0')]").setText(PAR_ToSalesOrderNumber);

forms.textField(690,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_SALES_ORDER_NUM_0')]").invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}

} // end of enterPickWaveSalesorderNumber

public void enterSourceAndDestinationSubinventory(String PAR_SourceSubinventory, String PAR_DestinationSubinventory, String PAR_LotNumber, String PAR_DestinationAccount ) throws Exception
{
if(PAR_SourceSubinventory == null )
	return;

forms.textField(681,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_SUBINV_CODE_0')]").setText(PAR_SourceSubinventory);

forms.textField(681,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_SUBINV_CODE_0')]").invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}
forms.textField(682,
"//forms:textField[(@name='TOLINES_QF_BLK_LOT_NUMBER_0')]").setText(PAR_LotNumber);

forms.textField(682,
"//forms:textField[(@name='TOLINES_QF_BLK_LOT_NUMBER_0')]").invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}
forms.textField(683,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_SUBINV_CODE_0')]").setText(PAR_DestinationSubinventory);

forms.textField(683,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_SUBINV_CODE_0')]").invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}

forms.textField(684,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_ACCOUNT_0')]").setText(PAR_DestinationAccount);

forms.textField(684,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_ACCOUNT_0')]").invokeSoftKey("NEXT_FIELD"); // work order department
{
	think(1.0);
}
} // end of enterSourceAndDestinationSubinventory



public boolean enterTransactMoveOrderLinesTab(String PAR_ItemNumber, String PAR_FromDateRequired, String PAR_ToDateRequired, String PAR_projectNumber,
	String PAR_TransactionType,String PAR_LineStatus, String PAR_AlocationType) throws Exception
{

if (PAR_ItemNumber==null)
	return false;


forms.textField(671,
"//forms:textField[(@name='TOLINES_QF_BLK_ITEM_0')]").setText(PAR_ItemNumber);

forms.textField(671,
"//forms:textField[(@name='TOLINES_QF_BLK_ITEM_0')]")
.invokeSoftKey("NEXT_FIELD"); // item 
{
	think(1.0);
}

forms.textField(672,
"//forms:textField[(@name='TOLINES_QF_BLK_ITEM_DESCRIPTION_0')]")
.invokeSoftKey("NEXT_FIELD"); // item description
{
	think(1.0);
}

forms.textField(673,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_REQUIRED_DATE_0')]").setText(PAR_FromDateRequired);

forms.textField(673,
"//forms:textField[(@name='TOLINES_QF_BLK_FROM_REQUIRED_DATE_0')]")
.invokeSoftKey("NEXT_FIELD"); // date required from
{
	think(1.0);
}
forms.textField(674,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_REQUIRED_DATE_0')]").setText(PAR_ToDateRequired);


forms.textField(674,
"//forms:textField[(@name='TOLINES_QF_BLK_TO_REQUIRED_DATE_0')]")
.invokeSoftKey("NEXT_FIELD"); // date required To
{
	think(1.0);
}

forms.textField(675,
"//forms:textField[(@name='TOLINES_QF_BLK_PROJECT_NUMBER_0')]").setText(PAR_projectNumber);

forms.textField(675,
"//forms:textField[(@name='TOLINES_QF_BLK_PROJECT_NUMBER_0')]")
.invokeSoftKey("NEXT_FIELD"); // project
{
	think(1.0);
}

forms.textField(676,
"//forms:textField[(@name='TOLINES_QF_BLK_TRANSACTION_TYPE_NAME_0')]").setText(PAR_TransactionType);

forms.textField(676,
"//forms:textField[(@name='TOLINES_QF_BLK_TRANSACTION_TYPE_NAME_0')]")
.invokeSoftKey("NEXT_FIELD"); // transaction type
{
	think(1.0);
}

forms.list(677,
"//forms:list[(@name='TOLINES_QF_BLK_LINE_STATUS_0')]").selectItem(PAR_LineStatus);


forms.list(677,
"//forms:list[(@name='TOLINES_QF_BLK_LINE_STATUS_0')]")
.invokeSoftKey("NEXT_FIELD"); // line status
{
	think(1.0);
}
forms.list(678,
"//forms:list[(@name='TOLINES_QF_BLK_ALLOCATIONS_TYPE_0')]").selectItem(PAR_AlocationType);


forms.list(678,
"//forms:list[(@name='TOLINES_QF_BLK_ALLOCATIONS_TYPE_0')]")
.invokeSoftKey("NEXT_FIELD"); // allocation type
{
	think(1.0);
}

return true;
} // end of enterTransactMoveOrderLinesTab

public void clickOnMoveOrderTransactButton() throws Exception
{
forms.button(40,
	"//forms:button[(@name='TOLINES_CONTROL_TRANSACT_0')]")
	.click(); // click on the transact button
think(1.0);

} // end of clickOnMoveOrderTransactButton


public void enterHeadersDocumentNumbers(String PAR_FromDocumentNumber, String PAR_ToDocumentNumber) throws Exception
{
forms.textField(29,
"//forms:textField[(@name='TOLINES_QF_BLK_ORDER_NUM_FROM_0')]")
.setText(PAR_FromDocumentNumber);

think(1.0);

forms.textField(29,
	"//forms:textField[(@name='TOLINES_QF_BLK_ORDER_NUM_FROM_0')]")
	.invokeSoftKey("NEXT_FIELD"); // headers document number from
{
	think(1.0);
}
forms.textField(30,
"//forms:textField[(@name='TOLINES_QF_BLK_ORDER_NUM_TO_0')]")
.setText(PAR_ToDocumentNumber);

think(1.0);

forms.textField(30,
	"//forms:textField[(@name='TOLINES_QF_BLK_ORDER_NUM_TO_0')]")
	.invokeSoftKey("NEXT_FIELD"); // headers document number to
{
	think(1.0);
}
} // end of enterHeadersDocumentNumbers

public void enterHeadersDescription(String PAR_DocumentDescription) throws Exception
{
if (PAR_DocumentDescription == null)
	return;

forms.textField(31,
"//forms:textField[(@name='TOLINES_QF_BLK_ORDER_DESCRIPTION_0')]")
.setText(PAR_DocumentDescription);

think(1.0);

forms.textField(31,
	"//forms:textField[(@name='TOLINES_QF_BLK_ORDER_DESCRIPTION_0')]")
	.invokeSoftKey("NEXT_FIELD"); // headers description
{
	think(1.0);
}
} // end of enterHeadersDescription

public void enterHeadersOrderType(String PAR_DocumentOrderType) throws Exception
{

if (PAR_DocumentOrderType == null)
	return;

forms.list(32,
"//forms:list[(@name='TOLINES_QF_BLK_MOVE_ORDER_TYPE_0')]")
.selectItem(PAR_DocumentOrderType);

forms.list(32,
	"//forms:list[(@name='TOLINES_QF_BLK_MOVE_ORDER_TYPE_0')]")
	.invokeSoftKey("NEXT_FIELD"); // headers order type
{
	think(1.0);
}
} // end of enterHeadersOrderType

public void enterHeadersCreatedBy(String PAR_DocumentCreatedBy) throws Exception
{
if (PAR_DocumentCreatedBy == null)
	return;

forms.textField(33,
"//forms:textField[(@name='TOLINES_QF_BLK_CREATED_BY_NAME_0')]")
.setText(PAR_DocumentCreatedBy);

think(1.0);

forms.textField(33,
	"//forms:textField[(@name='TOLINES_QF_BLK_CREATED_BY_NAME_0')]")
	.invokeSoftKey("NEXT_FIELD"); // created by
{
	think(1.0);
}

} // end of enterHeadersCreatedBy

public void switchResponsibility(String PAR_ResponsibilityName)	throws Exception
{
/*
 * This function changes the responsiblity to PAR_ResponsibilityName
 * 
 * usage: switchResponsibility("GCSS-MC Inventory / Supply Shipping & Receiving NCO") ;
 * 
 */
		forms.window(31, "//forms:window[(@name='NAVIGATOR')]").activate(
				true);
		{
			think(1.0);
		}
		forms.window(30, "//forms:window[(@name='NAVIGATOR')]")
				.clickToolBarButton("Switch Responsibility...");  // ckick on switch responsiblity
		{
			think(33.11);
		}

		forms.listOfValues(32, "//forms:listOfValues").select(PAR_ResponsibilityName); // select this responsiblity
} // end of switchResponsibility

public void navigateToTransactMoveOrders(String PAR_InventoryOrgName) throws Exception
{
/*
 * 
 *  usage navigateToTransactMoveOrders(String PAR_InventoryOrgName)
 */

// check if the organization box shows up on the screen. if yes, then choose the inventory orgname.  
// the selectInventoryOrganization() will automatically return if the dialog box doe snot exist on the screen
 
selectInventoryOrganization(PAR_InventoryOrgName);

	{
		forms.captureScreenshot(60);
		{
			think(1.0);
		}
		forms.treeList(61, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
				.focusItem("Move Orders");
		{
			think(1.0);
		}
		forms.treeList(62, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
				.selectItem("Move Orders");
		{
			think(1.0);
		}
		forms.treeList(107, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
				.focusItem("Move Orders|Transact Move Orders");
		{
			think(1.0);
		}
		forms.treeList(108, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
				.selectItem("Move Orders|Transact Move Orders"); // select transact move orders
		{
			think(1.0);
		}
		
		// check again if the dialog box appears.  if yes, then choose the inventory org name
		selectInventoryOrganization(PAR_InventoryOrgName);
	}
}

public void clickOnClearButton() throws Exception
{
/*
 * this is the clear button in the Find move order transactdion dialog box
 */
/*
 * This clicks on the Clear button in the Find Move order dialog box 
 */
forms.button(27, "//forms:button[(@name='TOLINES_QF_BLK_CLEAR_0')]")
.click(); // clear button
{
	think(1.0);

}
} //  end of clickOnClearButton()

public void enterQueryManagerDocumentNumberFindRange(String PAR_FromSDNNumber, String PAR_ToSDNNumber) throws Exception
{
/*
 * This is the query manager Find STD From and STD To Fields.  
 * This is accessible from Shipping->Transactions navigation  
 */
		forms.captureScreenshot(27);
		{
			think(1.0);
		}
		forms.textField(28,
				"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
				.setText(PAR_FromSDNNumber);
		{
			think(1.0);
		}

		forms.textField(137,
				"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_HI_0')]")
				.setFocus();
		{
			think(1.0);
		}					
		forms.textField(28,
		"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_HI_0')]")
		.setText(PAR_ToSDNNumber);
		{
			think(1.0);
		}
		
		clickOnQueryManagerFindButton();  // click on the find button

} // end of enterDocumentNumberFindRange

public void enterQueryManagerDocumentNumberFindRange(String PAR_FromSDNNumber, 
		String PAR_ToSDNNumber,
		String PAR_imageNames) throws Exception
{
/*
* This is the query manager Find STD From and STD To Fields and a screenshot is taken before before the 
* find button is clicked
* 
* parameters:
* PAR_ToSDNNumber - high SDN number
* PAR_FromSDNNumber - low SDN Number
* PAR_imageNames - image name for the screenshot
*/
forms.captureScreenshot(27);
{
think(1.0);
}
forms.textField(28,
"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_LO_0')]")
.setText(PAR_FromSDNNumber);
{
think(1.0);
}

forms.textField(137,
"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_HI_0')]")
.setFocus();
{
think(1.0);
}					
forms.textField(28,
"//forms:textField[(@name='QM_DLVB_DLVB_TRACKING_NUMBER_HI_0')]")
.setText(PAR_ToSDNNumber);
{
think(1.0);
}

// take a screenshot
ScreenShot(false,true,PAR_imageNames);

clickOnQueryManagerFindButton();  // click on the find button

} // end of enterDocumentNumberFindRange


public void clickOnQueryManagerFindButton() throws Exception
{
forms.button(29, "//forms:button[(@name='QUERY_MANAGER_FIND_0')]")
.click();
{
	think(1.0);
}
} // end of clickOnQueryManagerFindButton

public void navigateToShippingTransactionsForm() throws Exception		
{
forms.captureScreenshot(63);
{
	think(0.163);
}
forms.treeList(64, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
		.focusItem("Shipping");
{
	think(0.229);
	think(0.085);
}
forms.treeList(87, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
		.selectItem("Shipping");
{
	think(1.524);
	think(0.003);
}
forms.treeList(110, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
		.focusItem("Shipping|Transactions");
{
	think(0.18);
	think(0.001);
}
forms.treeList(133, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
		.selectItem("Shipping|Transactions");
} // end of navigateToShippingTransactionsForm

public boolean validatePickPackLineExists(int PR_LineNumber) throws Exception
{
	/* 
	 * this will check if there is a material line that can be picked, pa ked and shipped
	 */
	boolean LineToPickPackExist = false;
	String myLabelValue = null;
	
	forms.captureScreenshot(33);
	{
		think(1.0);
	}
	if (!forms.textField(34,
			"//forms:textField[(@name='DLVB_DETAIL_LABEL_"+PR_LineNumber+"')]").exists())
		return false;
	
	forms.textField(34,
		"//forms:textField[(@name='DLVB_DETAIL_LABEL_"+PR_LineNumber+"')]").click(); // clicke don the detail field.  you have to make sure this is populated to ensure thatr there is a record to process
	{
		think(1.0);
	}
	myLabelValue = forms.textField(34,
		"//forms:textField[(@name='DLVB_DETAIL_LABEL_"+PR_LineNumber+"')]").getText();
	
	if (myLabelValue.isEmpty())
		return false;
	else
		return true;
} // validatePickPackLineExists

public void selectRecordToPickPackProcess() throws Exception
{
	/*
	 * This is executed only if validatePickPackLineExists returns a true statement which means there is a line to pick pack and ship
	 */
	{
		think(1.0);
	}
	forms.textField(35,
			"//forms:textField[(@name='DLVB_DRILLDOWN_RECORD_INDICATOR_0')]")
			.click(); // select the record to process (this is that blue box on the left
	{
		think(1.0);
	}
	forms.textField(342,
	"//forms:textField[(@name='DLVB_DRILLDOWN_RECORD_INDICATOR_0')]")
	.setFocus();
	
} // end of selectRecordToPickPackProcess

public void clickOnPickAndShipButton() throws Exception
{
	
		forms.captureScreenshot(344); // this brings you  to the Line/LPN details screen
		{
			think(1.0);
		}
		forms.button(345,
				"//forms:button[(@name='DLVB_BUTTONS_BUTTON1_0')]").click(); // print Pick and Ship button. an alert message saying Number of concurrent request launched successfully: 1. Number of requests that fialed: 0.
	
		think(1.0);
} // end of clickOnPickAndShipButton

public void clickOnPickPackAlertMessageOKButton() throws Exception
{
	/*
	 * an alert message comes up afgter the Pick and Ship button is clicked.
	 * an alert message saying Number of concurrent request launched successfully: 1. Number of requests that fialed: 0.
	 * This function will click on the OK button of that message box
	 */
	{
		forms.captureScreenshot(347);
		{
			think(1.0);
		}
		
		if (!forms.button(348, "//forms:button[(@name='MESSAGE_OK_0')]").exists())
			return;
		

				
		forms.button(348, "//forms:button[(@name='MESSAGE_OK_0')]").click(); // clickon the OK button. this brings you back to the Line/LPN details screen
	}
	
} // end of clickOnPickPackAlertMessageOKButton

public void clickOnLineLPNDoneButton() throws Exception
{
	forms.captureScreenshot(350);
	{
		think(1.0);
	}
	forms.button(351,
			"//forms:button[(@name='DLVB_BUTTONS_DETAIL_DONE_0')]")
			.click(); // click on Done button
	{
		think(1.0);
	}
} // end of clickOnLineLPNDoneButton

public void clickOnTransactMoveOrderIcon() throws Exception
{
	/*
	 * this method clicks on the blue man icon on the top of the shipping form
	 */
	{
		think(1.0);
	}
	forms.window(149, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.clickToolBarButton("Transact Move Order"); // his is the tansact move order icon
	
	forms.captureScreenshot(568);
	{
		think(1.0);
	}
} // end of clickOnTransactMoveOrderIcon

public void clickOnViewUpdateAllocationsButton() throws Exception
{
	/*
	 * This is to click on the View / Update Allocations button from the Transact Move Orders form.
	 * You call this after clicking on the Move order Icon
	 */
	while(true)
	{
		if (forms.button(43, "//forms:button[(@name='TOLINES_CONTROL_OPEN_0')]")
		.exists())
			break;
		else
			think(1.0);
	}
		forms.captureScreenshot(41);
		{
			think(1.0);
		}
		forms.checkBox(42,
		"//forms:checkBox[(@name='TOLINES_BLK_SUBMIT_0')]")
		.setFocus();
		{
			think(1.0);
		}
		forms.button(43, "//forms:button[(@name='TOLINES_CONTROL_OPEN_0')]")
		.click(); // click on view/Update llocations button

		think(1.0);
} // end of clickOnViewUpdateAllocationsButton


public void clickOnTransactMoveOrderLotSerialButton() throws Exception
{
	/*
	 * This clicks on the Lot/Serial button that is found in the Move Order Line Allocations form
	 */
	
	if (!forms.button(46,
			"//forms:button[(@name='CONTROL_LOT_SERIAL_BUTTON_0')]").exists())
		return;
	
	// check if the button is enabled. if not, return
	if (!forms.button(46,
	"//forms:button[(@name='CONTROL_LOT_SERIAL_BUTTON_0')]").isEnabled())
			return;
	
	// at this point, this button is existing and is enabled to be clickable
	forms.captureScreenshot(45);
	{
		think(1.0);
	}
	forms.button(46,
			"//forms:button[(@name='CONTROL_LOT_SERIAL_BUTTON_0')]")
			.click(); // click on lot/serial button
	think(1.0);
	
} // end of clickOnTransactMoveOrderLotSerialButton

public void generateLotSerial_SerialNumber() throws Exception
{
	/*
	 * This is the form where you find a serial number after clicking on the Lot/Serial Number.
	 * To know what was picked up as the starting serial number, call getStartSerialNumber() after this function
	 */
	forms.textField(49,
	"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
	.setFocus();
	{
		think(1.0);
	}
	forms.textField(50,
	"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
	.openDialog(); // open the serial number LOV button

	forms.listOfValues(53, "//forms:listOfValues").find("%"); // enter a serial number mask
	{
		think(2.0);
	}
	forms.listOfValues(54, "//forms:listOfValues").choose(1);  // select the serial number
} // end of generateLotSerial_SerialNumber


public String getStartSerialNumber() throws Exception
{
	// this is a function to get the Start Serial number that is generated.  You only call this function AFTER you have run generateLotSerial_SerialNumber()
	String MyStartSerialNumber = null;
	
	forms.captureScreenshot(48);
	{
		think(1.0);
	}
	forms.textField(49,
			"//forms:textField[(@name='SERIAL_ENTRY_CURRENT_RECORD_INDICATOR_0')]")
			.setFocus();
	{
		think(1.0);
	}
	MyStartSerialNumber = forms.textField(50,
			"//forms:textField[(@name='SERIAL_ENTRY_FM_SERIAL_NUMBER_0')]")
			.getText(); // get the serial number that was created
	
	return MyStartSerialNumber;
}

public String getEndSerialNumber() throws Exception
{
	// This is the End serial number  that is generated when you try to generate a serial number from the serial entry screen. You only call this function AFTER you have run generateLotSerial_SerialNumber()
	String myEndSerialNumber = null;
	
	forms.captureScreenshot(56);
	{
		think(1.0);
	}
	myEndSerialNumber = forms.textField(57,
			"//forms:textField[(@name='SERIAL_ENTRY_TO_SERIAL_NUMBER_0')]")
			.getText(); // this is the last serial number
	return myEndSerialNumber;
	
} // end of getEndSerialNumber

public void clickOnSerialNumberCreationDONEButton() throws Exception
{
	/*
	 * This is the DONE button that you will see after you have generated a serial number
	 */
	forms.captureScreenshot(62);
	{
		think(1.0);
	}
	forms.button(63,
			"//forms:button[(@name='NAVIGATION_CONTROL_OK_0')]")
			.click(); // click on the serial number Done button
	
	think(1.0);
} // end of clickOnSerialNumberCreationDONEButton

public void clickOnTransactMoveOrderLineAllocationTransactButton() throws Exception
{
	if(!forms.button(66, "//forms:button[(@name='CONTROL_DONE_0')]").exists())
		return;
	
	forms.captureScreenshot(65);
	{
		think(1.0);
	}
	forms.button(66, "//forms:button[(@name='CONTROL_DONE_0')]") // click on the trasact button.  Make sure you check if the message form showing records applied and saved
			.click();
	{
		think(1.0);
	}
} // end of clickOnTransactMoveOrderLineAllocationTransactButton

public void clickOnDeliveryTab() throws Exception
{
	if (!forms.tab(79, "//forms:tab[(@name='ENTITIES_TABS')]").exists())
		return;

	forms.textField(78,
			"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
			.setFocus();
	{
		think(1.0);
	}
	forms.tab(79, "//forms:tab[(@name='ENTITIES_TABS')]").select(
			"Delivery");
	{
		think(1.625);
	}
	forms.captureScreenshot(77);
	{
		think(1.0);
	}
} // end of clickOnDeliveryTab

public boolean checkShippingLineStatus(int PAR_LineNumber, String PAR_LineStatusCode) throws Exception
{
	/*
	 * this returns true if the line being tested has a status code that is equal to the LineStatusCode parameter
	 * for example
	 * checkShippingLineStatus(0, "Released To Warehouse")
	 * returns: True if the status of the line is equal to the parameter
	 * returns: false if the status of the is not equal to the parameter 
	 * 
	 * PAR_LineNumber is any nuymber from 0 or higher corresponding to the shipping lines where line 1 = 0, LIne 2 = 1 etcetera.
	 */
	boolean ShippingLineStatusMatchesParameter = false;
	String myLIneStatusCode = null;

	if (!forms.textField(570,
		"//forms:textField[(@name='DLVB_RELEASED_STATUS_NAME_"+PAR_LineNumber+"')]").exists())
		return false;
	
	forms.captureScreenshot(568);
	{
		think(1.0);
	}
	forms.textField(570,
	"//forms:textField[(@name='DLVB_RELEASED_STATUS_NAME_"+PAR_LineNumber+"')]").click(); // line status says "Released To Warehouse"

	myLIneStatusCode = getShippingLineStatus(PAR_LineNumber);
	
	if (myLIneStatusCode.equalsIgnoreCase(PAR_LineStatusCode))
		return true;
	else
		return false;
} // end of checkShippingLineStatus

public String getShippingLineStatus(int PAR_LineNumber) throws Exception
{
	/*
	 * this returns  status code of the shikpping line equal to the PAR_LineNumber parameter
	 * for example
	 * getShippingLineStatus(0)
	 * 
	 * PAR_LineNumber is any number from 0 or higher corresponding to the shipping lines where line 1 = 0, LIne 2 = 1 etcetera.
	 */

	String myLIneStatusCode = null;

	if (!forms.textField(570,
		"//forms:textField[(@name='DLVB_RELEASED_STATUS_NAME_"+PAR_LineNumber+"')]").exists())
		return null;
	
	forms.captureScreenshot(568);
	{
		think(1.0);
	}
	myLIneStatusCode = forms.textField(570,
	"//forms:textField[(@name='DLVB_RELEASED_STATUS_NAME_"+PAR_LineNumber+"')]").getText();
	

	return myLIneStatusCode;
} // end of getShippingLineStatus



public boolean checkShippingLineNextStep(int PAR_LineNumber, String PAR_LineNextStepCode) throws Exception
{
	/*
	 * this returns true if the line being tested has a NextStep code that is equal to the PAR_LineNextStepCode parameter
	 * for example
	 * checkShippingLineNextStep(0, "Transact Move Order")
	 * returns: True if the status of the line is equal to the parameter
	 * returns: false if the status of the is not equal to the parameter 
	 * 
	 * PAR_LineNumber is any nuymber from 0 or higher corresponding to the shipping lines where line 1 = 0, LIne 2 = 1 etcetera.
	 */
	boolean ShippingLineNextStepMatchesParameter = false;
	String myLIneNextStepCode = null;
	
	if (!forms.textField(574,
		"//forms:textField[(@name='DLVB_NEXT_STEP_"+PAR_LineNumber+"')]").exists())
		return false;
	
	forms.captureScreenshot(568);
	{
		think(1.0);
	}
	forms.textField(574,
		"//forms:textField[(@name='DLVB_NEXT_STEP_"+PAR_LineNumber+"')]").click(); // line status says "Released To Warehouse"
	
	myLIneNextStepCode = getShippingLineStatus(PAR_LineNumber);
	
	if (myLIneNextStepCode.equalsIgnoreCase(PAR_LineNextStepCode))
		return true;
	else
		return false;
} // end of checkShippingLineNextStep

public String getShippingLineNextStep(int PAR_LineNumber) throws Exception
{
	/*
	 * this returns  Next Step code of the shipping line equal to the PAR_LineNumber parameter
	 * for example
	 * getShippingLineNextStep(0)
	 * 
	 * PAR_LineNumber is any number from 0 or higher corresponding to the shipping lines where line 1 = 0, LIne 2 = 1 etcetera.
	 */

	String myLIneNextStepCode = null;

	if (!forms.textField(574,
		"//forms:textField[(@name='DLVB_NEXT_STEP_"+PAR_LineNumber+"')]").exists())
		return null;
	
	forms.captureScreenshot(568);
	{
		think(1.0);
	}
	
	myLIneNextStepCode = forms.textField(574,
		"//forms:textField[(@name='DLVB_NEXT_STEP_"+PAR_LineNumber+"')]").getText();
	

	return myLIneNextStepCode;
} // end of getShippingLineNextStep

public void getShippingLinePickOrderNumber(int PAR_LineNumber) throws Exception
{
	if (!forms.textField(577,
		"//forms:textField[(@name='DLVB_SOURCE_HEADER_NUMBER_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(577,
			"//forms:textField[(@name='DLVB_SOURCE_HEADER_NUMBER_"+PAR_LineNumber+"')]")
			.click(); // this is the pick and shp order number
	{
		think(1.0);
	}
} // end of getShippingLinePickOrderNumber

public void getShippingLineSDNNumber(int PAR_LineNumber) throws Exception
{
	if (!forms.textField(578,
		"//forms:textField[(@name='DLVB_TRACKING_NUMBER_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(578,
		"//forms:textField[(@name='DLVB_TRACKING_NUMBER_"+PAR_LineNumber+"')]")
			.click(); // this is the pick and shp SDN number
	{
		think(1.0);
	}
} // end of getShippingLineSDNNumber

public void setShippingLineSDNNumber(int PAR_LineNumber, String PAR_ShippingLineSDNNumber) throws Exception
{
	if (!forms.textField(578,
		"//forms:textField[(@name='DLVB_TRACKING_NUMBER_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(578,
		"//forms:textField[(@name='DLVB_TRACKING_NUMBER_"+PAR_LineNumber+"')]")
			.setText(PAR_ShippingLineSDNNumber); // this is the pick and shp order number
	{
		think(1.0);
	}
} // end of setShippingLineSDNNumber

public void getShippingLineOrganization(int PAR_LineNumber) throws Exception
{
	if (!forms.textField(580,
		"//forms:textField[(@name='DLVB_ORGANIZATION_CODE_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(580,
		"//forms:textField[(@name='DLVB_ORGANIZATION_CODE_"+PAR_LineNumber+"')]")
			.click(); // this is the pick and shp organization
	{
		think(1.0);
	}
} // end of getShippingLineOrganization

public void setShippingLineOrganization(int PAR_LineNumber, String PAR_ShippingLineOrganization) throws Exception
{
	if (!forms.textField(580,
		"//forms:textField[(@name='DLVB_ORGANIZATION_CODE_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(580,
		"//forms:textField[(@name='DLVB_ORGANIZATION_CODE_"+PAR_LineNumber+"')]")
			.setText(PAR_ShippingLineOrganization); // this is the pick and shp organization
	{
		think(1.0);
	}
} // end of setShippingLineOrganization

public void getShippingLineSubinventoryCode(int PAR_LineNumber) throws Exception
{
	if (!forms.textField(583,
		"//forms:textField[(@name='DLVB_SUBINVENTORY_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(583,
		"//forms:textField[(@name='DLVB_SUBINVENTORY_"+PAR_LineNumber+"')]")
			.click(); // this is the pick and shp line subinventory code
	{
		think(1.0);
	}
} // end of getShippingLineSubinventoryCode

public void setShippingLineSubinventoryCode(int PAR_LineNumber, String PAR_ShippingLineSubinventoryCode) throws Exception
{
	if (!forms.textField(583,
		"//forms:textField[(@name='DLVB_SUBINVENTORY_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(583,
		"//forms:textField[(@name='DLVB_SUBINVENTORY_"+PAR_LineNumber+"')]")
			.setText(PAR_ShippingLineSubinventoryCode); // this is the pick and shp line subinventory code
	{
		think(1.0);
	}
} // end of setShippingLineSubinventoryCode


public void getShippingLineMoveOrder(int PAR_LineNumber) throws Exception
{
	if (!forms.textField(584,
		"//forms:textField[(@name='DLVB_MOVE_ORDER_NUMBER_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(584,
		"//forms:textField[(@name='DLVB_MOVE_ORDER_NUMBER_"+PAR_LineNumber+"')]")
			.click(); // this is the pick and shp line Move Order
	{
		think(1.0);
	}
} // end of getShippingLineMoveOrder

public void getShippingLineMoveOrderLineNumber(int PAR_LineNumber) throws Exception
{
	if (!forms.textField(586,
		"//forms:textField[(@name='DLVB_MOVE_ORDER_LINE_NUMBER_"+PAR_LineNumber+"')]").exists())
		return;
	
	forms.captureScreenshot(568);

	{
		think(1.0);
	}
	forms.textField(586,
		"//forms:textField[(@name='DLVB_MOVE_ORDER_LINE_NUMBER_"+PAR_LineNumber+"')]")
			.click(); // this is the pick and shp line Move Order LIne Number
	{
		think(1.0);
	}
} // end of getShippingLineMoveOrderLineNumber

public void closeShippingTransactionForm() throws Exception
{
	if (!forms.window(648, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]").exists())
		return;
	
	forms.captureScreenshot(568);
	{
		think(1.792);
	}
	forms.window(648, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.close(); // close shipping transactions form
	
	{
		think(1.0);
	}
} // end of closeShippingTransactionForm

public boolean clickOnShippingTransactionsDeliveryTab() throws Exception
{
	if (!forms.tab(33, "//forms:tab[(@name='ENTITIES_TABS')]").exists())
		return false;
	
	forms.captureScreenshot(31);
	{
		think(1.0);
	}

	forms.tab(33, "//forms:tab[(@name='ENTITIES_TABS')]").select(
			"Delivery"); // click delivery tab
	{
		think(1.0);
	}
	return true;
}// end of clickOnShippingTransactionsDeliveryTab

public boolean clickOnShipConfirmButton() throws Exception
{
	if (!forms.button(35, "//forms:button[(@name='DLVY_BUTTONS_BUTTON5_0')]").exists())
		return false;
	
	forms.captureScreenshot(31);
	{
		think(1.0);
	}

	forms.button(35, "//forms:button[(@name='DLVY_BUTTONS_BUTTON5_0')]")
	.click(); // clik on shp confirm button
	{
		think(1.0);
	}
	return true;
}// end of clickOnShipConfirmButton



public void findInventoryOrganization(String PAR_InventoryOrg) throws Exception
{
	/*
	 * selects the inventory org from the popup dialog box
	 * 
	 * usage:findInventoryOrganization("%MRA%");
	 */
	if (!forms.listOfValues(21, "//forms:listOfValues").exists())
		return;
	
	forms.captureScreenshot(20);
	{
		think(1.0);
	}
	forms.listOfValues(21, "//forms:listOfValues").find(PAR_InventoryOrg); // enter the inventory organization
	
	think(1.0);
} // end of findInventoryOrganization


public void enterShipConfirmShippingMethod(String PAR_ShippingMethod) throws Exception
{
	if (!forms.textField(59,
			"//forms:textField[(@name='DLVY_SHIP_METHOD_NAME_0')]").exists())
		return;

	
	{
		think(1.0);
	}
	forms.textField(59,
			"//forms:textField[(@name='DLVY_SHIP_METHOD_NAME_0')]")
			.click();
	{
		think(1.0);
	}
	forms.textField(60,
			"//forms:textField[(@name='DLVY_SHIP_METHOD_NAME_0')]")
			.setText(PAR_ShippingMethod); // ship methd
	{
		think(1.0);
	}
	forms.captureScreenshot(57);
	{
		think(1.0);
	}
	forms.textField(60,
	"//forms:textField[(@name='DLVY_SHIP_METHOD_NAME_0')]")
	.invokeSoftKey("NEXT_FIELD");
} // end of enterShipConfirmShippingMethod

public void enterShipConfirmDocumentSet(String PAR_DocumentSet) throws Exception
{
	if (!forms.textField(71,
			"//forms:textField[(@name='SHIP_CONFIRM_DOCUMENT_SET_0')]").exists())
		return;

	forms.textField(71,
			"//forms:textField[(@name='SHIP_CONFIRM_DOCUMENT_SET_0')]")
			.setText(PAR_DocumentSet); //document set
	{
		think(1.0);
	}
	forms.textField(72,
			"//forms:textField[(@name='SHIP_CONFIRM_DOCUMENT_SET_0')]")
			.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
} // end of enterShipConfirmDocumentSet

public void clickOnShipConfirmOKButton() throws Exception
{
	if (!forms.button(73, "//forms:button[(@name='SHIP_CONFIRM_OK_0')]").exists())
		return;
	{
		think(1.0);
	}
	forms.button(73, "//forms:button[(@name='SHIP_CONFIRM_OK_0')]")
			.click(); // ship confirm OK button
	
	forms.captureScreenshot(70);
	{
		think(1.0);
	}
	
} // end of clickOnShipConfirmOKButton

public void closeShipConfirmForm() throws Exception
{
	forms.captureScreenshot(79);
	{
		think(1.0);
	}
	forms.window(80, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.close(); // close shipping transactions form
	
} // end of closeShipConfirmForm

public void enterReleaseOrdersPickingRule(String PAR_PickingRule) throws Exception
{
	if(!forms.textField(272,
			"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]")
			.exists())
		return;
	
	forms.textField(272,
			"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]")
			.setFocus();
	{
		think(1.0);
	}
	forms.textField(272,
	"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]")
	.setText(PAR_PickingRule);
	
	forms.captureScreenshot(271);
	{
		think(1.0);
	}
	forms.textField(272,
	"//forms:textField[(@name='RELEASE_PICKING_RULE_0')]")
	.invokeSoftKey("NEXT_FIELD");
} // end of enterReleaseOrdersPickingRule

public void clickOnPickReleaseExecuteNowButton() throws Exception
{
	/*
	 * this is one of the buttons in the Pick release processing form.  You can click this to execute pick release immediately
	 */
	if (!forms.button(276, "//forms:button[(@name='RELEASE_ONLINE_0')]")
			.exists())
		return;

	{
		think(1.0);
	}
	forms.button(276, "//forms:button[(@name='RELEASE_ONLINE_0')]")
			.click(); // click on execut enow button
	{
		think(1.0);
	}
} // end of clickOnPickReleaseExecuteNowButton

public String generateUniqueSerialNumber() throws Exception {
	getVariables().set("mySerialNumber", "{{@timestampsecs}}",
		Variables.Scope.GLOBAL);
	String mygeneratedNumber = getVariables().get("mySerialNumber");
	int lengthOfString = mygeneratedNumber.length();
	String finalString = "";
	// info("length of string ==> "+lengthOfString);


	
	for (int a = 0; a < lengthOfString; a++) {

		if ((a + 1) > lengthOfString || a == lengthOfString || (a + 1) + 1 > lengthOfString)
			break;

		// info("myNumber.substring("+a+",1) == >"
		// +myNumber.substring(a,a+1));
		// info("myNumber.substring("+(a)+",2) == >"
		// +myNumber.substring(a+1,(a+1)+1));

		if (mygeneratedNumber.substring(
			a,
			a + 1).equalsIgnoreCase(
				mygeneratedNumber.substring(
				a + 1,
				(a + 1) + 1)))
			finalString = finalString + String.valueOf((char) ((a + 1) + 64));
		else {
			finalString = finalString + mygeneratedNumber.substring(
				a,
				a + 1);
			// info(finalString);
		}

	}
	return finalString;
} // end of generateUniqueSerialNumber

public boolean submitConcurrentRequest(String PAR_Concurrent_ReportName) throws Exception
{
	try
	{
		// initiate View-Requests
		clickOnViewRequests("NAVIGATOR");
		
		// click on Submit New Request button
		clickOnSubmitNewRequestsButton();
		
		// enter concurrent report name
		enterConcurrentOrReportName(PAR_Concurrent_ReportName);
		
		// enter parameters
		//example usage: enterReportParameter("Parent AAC", "MMFAF7");
		//enterReportParameter(db_Paramater_Label1, db_parameter_Value1);
		//enterReportParameter(db_Paramater_Label1, db_parameter_Value1);
		//enterReportParameter(db_Paramater_Label1, db_parameter_Value1);
		//enterReportParameter(db_Paramater_Label1, db_parameter_Value1);
		// keep on adding parameters if you want to
		
		
		// click on the OK button
		clickOKOnParameterWindow();
		
		// submit the request
		clickOKOnSubmitRequestButton();
		boolean RequestSubmittedAndSaved = checkIfTheRecordWasSaved("records applied and saved");
		
		//get Request ID and then click No button
		getVariables().set("GLBL_RequestID",getRequestIDThenClickButton("No"));
		
		//Find Requests and click reresh until complete
		findTheSpecificRequestByProgramName("Consolidated Asset Listing (Spreadsheet)");
		
		//Close Requests Jobs Window
		closeViewRequestsJobsWindow(); // close the jobs window
		
		return true;
		
	} catch (Exception e)
	{
		info ("Error while executing submitConcurrentRequest()");
		info("Exception ==> "+e);
		return false;
	}
} // end of submitConcurrentRequest

public boolean connectToSelectedDatabase(String PAR_databaseNameToInitialize) throws Exception {
	// This connects to a database defined by the parameter
	// PAR_databaseNameToInitialize.
	// after connecting to the database, it saves the database name into a
	// global variable GLB_databaseInUse
	// history
	// Manny gochuico, CACI 
	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
	// connect to the database
	try
	{
	utilities.getSQLService().connect(
		PAR_databaseNameToInitialize);
	
	getVariables().set(
		"GLB_databaseInUse",
		PAR_databaseNameToInitialize,
		Variables.Scope.GLOBAL);
	} catch (Exception e)
	{
		warn("*** database definition failed to complete *** ");
		fail("*** Exception : "+e);
		return false;
	}
	
	return true;
} // end of connectToSelectedDatabase

public boolean defineSelectedDatabase(String PAR_databaseSID, String PAR_databaseHostName, String PAR_databasePortNumber, String PAR_databaseServiceName, String PAR_databaseUsername, String PAR_databasePassword ) throws Exception
{
	/*
	 * this function tries to define a database during runtime
	 * the funciton returns:
	 *  true if the database definition is successful
	 *  false if the databvase definition is not successful
	 * 
	 */
	try
	{
		utilities.getSQLService().define(
			PAR_databaseSID,
			"oracle.jdbc.driver.OracleDriver",
			"jdbc:oracle:thin:@" + PAR_databaseHostName + ":" + PAR_databasePortNumber + "/" + PAR_databaseServiceName,
			PAR_databaseUsername,
			PAR_databasePassword);
	} catch (Exception e)
	{
		warn("*** database definition failed to complete *** ");
		fail("*** Exception : "+e);
		return false;
	}
	
	return true;
} // end of defineSelectedDatabase

public boolean defineSelectedDatabase(String PAR_databaseSID, 
		String PAR_databaseHostName,
		String PAR_DatabaseHostIP, 
		String PAR_PrimarydatabasePortNumber, 
		String PAR_SecondarydatabasePortNumber, 
		String PAR_databaseServiceName, 
		String PAR_databaseUsername, 
		String PAR_databasePassword ) throws Exception
{
	/*
	 * this function tries to define a database for GCMS-MC during runtime
	 * the funciton returns:
	 *  true if the database definition is successful
	 *  false if the databvase definition is not successful
	 *  
	 *  parameters:
	 *  String PAR_databaseSID
	 *  String PAR_databaseHostName,
	 *	String PAR_DatabaseHostIP, 
	 *	String PAR_PrimarydatabasePortNumber, 
	 *	String PAR_SecondarydatabasePortNumber, 
	 *	String PAR_databaseServiceName, 
	 *	String PAR_databaseUsername, 
	 *	String PAR_databasePassword
	 *
	 *  Sample usage:
	 *  defineSelectedDatabase("geneda", 
			"udeadm01vm01",
			"10.100.3.125", 
			"1600", 
			"1562", 
			"geneda",
			"readapps", 
			"readgeneda" );
	 * 
	 * Manny gochuico - CACI 2020, 2021
	 */
	try
	{
		
		utilities.getSQLService().define(
			PAR_databaseSID,
			"oracle.jdbc.driver.OracleDriver",
			"jdbc:oracle:thin:@(description=(address_list=" + 
			"(address=(protocol=tcp)(port="+PAR_PrimarydatabasePortNumber+")(host="+PAR_DatabaseHostIP+")) " + 
			"(address=(protocol=tcp)(host="+PAR_databaseHostName+")(port="+PAR_SecondarydatabasePortNumber+"))) " + 
			"(connect_data=(SERVICE_NAME="+PAR_databaseServiceName+")) " + 
			"(source_route=yes))", PAR_databaseUsername,
			PAR_databasePassword);

	} catch (Exception e)
	{
		warn("*** database definition failed to complete *** ");
		warn("*** Exception : "+e);
		return false;
	}
	
	return true;
} // end of defineSelectedDatabase

public boolean defineSelectedDatabase(String PAR_databaseInstanceName)  throws Exception
{
	/*
	 * this function tries to define a database for GCMS-MC during runtime
	 * the funciton returns:
	 *  true if the database definition is successful
	 *  false if the databvase definition is not successful
	 *  
	 *  parameters:
	 *  String PAR_databaseInstanceName
	 *  
	 *  Word of caution:
	 *  This function uses SS_getDatabaseInformation()( that will create global openscript variables or 
	 *  ran a function that sets up the following openscript variables using the gatVariables().set() method.
	 *  GLBL_EBS_SID, 
	 *  GLBL_EBS_Hostname,
	 *  GLBL_EBS_dbHostIP, 
	 *  GLBL_EBS_dbPrimaryPortNumber, 
	 *	GLBL_EBS_dbSecondaryPortNumber, 
	 *	GLBL_EBS_dbServiceName, 
	 *  GLBL_EBS_DBUserName, 
	 *	GLBL_EBS_DBUserPassword
	 *
	 *  Sample usage:
	 *  defineSelectedDatabase("geneda");
	 * 
	 * Manny gochuico - CACI 2020, 2021
	 */
	try
	{
		// try to define the database instance and try to connect
		SS_getDatabaseInformation("EBS_URL.xlsx", "EBSURLFilePath", "EBS_URL", PAR_databaseInstanceName);
		// ++++++++++++ get the database-related Global variables +++++++++++++++
		String GLBL_EBS_SID = getVariables().get(
			"GLBL_EBS_SID",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_DBUserName = getVariables().get(
			"GLBL_EBS_DBUserName",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_DBUserPassword = getVariables().get(
			"GLBL_EBS_DBUserPassword",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_Hostname = getVariables().get(
			"GLBL_EBS_Hostname",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_PortNumber = getVariables().get(
			"GLBL_EBS_PortNumber",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_UserName = getVariables().get(
			"GLBL_EBS_UserName",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbHostIP = getVariables().get(
			"GLBL_EBS_dbHostIP",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbPrimaryPortNumber = getVariables().get(
			"GLBL_EBS_dbPrimaryPortNumber",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbSecondaryPortNumber = getVariables().get(
			"GLBL_EBS_dbSecondaryPortNumber",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbServiceName = getVariables().get(
			"GLBL_EBS_dbServiceName",
			Variables.Scope.GLOBAL);
	
		
		utilities.getSQLService().define(
			PAR_databaseInstanceName,
			"oracle.jdbc.driver.OracleDriver",
			"jdbc:oracle:thin:@(description=(address_list=" + 
			"(address=(protocol=tcp)(port="+GLBL_EBS_dbPrimaryPortNumber+")(host="+GLBL_EBS_dbHostIP+")) " + 
			"(address=(protocol=tcp)(host="+GLBL_EBS_Hostname+")(port="+GLBL_EBS_dbSecondaryPortNumber+"))) " + 
			"(connect_data=(SERVICE_NAME="+GLBL_EBS_dbServiceName+")) " + 
			"(source_route=yes))", GLBL_EBS_DBUserName,
			GLBL_EBS_DBUserPassword);

	} catch (Exception e)
	{
		warn("*** database definition failed to complete *** ");
		warn("*** Exception : "+e);
		return false;
	}
	
	return true;
} // end of defineSelectedDatabase

public int executeSQLScriptAndExportResults(String PAR_SQLScriptToExecute, String PAR_exportResultsPath, String PAR_ExportResultsName, String PAR_databaseInstanceName) throws Exception
{
	/*
	 *  This reads a SQL from a source and exports the results to an excel spreadsheet
	 *  This returns:
	 *  the number of records read and exported if the SQL was successful and the results of the query was exported to an excel spreadsheet
	 *  Zero if there are no records returned or  if the procedure failed for any reason.  This returns a warn message
	 *  
	 *  Exception reporting
	 *  throws a FAIL if the database cannot be accessed, defined, or connected to
	 *  
	 *  parameters:
	 *  PAR_SQLScriptToExecute - this is the sql to execute.  this can be from a csv file or an excel spreadsheet of static text
	 *  PAR_exportResultsPath - this is the complete path of where the file will reside. this may be EBSURLFilePath or static test.  It will always check for EBSURLFilePath before using this parameter
	 *  PAR_ExportResultsName - this is the name of the resulting excelsheet.  This must be complete including the file extension
	 *  PAR_databaseInstanceName - this is the database where the SQL will be run
	 *  
	 *  Calls the following methods:
	 *  public void SS_getDatabaseInformation(String ExcelSheetName, String pathName, String ExcelTabName, String EBSInstanceName)
	 *  public boolean defineSelectedDatabase(String PAR_databaseSID, String PAR_databaseHostName, String PAR_databasePortNumber, String PAR_databaseServiceName, String PAR_databaseUsername, String PAR_databasePassword )
	 *  public boolean connectToSelectedDatabase(String PAR_databaseNameToInitialize)
	 *  
	 *  sample usage:
	 *  executeSQLScriptAndExportResults("SELECT * FROM XXMC.XXMC_INV_PO_TXN_IF_STG WHERE STANDARD_DOCUMENT_NUMBER = '<>'",
	 *  									"C:\\oracle\\OracleATS\\OFT\\DataBank\\",
	 *  									"TC_12_Step5_SQL.xlsx",
	 *  									"geneda");
	 *  
	 *  PreRequisites:
	 *  This requires that the database has been defined prior to calling this function by calling the functions in sequence:
	 *  defineSelectedDatabase(String PAR_databaseSID, String PAR_databaseHostName, String PAR_databasePortNumber, String PAR_databaseServiceName, String PAR_databaseUsername, String PAR_databasePassword )
	 *  connectToSelectedDatabase(String PAR_databaseNameToInitialize)
	 *  
	 *  Qualifiers:
	 *  If there is no valid definition and connection to PAR_databaseInstanceName, thenThis function will try to connect using the instance saved in the environment variable -GLBL_EBSInstance. 
	 *  If there is no environment -GLBL_EBSInstance, then it will report a connection failure.
	 *  
	 *  Manny Gochuico, CACI February 2, 2021
	 */
	int myNumberOfSQLRecordsread = 0;
	boolean WasitSuccessful = true;
	boolean makeFirstRowAsColumnHeader = true;
	boolean dataMatches = false;
	int numberOfSQLResultsFieldsSaved = 0;
	int myCurrentRow = 0;
	int currenActiveRow = 0;
	String mySavedSQLResultsPath = getSettings().get("EBSURLFilePath",PAR_exportResultsPath);
	String myProgramResultsFilename = PAR_ExportResultsName;
	mySavedSQLResultsPath = mySavedSQLResultsPath+myProgramResultsFilename;
	String mySheetName = "SavedFields";
	

	// connect to the database. make sure the database
	boolean ConnectedToDatabaseInstance = false;
	boolean databaseInstanceIsDefined = false;
	
	ConnectedToDatabaseInstance = connectToSelectedDatabase(PAR_databaseInstanceName);
	if (!ConnectedToDatabaseInstance)
	{
		// try to define the database instance and try to connect
		SS_getDatabaseInformation("EBS_URL.xlsx", "EBSURLFilePath", "EBS_URL", PAR_databaseInstanceName);
		// ++++++++++++ get the database-related Global variables +++++++++++++++
		String GLBL_EBS_SID = getVariables().get(
			"GLBL_EBS_SID",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_DBUserName = getVariables().get(
			"GLBL_EBS_DBUserName",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_DBUserPassword = getVariables().get(
			"GLBL_EBS_DBUserPassword",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_Hostname = getVariables().get(
			"GLBL_EBS_Hostname",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_PortNumber = getVariables().get(
			"GLBL_EBS_PortNumber",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_UserName = getVariables().get(
			"GLBL_EBS_UserName",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbHostIP = getVariables().get(
			"GLBL_EBS_dbHostIP",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbPrimaryPortNumber = getVariables().get(
			"GLBL_EBS_dbPrimaryPortNumber",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbSecondaryPortNumber = getVariables().get(
			"GLBL_EBS_dbSecondaryPortNumber",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_dbServiceName = getVariables().get(
			"GLBL_EBS_dbServiceName",
			Variables.Scope.GLOBAL);
		
		databaseInstanceIsDefined = defineSelectedDatabase(GLBL_EBS_SID, 
			GLBL_EBS_Hostname,
			GLBL_EBS_dbHostIP, 
			GLBL_EBS_dbPrimaryPortNumber, 
			GLBL_EBS_dbSecondaryPortNumber, 
			GLBL_EBS_dbServiceName, 
			GLBL_EBS_DBUserName, 
			GLBL_EBS_DBUserPassword);
		
		if (!databaseInstanceIsDefined)
		{
			fail("Error - "+ PAR_databaseInstanceName +" Cannot Be Defined");
			return 0;
		}
		else
			ConnectedToDatabaseInstance = connectToSelectedDatabase(PAR_databaseInstanceName);
		
		if (!ConnectedToDatabaseInstance)
		{
			fail("Error - Cannot Connect To the "+ PAR_databaseInstanceName +" database");
			return 0;
		}
		
	} // end of (!ConnectedToDatabaseInstance)
	
	// run the query


	Table myTable;
	Row myTableRow;;
	int myTableRowCount = 0;
	int myTableColumnCount = 0;
	String myReturnRequisitionNumber = null;
	// +++++++++++++++++++++

	myTable = utilities.getSQLService().query(
		PAR_databaseInstanceName,
		PAR_SQLScriptToExecute,
		null);
	// +++++++++++++++++++++

	myTableRowCount = myTable.getRowCount();
	myTableColumnCount = myTable.getColumnCount();

	// make sure there are records to process
	if (myTableRowCount == 0) 
	{
		info("*******  No Data Retrieved **********");
			return myTableRowCount;  // return 0 to the calling program
	}
	else	
	{ // this means myTableRowCount > 0
		// check if a datatable with a sheet named PAR_ExportResultsName already exist.  if no, then create the sheet
		try
		{
			datatable.importSheet(mySavedSQLResultsPath, mySheetName, mySheetName, makeFirstRowAsColumnHeader);
			datatable.setCurrentSheet(mySheetName);
		} catch (Exception e)
		{
			WasitSuccessful = false;
		}
		
		if (WasitSuccessful)
		{
			// get the number of columns read
			
			datatable.addSheet(mySheetName, true);
			// write the columns as first row in the data table
			for (int a=0;a<myTableColumnCount;a++)
			{
				datatable.addColumn(mySheetName, myTable.getColumnName(a), a);
			}
			// write the results of the SQL into the data table
			for (int rownum=0;rownum<myTableRowCount;rownum++)
			{
				myTableRow = myTable.getRow(rownum);
				
				for (int colnum=0;colnum<myTableColumnCount;colnum++)
				{
				datatable.setValue(mySheetName, rownum, myTable.getColumnName(colnum), myTableRow.get(myTable.getColumnName(colnum)));
				}
			}
			
			// export the file and overwrite the old file
			datatable.exportAndOverwriteSheet(mySavedSQLResultsPath, mySheetName, mySheetName);
		}

	} // end of if ((myTableRowCount !=0)

	
	// end of run the query
	
	
	return myNumberOfSQLRecordsread;
} // end of executeSQLScriptAndExportResults

public String getConcurrentJobStatus(String PAR_ConcurrentJobName, 
		String PAR_StatusCode, 
		String PAR_exportResultsPath, 
		String PAR_ExportResultsName, 
		String PAR_databaseInstanceName) throws Exception
{
	/*
	 *  This checks the status of a concurrent program 
	 *  This returns:
	 *  A string value that returns the current status of the concurrent job 
	 *  the number of records read and exported if the SQL was successful and the results of the query was exported to an excel spreadsheet
	 *  Zero if there are no records returned or  if the procedure failed for any reason.  This returns a warn message
	 *  
	 *  Exception reporting
	 *  throws a FAIL if the database cannot be accessed, defined, or connected to
	 *  
	 *  parameters:
	 *  PAR_ConcurrentJobName - this is the concurrent job to be checked for status .  
	 *  PAR_StatusCode - If this is populated, then the script will look for this specific status.  If this status does not exist, then the function will return the last completed Status Code
	 * 					If this is null, then it will return the last completed Status Code
	 *  PAR_exportResultsPath - this is the complete path of where the file will reside. this may be EBSURLFilePath or static test.  It will always check for EBSURLFilePath before using this parameter
	 *  PAR_ExportResultsName - this is the name of the resulting excelsheet.  This must be complete including the file extension
	 *  PAR_databaseInstanceName - this is the database where the SQL will be run
	 *  
	 *  Calls the following methods:
	 *  public void SS_getDatabaseInformation(String ExcelSheetName, String pathName, String ExcelTabName, String EBSInstanceName)
	 *  public boolean defineSelectedDatabase(String PAR_databaseSID, String PAR_databaseHostName, String PAR_databasePortNumber, String PAR_databaseServiceName, String PAR_databaseUsername, String PAR_databasePassword )
	 *  public boolean connectToSelectedDatabase(String PAR_databaseNameToInitialize)
	 *  
	 *  sample usage:
	 *  executeSQLScriptAndExportResults("Consolidated Asset Listing (Spreadsheet)",
	 *  									"F",
	 *  									"C:\\oracle\\OracleATS\\OFT\\DataBank\\",
	 *  									"TC_12_Step5_SQL.xlsx",
	 *  									"geneda");
	 *  
	 *  Status Codes that can be used as parameters:
	 *  'A', 'Waiting',
	 *  'B', 'Resuming',
	 *  'C', 'Normal',
	 *  'D', 'Cancelled',
	 *  'E', 'Errored',
	 *  'F', 'Scheduled',
	 *  'G', 'Warning',
	 *  'H', 'On Hold',
	 *  'I', 'Normal',
	 *  'M', 'No Manager',
	 *  'Q', 'Standby',
	 *  'R', 'Normal',
	 *  'S', 'Suspended',
	 *  'T', 'Terminating',
	 *  'U', 'Disabled',
	 *  'W', 'Paused',
	 *  'X', 'Terminated',
	 *  'Z', 'Waiting'
	 *  
	 *  PreRequisites:
	 *  This requires that the database has been defined prior to calling this function by calling the functions in sequence:
	 *  defineSelectedDatabase(String PAR_databaseSID, String PAR_databaseHostName, String PAR_databasePortNumber, String PAR_databaseServiceName, String PAR_databaseUsername, String PAR_databasePassword )
	 *  connectToSelectedDatabase(String PAR_databaseNameToInitialize)
	 *  
	 *  Qualifiers:
	 *  If there is no valid definition and connection to PAR_databaseInstanceName, thenThis function will try to connect using the instance saved in the environment variable -GLBL_EBSInstance. 
	 *  If there is no environment -GLBL_EBSInstance, then it will report a connection failure.
	 *  
	 *  Manny Gochuico, CACI February 2, 2021
	 */
	int myNumberOfSQLRecordsread = 0;
	boolean WasitSuccessful = true;
	boolean makeFirstRowAsColumnHeader = true;
	boolean dataMatches = false;
	int numberOfSQLResultsFieldsSaved = 0;
	int myCurrentRow = 0;
	int currenActiveRow = 0;
	String mySavedSQLResultsPath = getSettings().get("EBSURLFilePath",PAR_exportResultsPath);
	String myProgramResultsFilename = PAR_ExportResultsName;
	mySavedSQLResultsPath = mySavedSQLResultsPath+myProgramResultsFilename;
	String mySheetName = "SavedFields";
	String myConcurrentJobPhaseCode = null;
	
	// this is the SQL to pull the status of the concurrent job
	String PAR_SQLScriptToExecute = "SELECT DISTINCT fcr.request_id, fcr.actual_start_date, " +
	"fcr.actual_completion_date, " +
	"floor(((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60)/3600) HOURS, " +
	"floor((((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60) - " +
	"floor(((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60)/3600)*3600)/60) MINUTES, " +
	"round((((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60) - " +
	"floor(((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60)/3600)*3600 - " +
	"(floor((((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60) - " +
	"floor(((fcr.actual_completion_date-fcr.actual_start_date)*24*60*60)/3600)*3600)/60)*60) )) SECS, " +
	"DECODE (fcr.phase_code, " +
	"'C', 'Completed', " +
	"'I', 'Inactive', " +
	"'P', 'Pending', " +
	"'R', 'Running', " +
	"'N/A' " +
	") phase_code, " +
	"DECODE (fcr.status_code, " +
	"'A', 'Waiting', " +
	"'B', 'Resuming', " +
	"'C', 'Normal', " +
	"'D', 'Cancelled', " +
	"'E', 'Errored', " +
	"'F', 'Scheduled', " +
	"'G', 'Warning', " +
	"'H', 'On Hold', " +
	"'I', 'Normal', " +
	"'M', 'No Manager', " +
	"'Q', 'Standby', " +
	"'R', 'Normal', " +
	"'S', 'Suspended', " +
	"'T', 'Terminating', " +
	"'U', 'Disabled', " +
	"'W', 'Paused', " +
	"'X', 'Terminated', " +
	"'Z', 'Waiting', " +
	"'N/A' " +
	") status_code, " +
	"fcr.outfile_name, fcr.number_of_arguments, fcr.argument_text, " +
	"frt.responsibility_name, fav.application_name, fav.application_short_name appl_short_name, fu.user_name, " +
	"fu.description user_description, fu.start_date user_start_date, " +
	"fcp.user_concurrent_program_name, " +
	"fcp.concurrent_program_name short_name, fe.executable_name, " +
	"DECODE (fe.execution_method_code, " +
	"'B', 'Request Set Stage Function', " +
	"'Q', 'SQL*Plus', " +
	"'H', 'Host', " +
	"'L', 'SQL*Loader', " +
	"'A', 'Spawned', " +
	"'I', 'PL/SQL Stored Procedure', " +
	"'P', 'Oracle Reports', " +
	"'S', 'Immediate', " +
	"'N/A' " +
	") execution_method, " +
	"fe.execution_file_name " +
	"FROM fnd_concurrent_requests fcr, " +
	"fnd_user fu, " +
	"fnd_application_vl fav, " +
	"fnd_responsibility_tl frt, " +
	"fnd_concurrent_programs_vl fcp, " +
	"fnd_executables fe " +
	"WHERE fcr.requested_by = fu.user_id " +
	"AND fcr.concurrent_program_id = fcp.concurrent_program_id " +
	"AND fcr.responsibility_id = frt.responsibility_id " +
	"AND fcr.responsibility_application_id = fav.application_id " +
	"AND fcp.executable_id = fe.executable_id " +
	"AND fcp.user_concurrent_program_name = '" + PAR_ConcurrentJobName + "' " +
	"AND fcr.status_code='"+PAR_StatusCode+"'";

	

	// connect to the database. make sure the database
	boolean ConnectedToDatabaseInstance = false;
	boolean databaseInstanceIsDefined = false;
	
	ConnectedToDatabaseInstance = connectToSelectedDatabase(PAR_databaseInstanceName);
	if (!ConnectedToDatabaseInstance)
	{
		// try to define the database instance and try to connect
		SS_getDatabaseInformation("EBS_URL.xlsx", "EBSURLFilePath", "EBS_URL", PAR_databaseInstanceName);
		// ++++++++++++ get the database-related Global variables +++++++++++++++
		String GLBL_EBS_SID = getVariables().get(
			"GLBL_EBS_SID",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_DBUserName = getVariables().get(
			"GLBL_EBS_DBUserName",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_DBUserPassword = getVariables().get(
			"GLBL_EBS_DBUserPassword",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_Hostname = getVariables().get(
			"GLBL_EBS_Hostname",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_PortNumber = getVariables().get(
			"GLBL_EBS_PortNum er",
			Variables.Scope.GLOBAL);
		String GLBL_EBS_UserName = getVariables().get(
			"GLBL_EBS_UserName",
			Variables.Scope.GLOBAL);
		
		databaseInstanceIsDefined = defineSelectedDatabase(GLBL_EBS_SID, GLBL_EBS_Hostname, GLBL_EBS_PortNumber, GLBL_EBS_SID, GLBL_EBS_DBUserName, GLBL_EBS_DBUserPassword );
		if (!databaseInstanceIsDefined)
		{
			fail("Error - "+ PAR_databaseInstanceName +" Cannot Be Defined");
			return "DB Definition FAILED";
		}
		else
			ConnectedToDatabaseInstance = connectToSelectedDatabase(PAR_databaseInstanceName);
		
		if (!ConnectedToDatabaseInstance)
		{
			fail("Error - Cannot Connect To the "+ PAR_databaseInstanceName +" database");
			return "DB Connection FAILED";
		}
		
	} // end of (!ConnectedToDatabaseInstance)
	
	// run the query


	Table myTable;
	Row myTableRow;;
	int myTableRowCount = 0;
	int myTableColumnCount = 0;
	String myReturnRequisitionNumber = null;
	// +++++++++++++++++++++

	myTable = utilities.getSQLService().query(
		PAR_databaseInstanceName,
		PAR_SQLScriptToExecute,
		null);
	// +++++++++++++++++++++

	myTableRowCount = myTable.getRowCount();
	myTableColumnCount = myTable.getColumnCount();

	// make sure there are records to process
	if (myTableRowCount == 0) 
	{
		info("*******  No Data Retrieved **********");
			return "No Data Found";  // return 0 to the calling program
	}
	else	
	{ // this means myTableRowCount > 0
		// check if a datatable with a sheet named PAR_ExportResultsName already exist.  if no, then create the sheet
		try
		{
			datatable.importSheet(mySavedSQLResultsPath, mySheetName, mySheetName, makeFirstRowAsColumnHeader);
			datatable.setCurrentSheet(mySheetName);
		} catch (Exception e)
		{
			WasitSuccessful = false;
		}
		
		if (WasitSuccessful)
		{
			// get the phase code value
			myTableRow = myTable.getRow(0);
			myConcurrentJobPhaseCode = myTableRow.get("phase_code");
			// get the number of columns read
			
			datatable.addSheet(mySheetName, true);
			// write the columns as first row in the data table
			for (int a=0;a<myTableColumnCount;a++)
			{
				datatable.addColumn(mySheetName, myTable.getColumnName(a), a);
			}
			// write the results of the SQL into the data table
			for (int rownum=0;rownum<myTableRowCount;rownum++)
			{
				myTableRow = myTable.getRow(rownum);
				
				for (int colnum=0;colnum<myTableColumnCount;colnum++)
				{
				datatable.setValue(mySheetName, rownum, myTable.getColumnName(colnum), myTableRow.get(myTable.getColumnName(colnum)));
				}
			}
			
			// export the file and overwrite the old file
			datatable.exportAndOverwriteSheet(mySavedSQLResultsPath, mySheetName, mySheetName);
		}

	} // end of if ((myTableRowCount !=0)

	
	// end of run the query
	
	
	return myConcurrentJobPhaseCode;
} // end of getConcurrentJobStatus


public void SS_getDatabaseInformation(String ExcelSheetName, String pathName, String ExcelTabName, String EBSInstanceName) throws Exception
{
/*
* This script will bring any excel sheet into the automated testing program during playback and create a databank on the fly
* based on the columhns of the excel spreadsheet. this will allow  to add new EBS instances or change EBS instances
* to be used for automated testing without the need for a .csv databank and not having to make changes to the automated master driver scripts. 
*
* function call example: SS_getDatabaseInformation("EBS_URL.xlsx","z:\\CommonAssets\\","EBS_URL","uxbs1");
*
* Inbound parameters:
* ExcelSheetName = name of the excel spreadhseet including extension
* String pathName = pathname for the esxcel spreadsheet
* String ExcelTabName = this is the tab name for the sheet to use. for example  Sheet1 or EBS_URL
* String EBSInstanceTypeName = this can be "uxbs1", "uxbs5", etc.)
*
* Returns:
* none
*
* Outbound Global Variable:
* String GLBL_EBS_SID = getVariables().get("GLBL_EBS_SID",Variables.Scope.GLOBAL);
* String GLBL_EBS_DBUserName = getVariables().get("GLBL_EBS_DBUserName",Variables.Scope.GLOBAL);
* String GLBL_EBS_DBUserPassword = getVariables().get("GLBL_EBS_DBUserPassword",Variables.Scope.GLOBAL);
* String GLBL_EBS_Hostname = getVariables().get("GLBL_EBS_Hostname",Variables.Scope.GLOBAL);
* String GLBL_EBS_PortNumber = getVariables().get("GLBL_EBS_PortNum er",Variables.Scope.GLOBAL);
* String GLBL_EBS_UserName = getVariables().get("GLBL_EBS_UserName",Variables.Scope.GLOBAL);
* String GLBL_SOA_UserName = getVariables().get("GLBL_SOA_UserName",Variables.Scope.GLOBAL);
* String GLBL_SOA_UserPassword = getVariables().get("GLBL_SOA_UserPassword",Variables.Scope.GLOBAL);

*
* Inbound Global Variable:
* none
*
* Note:
* for the master driver to fully utilize this without hard-coding the EBs instance name when calling this script, the Master driver
* must have a line that checks whether an instance parameter is passed on to the program during playback. If there is none, then a default database will be assigned to
* Var_EBSInstanceName. the master driver must have these lines at the top of the program:
* String Var_EBSInstanceName = getSettings.get("PARAM_EBSInstanceName");
* if (Var_EBSInstanceName == null)
*     Var_EBSInstanceName = "uxbs1";
* if (VAR_EBSUserRole == null)
*     Var_EBSUserRole = "User";
*     
* ... and then calling this function :
*         String EBS_Url = SS_getDatabaseInformation("EBS_URL.xlsx","z:\\CommonAssets\\","EBS_URL",Var_EBSInstanceName);
*
* manny gochuico
* September 24, 2020 - Created
*/


//read the excel spreadsheeet and create a datatable from the spreadsheet
	String GLBL_EBS_SID = null;
	String GLBL_EBS_DBUserName = null;
	String GLBL_EBS_DBUserPassword = null;
	String GLBL_EBS_Hostname = null;
	String GLBL_EBS_PortNumber = null;
	String GLBL_EBS_ServiceName = null;
	String GLBL_EBS_URL = null;
	String GLBL_EBS_AdminUserPassword = null;
	String GLBL_SOA_UserName = null;
	String GLBL_SOA_UserPassword = null;
	String GLBL_EBS_dbHostIP = null;
	String GLBL_EBS_dbPrimaryPortNumber = null;
	String GLBL_EBS_dbSecondaryPortNumber = null;
	String GLBL_EBS_dbServiceName = null;	
	
String whatFileToLoad = pathName+ExcelSheetName;
String dataTableTabName = ExcelTabName;
String URLToUse = null;

//read the excel spreadsheeet and create a datatable from the spreadsheet
datatable.importSheet(whatFileToLoad , ExcelTabName, dataTableTabName, true);

// get the number of rows in the datatable sheet
int NumberOfRows = 0;
NumberOfRows = datatable.getRowCount(dataTableTabName);

String db_EBS_Instance_Type = null;
String db_EBS_Instance_URL = null;
String db_instance_name = null;
String db_database_name = null;
String db_host_name = null;
String db_port_number = null;
String db_SID_name = null;
String db_user_name = null;
String db_password = null;
String db_Service_name = null;
String db_AdminUserPassword = null;
String db_SOA_user_name = null;
String db_SOA_password = null;
String db_host_IP = null;
String db_Primary_port_number = null;
String db_Secondary_port_number = null;


for (int currentDBRow=0;currentDBRow<NumberOfRows;currentDBRow++)
{


// read the EBS_instance_type field of the current row
db_EBS_Instance_Type = datatable.getValue(dataTableTabName,currentDBRow,"EBS_Instance_Type").toString();
db_EBS_Instance_URL = datatable.getValue(dataTableTabName,currentDBRow,"EBS_Instance_URL").toString();
db_instance_name = datatable.getValue(dataTableTabName,currentDBRow,"instance_name").toString();
db_database_name = datatable.getValue(dataTableTabName,currentDBRow,"database_name").toString();
db_host_name = datatable.getValue(dataTableTabName,currentDBRow,"host_name").toString();
db_port_number = datatable.getValue(dataTableTabName,currentDBRow,"port_number").toString();
db_SID_name = datatable.getValue(dataTableTabName,currentDBRow,"SID_name").toString();
db_user_name = datatable.getValue(dataTableTabName,currentDBRow,"user_name").toString();
db_password = datatable.getValue(dataTableTabName,currentDBRow,"password").toString();
db_Service_name = datatable.getValue(dataTableTabName,currentDBRow,"Service_name").toString();
db_AdminUserPassword = datatable.getValue(dataTableTabName,currentDBRow,"Administrator_password").toString();
db_SOA_user_name = datatable.getValue(dataTableTabName,currentDBRow,"SOA_username").toString();
db_SOA_password = datatable.getValue(dataTableTabName,currentDBRow,"SOA_password").toString();
db_host_IP = datatable.getValue(dataTableTabName,currentDBRow,"Host_IP").toString();
db_Primary_port_number = datatable.getValue(dataTableTabName,currentDBRow,"Primary_Port_Number").toString();
db_Secondary_port_number = datatable.getValue(dataTableTabName,currentDBRow,"Secondary_Port_Number").toString();


if (EBSInstanceName.equals(db_instance_name))
  {
	getVariables().set("GLBL_EBS_URL",db_EBS_Instance_URL,Variables.Scope.GLOBAL);
	getVariables().set("GLBL_EBS_SID",db_SID_name,Variables.Scope.GLOBAL);
	getVariables().set("GLBL_EBS_DBUserName",db_user_name,Variables.Scope.GLOBAL);
	getVariables().set("GLBL_EBS_DBUserPassword",db_password,Variables.Scope.GLOBAL);
	getVariables().set("GLBL_EBS_Hostname",db_host_name,Variables.Scope.GLOBAL);
	getVariables().set("GLBL_EBS_PortNumber",db_port_number,Variables.Scope.GLOBAL);
	getVariables().set("GLBL_EBS_ServiceName",db_Service_name,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_EBS_AdminUserPassword",db_AdminUserPassword,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_SOA_UserName",db_SOA_user_name,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_SOA_UserPassword",db_SOA_password,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_EBS_dbHostIP",db_host_IP,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_EBS_dbPrimaryPortNumber",db_Primary_port_number,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_EBS_dbSecondaryPortNumber",db_Secondary_port_number,Variables.Scope.GLOBAL);
    getVariables().set("GLBL_EBS_dbServiceName",db_Service_name,Variables.Scope.GLOBAL);

	// check the values
    GLBL_EBS_URL = getVariables().get("GLBL_EBS_URL",Variables.Scope.GLOBAL);
    GLBL_EBS_AdminUserPassword = getVariables().get("GLBL_EBS_AdminUserPassword",Variables.Scope.GLOBAL);
	GLBL_EBS_SID = getVariables().get("GLBL_EBS_SID",Variables.Scope.GLOBAL);
	GLBL_EBS_DBUserName = getVariables().get("GLBL_EBS_DBUserName",Variables.Scope.GLOBAL);
	GLBL_EBS_DBUserPassword = getVariables().get("GLBL_EBS_DBUserPassword",Variables.Scope.GLOBAL);
	GLBL_EBS_Hostname = getVariables().get("GLBL_EBS_Hostname",Variables.Scope.GLOBAL);
	GLBL_EBS_PortNumber = getVariables().get("GLBL_EBS_PortNumber",Variables.Scope.GLOBAL);
	GLBL_EBS_ServiceName = getVariables().get("GLBL_EBS_ServiceName",Variables.Scope.GLOBAL);
	GLBL_SOA_UserName = getVariables().get("GLBL_SOA_UserName",Variables.Scope.GLOBAL);
	GLBL_SOA_UserPassword = getVariables().get("GLBL_SOA_UserPassword",Variables.Scope.GLOBAL);
	GLBL_EBS_dbHostIP  = getVariables().get("GLBL_EBS_dbHostIP",Variables.Scope.GLOBAL);
	GLBL_EBS_dbPrimaryPortNumber  = getVariables().get("GLBL_EBS_dbPrimaryPortNumber",Variables.Scope.GLOBAL);
	GLBL_EBS_dbSecondaryPortNumber  = getVariables().get("GLBL_EBS_dbSecondaryPortNumber",Variables.Scope.GLOBAL);
	GLBL_EBS_dbServiceName  = getVariables().get("GLBL_EBS_dbServiceName",Variables.Scope.GLOBAL);
	
	info("GLBL_EBS_URL ===> "+GLBL_EBS_URL );
	info("GLBL_EBS_AdminUserPassword ===> "+GLBL_EBS_AdminUserPassword );
	info("GLBL_EBS_SID ===> "+GLBL_EBS_SID );
	info("GLBL_EBS_DBUserName ===> "+GLBL_EBS_DBUserName );
	info("GLBL_EBS_DBUserPassword ===> "+GLBL_EBS_DBUserPassword );
	info("GLBL_EBS_Hostname ===> "+GLBL_EBS_Hostname );
	info("GLBL_EBS_PortNumber ===> "+GLBL_EBS_PortNumber );
	info("GLBL_EBS_ServiceName ===> "+GLBL_EBS_ServiceName );
	info("GLBL_SOA_UserName ===> "+GLBL_SOA_UserName );
	info("GLBL_SOA_UserPassword ===> "+GLBL_SOA_UserPassword );
	info("GLBL_EBS_dbHostIP ===> "+GLBL_EBS_dbHostIP );
	info("GLBL_EBS_dbPrimaryPortNumber ===> "+GLBL_EBS_dbPrimaryPortNumber );
	info("GLBL_EBS_dbSecondaryPortNumber ===> "+GLBL_EBS_dbSecondaryPortNumber );
	info("GLBL_EBS_dbServiceName ===> "+GLBL_EBS_dbServiceName );	
	
info("CHECK POINT 1");
  } // end of if (EBSInstanceName ...

} // end of for (int currentDBrow ... 
   
//connect to the selected database

utilities.getSQLService().define(GLBL_EBS_SID,
	"oracle.jdbc.driver.OracleDriver",
	"jdbc:oracle:thin:@"+GLBL_EBS_Hostname+":"+GLBL_EBS_PortNumber+"/"+GLBL_EBS_ServiceName,
	GLBL_EBS_DBUserName, GLBL_EBS_DBUserPassword);

boolean databaseInstanceIsDefined = defineSelectedDatabase(GLBL_EBS_SID, 
	GLBL_EBS_Hostname,
	GLBL_EBS_dbHostIP, 
	GLBL_EBS_dbPrimaryPortNumber, 
	GLBL_EBS_dbSecondaryPortNumber, 
	GLBL_EBS_dbServiceName, 
	GLBL_EBS_DBUserName, 
	GLBL_EBS_DBUserPassword);

boolean ConnectedToDatabaseInstance = false;

if (!databaseInstanceIsDefined)
{
	fail("Error - "+ EBSInstanceName +" Cannot Be Defined");
	return;
}
else
	ConnectedToDatabaseInstance = connectToSelectedDatabase(EBSInstanceName);

if (!ConnectedToDatabaseInstance)
{
	fail("Error - Cannot Connect To the "+ EBSInstanceName +" database");
	return;
}


info("checkpoint 2");

 return ;
} // end of function SS_getDatabaseInformation

public void closeTransactMoveOrdersForm() throws Exception
{
	if (!forms.window(74, "//forms:window[(@name='TOLINES_WIN')]").exists())
		return;
	
	forms.captureScreenshot(73);
	{
		think(1.0);
	}
	forms.window(74, "//forms:window[(@name='TOLINES_WIN')]").close();
	{
		think(1.0);
	}
} // end of closeTransactMoveOrdersForm

public void activateShippingTransactionsForm() throws Exception
{
	{
		think(2.0);
	}
	forms.window(75, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.activate(true);
	{
		think(1.0);
	}
	forms.captureScreenshot(73);
	{
		think(1.0);
	}
	
} // end of activateShippingTransactionsForm

public void closeShippingTransactionsForm() throws Exception
{
	if (!forms.window(74, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]").exists())
		return;
	
	forms.captureScreenshot(73);
	{
		think(1.0);
	}
	forms.window(74, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]").close();
	{
		think(1.0);
	}
} // end of closeTransactMoveOrdersForm

public boolean runSQLForDAASTransmission(String PAR_SDNNumber, String PAR_OutputExcelFilePath, String PAR_OutputExcelFileName, String PAR_EBSInstance) throws Exception
{
	/* run this function after running createSQLforDAASTransmission(String PAR_SDNNumber) that builds the SQL statement for TS09 Main TC15 Step 10
	* 
	* Sample usage 
	* runSQLForDAASTransmission("M2903000410003" , "C:\\oracle\\OracleATS\\OFT\\DataBank\\", "TC_12_Step5_SQL.xlsx", "geneda")
	* 
	*/
	try
	{
	String mySQLforDAAS = createSQLforDAASTransmission(PAR_SDNNumber);
	executeSQLScriptAndExportResults(mySQLforDAAS,
		   									"C:\\oracle\\OracleATS\\OFT\\DataBank\\",
		   									"TC_12_Step5_SQL.xlsx",
		   									"geneda");
	} catch (Exception e)
	{
		info("Error executing runSQLForDAASTransmission");
		info("Exception - "+ e);
		return false;
	}
	
	return true;
	
} // end of runSQLForDAASTransmission

public boolean runSQLForGOCTeamExecution(String PAR_SDNNumber, String PAR_OutputExcelFilePath, String PAR_OutputExcelFileName, String PAR_EBSInstance) throws Exception
{
	/* run this function after running createSQLForGOCTeamExecution(String PAR_SDNNumber) that builds the SQL statement for TS09 Main TC15 Step 10
	* 
	* Sample usage 
	* runSQLForGOCTeamExecution("M2903000410003" , "C:\\oracle\\OracleATS\\OFT\\DataBank\\", "TC_12_Step5_SQL.xlsx", "geneda")
	* 
	*/
	try
	{
	String mySQLforGOCTeam = createSQLForGOCTeamExecution(PAR_SDNNumber);
	executeSQLScriptAndExportResults(mySQLforGOCTeam,
		   									"C:\\oracle\\OracleATS\\OFT\\DataBank\\",
		   									"TC_15_Step9_SQL.xlsx",
		   									"geneda");
	} catch (Exception e)
	{
		info("Error executing runSQLForGOCTeamExecution");
		info("Exception - "+ e);
		return false;
	}
	
	return true;
	
} // end of runSQLForGOCTeamExecution

public int runMySQL(String PAR_BaseSQLString, String PAR_SQLParameters, String PAR_OutputExcelFilePath, String PAR_OutputExcelFileName, String PAR_EBSInstance) throws Exception
{
	/* run this function to execute your SQL statement.
	 * 
	 * parameters
	 * PAR_BaseSQLString = this is the SQL you want to run
	 * PAR_SQLParameters = this is the parameter list delimited by ";".  If you dont have any parameters, just enter null
	 * PAR_OutputExcelFilePath = this is the path to your databank
	 * PAR_OutputExcelFileName = this is the excel output file name with xlsx extension
	 * PAR_EBSInstance = this is the instance where you want to run the query
	 * 
	 * note:
	 * PAR_SQLParameters must be OpenScript Variables (see sample under Sample usage section
	 * 
	 * returns: number of records resulted from running the query.  also the number of records outputed to the excel output file.
	* 
	* Sample usage 1 - running with Query parameters
	* 	String javaVarSDNNumber = "123456789";
		String javaVarSRNumber = "987654321";
		getVariables().set("Var_SDNNumber",javaVarSDNNumber );
		getVariables().set("Var_SRNumber",javaVarSRNumber );
		String myBaseSQL = "SELECT * FROM XXMC.XXMC_INV_PO_TXN_IF_STG WHERE STANDARD_DOCUMENT_NUMBER = '" +  "?" + "' " +
		" and SERVICE_REQUEST_NUMBER = '"+"?"+"'";
		int numberOfRecordsQueried = runSQL(myBaseSQL,"Var_OrderNumber;Var_SDNNumber;Var_SRNumber",
											"C:\\oracle\\OracleATS\\OFT\\DataBank\\",
		   									"TC_15_Step9_SQL.xlsx",
		   									"geneda");
		info(myFinalSQL);
		
	* Sample Usage 2 - running with No Query parameters
	 	String myBaseSQL = "SELECT * FROM XXMC.XXMC_INV_PO_TXN_IF_STG ";
		int numberOfRecordsQueried = runSQL(myBaseSQL,null,
											"C:\\oracle\\OracleATS\\OFT\\DataBank\\",
		   									"TC_15_Step9_SQL.xlsx",
		   									"geneda");
		info(myFinalSQL);
	* Copyrights(c)
	* CACI IP 2021
	*/
	int numberOfRecordsReturned = 0;
	try
	{
	String mySQLToRun = createSQLForExecution(PAR_BaseSQLString,PAR_SQLParameters);
	numberOfRecordsReturned = executeSQLScriptAndExportResults(mySQLToRun,
											PAR_OutputExcelFilePath,
											PAR_OutputExcelFileName,
											PAR_EBSInstance);
	} catch (Exception e)
	{
		info("Error executing runSQLForGOCTeamExecution");
		info("Exception - "+ e);
		return 99999;
	}
	
	return numberOfRecordsReturned;
	
} // end of runSQL


public String createSQLforDAASTransmission(String PAR_SDNNumber) throws Exception
{
	/*
	 * run this function to create the SQL statement to run TS09 Main TC-15 Step 10
	 */
	String myBaseSQL = "SELECT DOCUMENT_IDENTIFIER, " +
	   getFutureDate(0) + "," +
	   " SUBSTR(CONCATENATED_DATA,30,14) SDN, SUBSTR(CONCATENATED_DATA,64,1) DISPOSAL_AUTHORITY, " +
       " CONCATENATED_DATA " +
       "from XXMC.XXMC_DAAS_OUTBOUND_QUE " +
       "where SUBSTR(CONCATENATED_DATA,30,14) = '" +
       "?" + "' " +
       "order by SUBSTR(CONCATENATED_DATA,30,14) desc";
	
	int SDNNumberGoesHere = myBaseSQL.indexOf("?") ;
	
	 // Create a new string 
    String newString = new String(); 

    for (int i = 0; i < myBaseSQL.length(); i++) { 

        // Insert the original string character 
        // into the new string 



        if (i == SDNNumberGoesHere) 
        	{
            // Insert the string to be inserted 
            // into the new string 
            newString += PAR_SDNNumber; 
        	}
        else
                newString += myBaseSQL.charAt(i); 
        } 
    

    // return the modified String 
    return newString; 
}

public String createSQLForGOCTeamExecution(String PAR_SDNNumber) throws Exception
{
	/*
	 * run this function to create the SQL statement to run TS09 Main TC-15 Step 9
	 */
	String myBaseSQL = "SELECT * FROM XXMC.XXMC_INV_PO_TXN_IF_STG WHERE STANDARD_DOCUMENT_NUMBER = '" +
       "?" + "' ";
	
	int SDNNumberGoesHere = myBaseSQL.indexOf("?") ;
	
	 // Create a new string 
    String newString = new String(); 

    for (int i = 0; i < myBaseSQL.length(); i++) { 

        // Insert the original string character 
        // into the new string 



        if (i == SDNNumberGoesHere) 
        	{
            // Insert the string to be inserted 
            // into the new string 
            newString += PAR_SDNNumber; 
        	}
        else
                newString += myBaseSQL.charAt(i); 
        } 
    

    // return the modified String 
    return newString; 
} // end of createSQLForGOCTeamExecution

public String createSQLForExecution(String PAR_BaseSQLString, String PAR_SQLParameters) throws Exception
{
	/*
	 * run this function to create the SQL statement to be executed
	 * PAR_SQLParameters are openscript variables and must be delimited by ";" for example "Var_SDNNumber;Var_SRNumber"
	 */
	// ++++++++++++ setup variables +++++++++++++++++++++
	boolean isThereAComma = false;
	int SQLParameterItemCounter = 0;
	String mySQLParameters = PAR_SQLParameters;
	String charToSearch =  ";";
	List<String> SQLParameterItems = new ArrayList<String>();
	 // Create a new string 
    String newString = new String(); 

	String repeatedString = null;
	boolean repeatedText = false;
	int repeatedCount = 0;
	String myBaseSQL = PAR_BaseSQLString;
	
	// return the PAR_BaseSQLString if there are no parameters
	if (PAR_SQLParameters==null)
		return PAR_BaseSQLString;
	// String myBaseSQL = "SELECT * FROM XXMC.XXMC_INV_PO_TXN_IF_STG WHERE STANDARD_DOCUMENT_NUMBER = '" +
   //  "?" + "' ";



	// ++++++++++++ now parse the SQL parameters +++++++++++++++++++
	for (int i = 0; i < mySQLParameters.length(); i++) {
		// check if ther eis a comma in the string
		int commaLocation = mySQLParameters.indexOf(
			charToSearch,
			i);
		info("commaLocaton ===> " + commaLocation);
		if (commaLocation > 0) {
			isThereAComma = true;
			String A = mySQLParameters.substring(
				i,
				commaLocation);
			SQLParameterItems.add(A);
			info(SQLParameterItems.get(
				SQLParameterItemCounter).toString());
			i = commaLocation;
			SQLParameterItemCounter++;
			info("the value of i is ==>" + i);

		} else {
			if (isThereAComma) {
				SQLParameterItems.add(mySQLParameters.substring(
					i,
					mySQLParameters.length()));
				info(SQLParameterItems.get(
					SQLParameterItemCounter).toString());
				break;
			} else {
				SQLParameterItems.add(mySQLParameters);
				info("myNavigation ===> " + mySQLParameters);
				SQLParameterItemCounter++;
				break;
			}

		}
	} // end of for (int i = 0...

	// ++++++++++++ END OF parse the SQL parameters +++++++++++++++++++
	
	info("Now insert the parameter items into the base SQL String ");
	boolean allParametersInserted = false;


		
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		
		int ParameterGoesHere = myBaseSQL.indexOf("?") ;
		
		int i=0;
		String SQLParameter = SQLParameterItems.get(
			i).toString();
		// info(menuItems.get(i).toString());
		info ("starts here ==> "+SQLParameter);
	info ("SQLParameterItems.size() =="+SQLParameterItems.size());
		int k=0;
	    while(k < myBaseSQL.length()) { 

	        // Insert the original string character 
	        // into the new string 



	        if (k == ParameterGoesHere) 
	        	{
	        	myBaseSQL = myBaseSQL.substring(ParameterGoesHere+1, myBaseSQL.length());
	        	info("myBaseSQL is now ==> "+myBaseSQL);
	        	info("myBaseSQL length is now "+myBaseSQL.length() );
	        	ParameterGoesHere = myBaseSQL.indexOf("?") ;
	            // Insert the string to be inserted 
	            // into the new string 
	            newString += getVariables().get(SQLParameter); 
	            info ("newstring is now == > "+newString);
	            
	    		info("("+i+") Inserted ==> "+SQLParameter);	
	           i++;
	           k=0; // reset k
	           if (i<SQLParameterItems.size())
	        	   SQLParameter = SQLParameterItems.get(i).toString();
	   		// info(menuItems.get(i).toString());
	   		info (SQLParameter);
	        	}
	        else
	        {
	                newString += myBaseSQL.charAt(k); 
	                k++;
	        }

	   	
// ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++		
		

		
			
	    } // end of while

		think(2.0);
		info("Checkpoint "+i+"a");
		// web.window(19, "/web:window[@index='0' or @title='Home']").waitForPage(null);
	{
	think(1.0);
	}
info("GOING BACK TO THE FOR i LOOP"); // remove aftger debug
	 


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++


    // return the modified String 
    return newString; 
} // end of createSQLForExecution


public String getFutureDate(int par_daysIntoTheFuture) throws Exception {
	/*
	 * Thia function calculates a future date based on the system date plus
	 * the value of par_daysIntoTheFuture
	 * 
	 * it returns the future date in DD-MON-YYYY format to be used for EBS
	 * forms examples of calling this function getFutureDate(30) - returns a
	 * date 30 days from the system date getFutureDate(90) - returns a date
	 * 60 days from the system date
	 */
	// ++++++++++++ Global variables +++++++++++++++
	
	String GLBL_EBS_SID = getVariables().get(
		"GLBL_EBS_SID",
		Variables.Scope.GLOBAL);
	String GLBL_EBS_DBUserName = getVariables().get(
		"GLBL_EBS_DBUserName",
		Variables.Scope.GLOBAL);
	String GLBL_EBS_DBUserPassword = getVariables().get(
		"GLBL_EBS_DBUserPassword",
		Variables.Scope.GLOBAL);
	String GLBL_EBS_Hostname = getVariables().get(
		"GLBL_EBS_Hostname",
		Variables.Scope.GLOBAL);
	String GLBL_EBS_PortNumber = getVariables().get(
		"GLBL_EBS_PortNumber",
		Variables.Scope.GLOBAL);
	String GLBL_EBS_UserName = getVariables().get(
		"GLBL_EBS_UserName",
		Variables.Scope.GLOBAL);

	Table myTable;
	Row myTableRow;
	int myTableRowCount = 0;
	String[] myTableColumns;
	// +++++++++++++++++++++

	myTable = utilities.getSQLService().query(
		GLBL_EBS_SID,
		"select to_char(sysdate+" + par_daysIntoTheFuture + ",'DD-MON-YYYY') future_date from dual",
		null);
	// utilities.parameters(PAR_CandidateOrderNumber));

	// +++++++++++++++++++++

	while (true) // wait until there is a count
	{
		myTableRowCount = myTable.getRowCount();
		if (myTableRowCount != 0)
			break;
		else
			think(5.0);
	}

	myTableRow = myTable.getRow(0);
	String myFutureDate = myTableRow.get("FUTURE_DATE");
	info("myFutureDate ===> " + myFutureDate);

	return myFutureDate;

} // end of getFutureDate

public void enterResponsiblity(String PAR_Responsiblity, String PAR_FirstMenuitem) throws Exception
{
	{
		//web.window(1293, "/web:window[@index='0' or @title='Home']")
		//		.waitForPage(null);
		{
			think(1.0);
		}
		while (true)
		{
				
			if(web.element(
				1296,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"+PAR_Responsiblity+"' or @index='58']")
				.exists())
				break;
			else
				delay(1000);
		}
		web.element(
				1296,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"+PAR_Responsiblity+"' or @index='58']")
				.click();
		
		delay(12000);
		

		
			while (true) {
					
				if (web.element(
					18,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + PAR_FirstMenuitem
								+ "']")
				.exists())
				{
					info("Found the menu item");
					break;
				}
				else
				{
					web.element(
						1296,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"+PAR_Responsiblity+"' or @index='58']")
						.click();
					
					delay(1000);
				}
		}
	}
	
} // end of enterResponsiblity 


public void SS_getEBSNavigationAndClickOnMenuItems(String PAR_NavigationString, String delimiterPattern) throws Exception {
	/*
	 * this function will read the navigation path from the scripts
	 * spreadsheet and then use the data in th espreadsheet to navigate the
	 * menuts in EBS.
	 * 
	 * Manny Gochuico (CACI Intellectual Property) 2021
	 */
	// ++++++++++++ setup variables +++++++++++++++++++++
	boolean isThereAComma = false;
	int menuItemCounter = 0;
	String myNavigation = PAR_NavigationString;
	String charToSearch = delimiterPattern; // originally --> ",";
	List<String> menuItems = new ArrayList<String>();

	String repeatedString = null;
	boolean repeatedText = false;
	int repeatedCount = 0;



	// ++++++++++++ now parse the menu items +++++++++++++++++++
	for (int i = 0; i < myNavigation.length(); i++) {
		// check if ther eis a comma in the string
		int commaLocation = myNavigation.indexOf(
			charToSearch,
			i);
		info("commaLocaton ===> " + commaLocation);
		if (commaLocation > 0) {
			isThereAComma = true;
			String A = myNavigation.substring(
				i,
				commaLocation);
			menuItems.add(A);
			info(menuItems.get(
				menuItemCounter).toString());
			i = commaLocation;
			menuItemCounter++;
			info("the value of i is ==>" + i);

		} else {
			if (isThereAComma) {
				menuItems.add(myNavigation.substring(
					i,
					myNavigation.length()));
				info(menuItems.get(
					menuItemCounter).toString());
				break;
			} else {
				menuItems.add(myNavigation);
				info("myNavigation ===> " + myNavigation);
				menuItemCounter++;
				break;
			}

		}
	}

	info("Now Click on the menu items");
	boolean allmenuitemsclicked = false;

	for (int i = 0; i < menuItems.size(); i++) {
		String menuItem = menuItems.get(
			i).toString();
		// info(menuItems.get(i).toString());
		info (menuItem);
		
		delay(5000); // added 7-12-2021

//info("I am here - "+i); // remove after debug
		while (true) {
			if (web.element(
				18,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem
							+ "']")
			.exists())
			{
				info("check point "+i);
				break;
			}
			else
			{
				// info("XXXXXXXXXXXXX");
				think(2.0);
				if (forms.window(29, "//forms:window[(@name='NAVIGATOR')]").exists())
				{
					allmenuitemsclicked = true;
					break;
				}
			}
		}
//info("I am here AGAIN - "+i); // remove after debufg
		if (allmenuitemsclicked) // this means that the java form is already displayed on the screen.
			break;
		
		think(4.0);
		
		web.element(
			18,
			"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem
						+ "']").click();
		
		info("("+i+") clicked on ==> "+menuItem);				


		delay(12000);
		info("Checkpoint "+i+"a");
		// web.window(19, "/web:window[@index='0' or @title='Home']").waitForPage(null);
	{
	think(2.0);
	}
//info("GOING BACK TO THE FOR LOOP"); // remove aftger debug
	}


	// +++++++++++++++++++++++++++++++++++++++++++++++++++++++++

	} // end of SS_getEBSNavigation	

public String getFirstNavigationMenuItem(String PAR_NavigationMenuItemsString,String PAR_DelimiterPattern) throws Exception
{
	boolean isThereAComma = false;
	int menuItemCounter = 0;
	String myFirstMenuItem = null;
	String myNavigation = PAR_NavigationMenuItemsString;
	String charToSearch = PAR_DelimiterPattern; // originally --> ",";
	List<String> menuItems = new ArrayList<String>();

	String repeatedString = null;
	boolean repeatedText = false;
	int repeatedCount = 0;



	// ++++++++++++ now parse the menu items +++++++++++++++++++
	for (int i = 0; i < myNavigation.length(); i++) {
		// check if ther eis a comma in the string
		int commaLocation = myNavigation.indexOf(
			charToSearch,
			i);
		info("commaLocaton ===> " + commaLocation);
		if (commaLocation > 0) {
			isThereAComma = true;
			String A = myNavigation.substring(
				i,
				commaLocation);
			menuItems.add(A);
			myFirstMenuItem = A;
			if (i==0)
				break; // get out of the loop after the first item is read
			info(menuItems.get(
				menuItemCounter).toString());
			i = commaLocation;
			menuItemCounter++;
			info("the value of i is ==>" + i);

		} else {
			if (isThereAComma) {
				menuItems.add(myNavigation.substring(
					i,
					myNavigation.length()));
				myFirstMenuItem = myNavigation.substring(
					i,
					myNavigation.length());
				info("myFirstMenuItem=== > "+myFirstMenuItem);
				break;
			} else {
				menuItems.add(myNavigation);
				info("myNavigation ===> " + myNavigation);
				myFirstMenuItem = myNavigation;
				menuItemCounter++;
				break;
			}

		}
	}
	getVariables().set("GLBL_FirstMenuItem", myFirstMenuItem);
	return myFirstMenuItem;
} // end of getFirstNavigationMenuItem

public void enterMMRServiceRequestNumber(String PAR_MMRServiceRequestNumber) throws Exception
{
	
			/*
			 * This is to enter the service request number in the MMR Report Screen
			 */
	// first check if it is displayed on screen
	while(true)
	{
		if (web.textBox(
					28,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_text[@id='saw_38401_7_1' or @index='1']")
					.exists(3, TimeUnit.SECONDS))
				break;
		else
			delay(1000);
	}
			// set focus on thwe service request text field
			web.textBox(
					28,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_text[@id='saw_38401_7_1' or @index='1']")
					.focus();
			
			web.textBox(
					28,
					"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_text[@id='saw_38401_7_1' or @index='1']")
					.setText(PAR_MMRServiceRequestNumber); // service Request number
			{
				delay(1000);
			}
} // end of enterMMRServiceRequestNumber

public void enterMMRTaskNumber(String PAR_MMRServiceRequestNumber) throws Exception
{
	
			/*
			 * This is to enter the Task number in the MMR Report Screen.  enter "#{All#}" for All
			 */
	// first check if it is displayed on screen
	while(true)
	{
		if (web.textBox(
			32,
			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_text[@id='saw_38415_4_1' or @index='2']")
			.exists(3, TimeUnit.SECONDS))
				break;
		else
			delay(1000);
	}
			// set focus on the Task Number text field
		web.textBox(
			32,
			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_text[@id='saw_38415_4_1' or @index='2']")
			.focus();
			
			web.textBox(
				32,
				"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_text[@id='saw_38415_4_1' or @index='2']")
				.setText("#{All#}"); // task number
			{
				delay(1000);
			}
} // end of enterMMRTasktNumber

public void clickOnMMRContinueButton() throws Exception
{
	
			/*
			 * This is to click on the continue button
			 */
	// first check if it is displayed on screen
	while(true)
	{
		if (web.button(
			33,
			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:input_button[@id='idContinueButton' or @value='Continue' or @index='0']")
			.exists(3, TimeUnit.SECONDS))
				break;
		else
			delay(1000);
	}
			// set focus on the Task Number text field

			
		web.button(
			33,
			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:input_button[@id='idContinueButton' or @value='Continue' or @index='0']")
			.click();
	{
		delay(12000);
	}
} // end of clickOnMMRContinueButton

public boolean validateMMRReportHasCompleted(String PAR_SRNumberToReport) throws Exception
{
	
			/*
			 * This will check that the SR number is displayed in the report.  
			 * The existence of this SRnumber  will signify that the report completed.
			 * Check this for 30 seconds
			 * then close the windows
			 */
	boolean MMRReportCompleted = false;
	
	// check if the SR number is displayed on screen
	while(true)
	{
		if (web.element(
		36,
		"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:td[@text='"+PAR_SRNumberToReport+"' or @id='e_saw_24338_7_1_0_0' or @index='195']")
		.exists(1, TimeUnit.MINUTES))
		{
			MMRReportCompleted = true;
				break;
		}
		else
			break;
	}
			// set focus on the Task Number text field

			
	web.element(
		36,
		"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:td[@text='27631014' or @id='e_saw_24338_7_1_0_0' or @index='195']")
		.click();  // this will ensure that the report has completed and displayed on screen
{
	delay(1000);
}
	return MMRReportCompleted;
} // end of validateMMRReportHasCompleted


public void clickButtonOnTrustedSiteDialogForm(String PAR_ButtonToClick) throws Exception
{
	/*
	 * this function checks if the trusted site dialog form pops up on screen.  if it does, click on either the Yes or No button
	 */
	int buttonToClick = 0;
	
	if (!PAR_ButtonToClick.equalsIgnoreCase("Yes"))
		return;
	else
		buttonToClick=1;
	// first check if it is displayed on screen
	if (!web.dialog(
			20,
			"/web:dialog_unknown[@text='The current webpage is trying to open a site in your Trusted sites list. Do you want to allow this?' or @index='0']")
			.exists(3,TimeUnit.SECONDS))
		return;
	

	web.dialog(
			20,
			"/web:dialog_unknown[@text='The current webpage is trying to open a site in your Trusted sites list. Do you want to allow this?' or @index='0']")
			.clickButton(buttonToClick); // trusted sites selection by clikcing on the YEs button
} // end of clickButtonOnTrustedSiteDialogForm

public void clickLinkToOpenOBIEEInAnotherWindow() throws Exception
{
	/*
	 * sometimes OBIEE will not open on the browser but will present a link to be clicked.
	 * This function will click on that link
	 */


	// wait for it to appear
	while(true)
	{
		if(web.element(
			19,
			"/web:window[@index='1' or @title='OBIEE Launcher']/web:document[@index='1']/web:id[@id='openNewWindow' and @disabled='False' and @onabort='null' and @onblur='null' and @onchange='null' and @onclick='null' and @ondblclick='null' and @onfocus='null' and @onkeydown='null' and @onkeypress='null' and @onkeyup='null' and @onload='null' and @onmousedown='null' and @onmousemove='null' and @onmouseout='null' and @onmouseover='null' and @onmouseup='null' and @onreset='null' and @onselect='null' and @onsubmit='null' and @tabindex='0' and @text='Open this content in a new window' and @index='0']")
			.exists(5, TimeUnit.SECONDS))
			break;
		else
			delay(1000);
	}
	web.element(
			19,
			"/web:window[@index='1' or @title='OBIEE Launcher']/web:document[@index='1']/web:id[@id='openNewWindow' and @disabled='False' and @onabort='null' and @onblur='null' and @onchange='null' and @onclick='null' and @ondblclick='null' and @onfocus='null' and @onkeydown='null' and @onkeypress='null' and @onkeyup='null' and @onload='null' and @onmousedown='null' and @onmousemove='null' and @onmouseout='null' and @onmouseover='null' and @onmouseup='null' and @onreset='null' and @onselect='null' and @onsubmit='null' and @tabindex='0' and @text='Open this content in a new window' and @index='0']")
			.click();  // click on the open in a new window
	{
		delay(5000);
	}
} // end of clickLinkToOpenOBIEEInAnotherWindow

public void clickOnOBIEETab(String PAR_OBIEETab) throws Exception
{
	
			/*
			 * This is to click on the a tab with the label PAR_OBIEETab
			 * Example usage:
			 * clickOnOBIEETab("GCSS-MC Reports");
			 */
	// first check if it is displayed on screen
	while(true)
	{
		if (web.element(
			23,
			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']/web:document[@index='0']/web:div[@text='"+PAR_OBIEETab+"' or @index='20']")
			.exists(3, TimeUnit.SECONDS))
				break;
		else
			delay(1000);
	}
			

			
	web.element(
		23,
		"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']/web:document[@index='0']/web:div[@text='"+PAR_OBIEETab+"' or @index='20']")
		.click();
	{
	delay(3000);
	}
	{
		delay(5000);
	}
} // end of clickOnOBIEETab

public void clickOnOBIEEReportLink(String PAR_OBIEEReportLink) throws Exception
{
	
			/*
			 * This is to click on the a link after you have chosen the OBIEE report tab
			 * you always call this after clickOnOBIEETab
			 * Example usage:
			 * clickOnOBIEETab("GCSS-MC Reports");
			 * clickOnOBIEEReportLink("Parts Requested");
			 */
	// first check if it is displayed on screen
	while(true)
	{
		if (web.link(
			24,
			"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']/web:document[@index='0']/web:a[@text='"+PAR_OBIEEReportLink+"' " +
				"]")
		.exists(3, TimeUnit.SECONDS))
				break;
		else
			delay(1000);
	}
			
	
	web.link(
		24,
		"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - Dashboard Index']/web:document[@index='0']/web:a[@text='"+PAR_OBIEEReportLink+"' " +
			"]")
			.click();

	{
	delay(3000);
	}
	{
		delay(5000);
	}
} // end of clickOnOBIEEReportLink

public void exitOBIEEReportingDashboard() throws Exception
{
	web.button(
		44,
		"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']/web:document[@index='0']/web:form[@index='1']/web:input_button[@id='gobtn' or @name='gobtn' or @value='Apply' or @index='0']")
		.click(); // click on File /Exit
{
	delay(3000);
}
web.window(45,
		"/web:window[@index='2' or @title='Oracle BI Interactive Dashboards - MMR']")
		.close();
{
	delay(3000);
}
web.window(46, "/web:window[@index='1' or @title='OBIEE Launcher']")
		.close(); // close the OBIEE launcher

web.window(15, "/web:window[@index='0' or @title='Home']")
	.close(); // close the blank form

	delay(3000);
} // end of exitOBIEEReportingDashboard

public void clickOnReportTypeResponseButton(String PAR_Buttonlabel) throws Exception
{
	/*
	 * When you are presented with a submit new Request dialog box, you will see two radio buttons
	 * Single Request and Request Set.  You are also presented with two buttons, OK and Cancel.
	 * This function is to click on either the OK button or the Cancel button.
	 * 
	 * parameters:
	 * String PAR_Buttonlabel = This is either "OK" or "Cancel"
	 * 
	 * Behavior:
	 * When you click on the Cancel button, the last form you were at is activated.
	 * when you click on the OK button, The Run Request Form is activated
	 * 
	 * manny gochuico, CACI march 11, 2021
	 * 
	 */
	beginStep("[700] Click on the "+PAR_Buttonlabel+" Button", 0);
	{
		forms.captureScreenshot(42);
		{
			delay(1000);
		}
		if (PAR_Buttonlabel.equalsIgnoreCase("CANCEL"))
		{
			info("You Clicked on CANCEL");
		
			forms.button(43, "//forms:button[(@name='WHAT_TYPE_CANCEL_0')]")
				.click(); // select request type - Cancel button
				
		}
		else
			if (PAR_Buttonlabel.equalsIgnoreCase("OK"))
			{
				info("You clicked on OK button");
		
				forms.button(142, "//forms:button[(@name='WHAT_TYPE_OK_0')]")
				.click(); // select request type - OK button
				
			}
			else
			{
				warn(PAR_Buttonlabel + " is invalid button label. Only Cancel and OK are accepted");
				return;
			}
		{
			delay(1000);
		}
	}
	endStep();
} // end of clickOnReportTypeResponseButton

public void clickOKinMessageForm() throws Exception 
{
	if (!forms.button(35, "//forms:button[(@name='MESSAGE_OK_0')]").exists())
		return;
	
	forms.button(35, "//forms:button[(@name='MESSAGE_OK_0')]").click();
	
} // end of clickOKinMessageForm

public String replaceStringCharacters(String PAR_StringToReplace, String oldChar, String newChar) throws Exception
{  
	int lengthOfOldChar = oldChar.length();
	int lengthOfString = PAR_StringToReplace.length();
	int whereIsTheString = PAR_StringToReplace.indexOf(oldChar);
	String newString = PAR_StringToReplace.substring(0, whereIsTheString)+newChar+PAR_StringToReplace.substring(whereIsTheString+lengthOfOldChar, lengthOfString);



    return newString;  
}  // end of replaceStringCharacters

public void clickOnShippingActionLOVandPressGoButton(String PAR_ActionToPerform) throws Exception
{
	/*
	 * This function will click on the Shipping transactios Actions LOV, select the Action to perform and click on the Go button
	 * 
	 * usage example:
	 *  clickOnShippingActionLOVandPressGoButton("Pick and Ship");
	 */
	beginStep("[100] Action Button", 0);
	{
		while (true)
		{
			if (forms.textField(46,
				"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
				.exists())
				break;
			else
				delay(2000);
		}
		forms.captureScreenshot(45);
		{
			think(1.0);
		}
		forms.textField(46,
				"//forms:textField[(@name='DLVB_DETAIL_LABEL_0')]")
				.setFocus();
		{
			think(1.0);
		}
		forms.list(47, "//forms:list[(@name='DLVB_BUTTONS_ACTIONS_0')]")
				.selectItem(PAR_ActionToPerform);
		{
			think(2.0);
		}
		forms.button(48, "//forms:button[(@name='DLVB_BUTTONS_GO_0')]")
				.click();
		
		think(2.0);
	}
	endStep();
} // end of  clickOnShippingActionLOVandPressGoButton

public String getViewRequestPhase(int PAR_ViewRequestLinesToCheck, String PAR_ProgramName) throws Exception
{
	/*
	 * This fucntion will return the Concurrent Run Phase of the program PAR_ProgramName
	 * This function will Return Completed, Pending, Running
	 * 
	 * The intent is for the program to go down the list of program names for PAR_ViewRequestLinesToCheck number of lines
	 * and once there is a match, return the phase of that concurrent program
	 * 
	 * 	 * 	 * usage example:
	 * getViewRequestPhase(10,"Auto Ship Confirm Report (Auto Ship confirm Report)")
	 * 
	 */
	String myViewRequestPhase = null;
	for (int a=0;a<PAR_ViewRequestLinesToCheck;a++)
	{
		String myLineProgramName = forms.textField(49, "//forms:textField[(@name='JOBS_PROGRAM_"+a+"')]").getText();
		if (myLineProgramName.equalsIgnoreCase(PAR_ProgramName))
		{
			forms.textField(51, "//forms:textField[(@name='JOBS_PHASE_"+a+"')]")
			.setFocus(); //phse must be Completed
			myViewRequestPhase = forms.textField(51, "//forms:textField[(@name='JOBS_PHASE_"+a+"')]")
			.getText(); //phse must be Completed
			break;

		}
	}
	return myViewRequestPhase;
} // end of getViewRequestPhase

public String getViewRequestStatus(int PAR_ViewRequestLinesToCheck, String PAR_ProgramName) throws Exception
{
	/*
	 * This fucntion will return the Concurrent Run Status of the program PAR_ProgramName
	 * This function will Return Completed or Warning, or Error
	 * 
	 * The intent is for the program to go down the list of program names for PAR_ViewRequestLinesToCheck number of lines
	 * and once there is a match, return the Status of that concurrent program
	 * 
	 * 	 * usage example:
	 * getViewRequestStatus(10,"Auto Ship Confirm Report (Auto Ship confirm Report)"))
	 */
	String myViewRequestStatus = null;
	for (int a=0;a<PAR_ViewRequestLinesToCheck;a++)
	{
		String myLineProgramName = forms.textField(49, "//forms:textField[(@name='JOBS_PROGRAM_"+a+"')]").getText();
		if (myLineProgramName.equalsIgnoreCase(PAR_ProgramName))
		{
			forms.textField(51, "//forms:textField[(@name='JOBS_STATUS_"+a+"')]")
			.setFocus(); //phse must be Completed
			myViewRequestStatus = forms.textField(51, "//forms:textField[(@name='JOBS_STATUS_"+a+"')]")
			.getText(); //phse must be Completed
			break;

		}
	}
	 return myViewRequestStatus;
} // end of getViewRequestStatus

public boolean checkViewRequestPhase(int PAR_ViewRequestLinesToCheck, String PAR_ProgramName, String PAR_PhaseName) throws Exception
{
	/*
	 * This fucntion will return True if the Concurrent Run Phase of the program PAR_ProgramName equals PAR_PhaseName
	 * This function will Return False if the Concurrent Run Phase of the program PAR_ProgramName Do not equal PAR_PhaseName
	 * 
	 * The intent is for the program to go down the list of program names for PAR_ViewRequestLinesToCheck number of lines
	 * and once there is a match, check if the phase of that concurrent program, matches the PAR_PhaseName parameter
	 * 
	 * 	 * usage example:
	 * checkViewRequestPhase(10,"Auto Ship Confirm Report (Auto Ship confirm Report)","Completed")
	 * 
	 */
	boolean isItTrue = false;
	String myViewRequestPhase = null;
	for (int a=0;a<PAR_ViewRequestLinesToCheck;a++)
	{
		String myLineProgramName = forms.textField(49, "//forms:textField[(@name='JOBS_PROGRAM_"+a+"')]").getText();
		if (myLineProgramName.equalsIgnoreCase(PAR_ProgramName))
		{
			forms.textField(51, "//forms:textField[(@name='JOBS_PHASE_"+a+"')]")
			.setFocus(); //phse must be Completed
			myViewRequestPhase = forms.textField(51, "//forms:textField[(@name='JOBS_PHASE_"+a+"')]")
			.getText(); //phse must be Completed
			if (myViewRequestPhase.equalsIgnoreCase(PAR_PhaseName))
				isItTrue= true;
			else
				isItTrue= false;

		}
	}
	return isItTrue;
} // end of checkViewRequestPhase

public boolean checkViewRequestStatus(int PAR_ViewRequestLinesToCheck, String PAR_ProgramName, String PAR_StatusName) throws Exception
{
	/*
	 * This fucntion will return True if the Concurrent Run status of the program PAR_ProgramName equals PAR_StatusName
	 * This function will Return False if the Concurrent Run Status of the program PAR_ProgramName Do not equal PAR_StatusName
	 * 
	 * The intent is for the program to go down the list of program names for PAR_ViewRequestLinesToCheck number of lines
	 * and once there is a match, check if the phase of that concurrent program, matches the PAR_PhaseName parameter
	 * 
	 * usage example:
	 * checkViewRequestStatus(10,"Auto Ship Confirm Report (Auto Ship confirm Report)","Completed")
	 */
	boolean isItTrue = false;
	String myViewRequestStatus = null;
	for (int a=0;a<PAR_ViewRequestLinesToCheck;a++)
	{
		String myLineProgramName = forms.textField(49, "//forms:textField[(@name='JOBS_PROGRAM_"+a+"')]").getText();
		if (myLineProgramName.equalsIgnoreCase(PAR_ProgramName))
		{
			forms.textField(51, "//forms:textField[(@name='JOBS_STATUS_"+a+"')]")
			.setFocus(); //phse must be Completed
			myViewRequestStatus = forms.textField(51, "//forms:textField[(@name='JOBS_STATUS_"+a+"')]")
			.getText(); //phse must be Completed

			if (myViewRequestStatus.equalsIgnoreCase(PAR_StatusName))
				isItTrue= true;
			else
				isItTrue= false;
		}
	}
	return isItTrue;
} // end of checkViewRequestStatus

public void clickOnAllMyRequestRadioButton() throws Exception
{
	/*
	 * this clisk on the All My Requests radio button in the view Request form
	 */
	forms.button(44, "//forms:button[(@name='JOBS_QF_FIND_0')]")
	.click(); // click on allmy fequest
	{
		think(2.0);
	}
	while (true)
	{
		// check until the program view request form is on the screen
		if (forms.textField(49, "//forms:textField[(@name='JOBS_PROGRAM_0')]")
					.exists())
			break;
		else
			delay(2000);
	}
} // end of clickOnAllMyRequestRadioButton

public void ScreenShot(boolean Web,boolean Forms, String PAR_ImageName) throws Exception 
{
	/** 
	*
	* The Screenshot function will create a .jpg image in a special sub folder
	* named "ScreenShots" in the current result playback session.   The parameters 
	* passed are:
	* Web - this is a boolean value where true is if we are capturing a web page
	* Forms - this is a boolean value where true is if we are capturing a Forms applet
	* PAR_ImageName - is the name we are giving the image without the file extension.  You have to concatenate the image path and the file extension. (see sample usage) 
	* 
	* the following OpenScript Global variables must have been set to a string value prior to calling this function
	* GLBL_IC_Left 
	* GLBL_IC_Top
	* GLBL_IC_HorizontalRes
	* GLBL_IC_VerticalRes
	* 
	* Dependencies:
	* You must call setupScreenshotParameters() at the top of your program before you run this function
	* 
	* Sample usage:
	* ScreenShot(false,true,GLBL_IC_ImagePath+"01_EnterMaterialRedistributionParameters"+a+".jpg");
	*/
	String ResultsReport = getSettings().get("oats_session_result_dir")+"\\ScreenShots";
	String imagepath=getVariables().get("GLBL_IC_ImagePath");
	String ImageName = imagepath+PAR_ImageName + ".jpg";
	int local_GLBL_IC_Left = Integer.valueOf(getVariables().get("GLBL_IC_Left"));
	int local_GLBL_IC_Top = Integer.valueOf(getVariables().get("GLBL_IC_Top"));
	int local_GLBL_IC_HorizontalRes = Integer.valueOf(getVariables().get("GLBL_IC_HorizontalRes"));
	int local_GLBL_IC_VerticalRes = Integer.valueOf(getVariables().get("GLBL_IC_VerticalRes"));

	if(Web)
	{
		web.window(
			"/web:window[@index='0' or @title='www.oracle.com - Bing']")
			.capturePage(ResultsReport, ImageName);
	}
	if(Forms)
	{
	ft.getScreenCapture(local_GLBL_IC_Left, 
		local_GLBL_IC_Top, 
		local_GLBL_IC_HorizontalRes, 
		local_GLBL_IC_VerticalRes, 
		ImageName);

	info("Completed Screenshot");
	}
} // end of ScreenShot


public String setupScreenshotParameters(String PAR_GLBL_IC_Left,String PAR_GLBL_IC_Top, String PAR_GLBL_IC_HorizontalRes, String PAR_GLBL_IC_VerticalRes ) throws Exception
{
	/*
	 * This function is needed to setup the variables for the ScreenShot function.
	 * This function sets up the global OpenScript Variables that is being used by ScreenShot():
	 * GLBL_IC_Left 
	 * GLBL_IC_Top
	 * GLBL_IC_HorizontalRes
	 * GLBL_IC_VerticalRes
	 * 
	 * Returns:
	 * String GLBL_IC_ImagePath = This is the path where the Screenshots are being saved.  This is the results folder for the specific run
	 * 
	 * usage:
	 * String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980")
	 */
	// setup screenshot related global variables
	String GLBL_IC_Left = PAR_GLBL_IC_Left;
	String GLBL_IC_Top = PAR_GLBL_IC_Top; 
	String GLBL_IC_HorizontalRes = PAR_GLBL_IC_HorizontalRes; 
	String GLBL_IC_VerticalRes = PAR_GLBL_IC_VerticalRes ;

	getVariables().set("GLBL_IC_Left", GLBL_IC_Left, Variables.Scope.GLOBAL);
	getVariables().set("GLBL_IC_Top", GLBL_IC_Top, Variables.Scope.GLOBAL);
	getVariables().set("GLBL_IC_HorizontalRes", GLBL_IC_HorizontalRes, Variables.Scope.GLOBAL);
	getVariables().set("GLBL_IC_VerticalRes", GLBL_IC_VerticalRes, Variables.Scope.GLOBAL);
	// this is old code - String GLBL_IC_ImagePath = "c:\\oracle\\OracleATS\\OFT\\GCSS-MC\\TS_04-MaterialDistribution\\results\\";
	String GLBL_IC_ImagePath = getSettings().get("oats_session_result_dir")+"\\";
	getVariables().set("GLBL_IC_ImagePath", GLBL_IC_ImagePath, Variables.Scope.GLOBAL);
	
	return GLBL_IC_ImagePath;
} // end of setupScreenshotParameters

public boolean enterMaterialNIINNumber(String PAR_itemNumber, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the item number is not editable and function did not do its correct function
	 */
	// first make sure that the item number field is editable before continuing this function
	if (!forms.textField(1533,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+PAR_LineNumber+"')]")
			.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1533,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+PAR_LineNumber+"')]")
			.setText(PAR_itemNumber);
	{
		think(1.0);
	}
	forms.textField(1534,
			"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+PAR_LineNumber+"')]")
			.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // enterMaterialNIINNumber

public boolean enterMaterialUnitOfMeasure(String PAR_UnitOfMeasure, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the Field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(1772,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1772,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+PAR_LineNumber+"')]")
	.setText(PAR_UnitOfMeasure);
	{
		think(1.0);
	}
	forms.textField(1772,
	"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+PAR_LineNumber+"')]")
	.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // enterMaterialUnitOfMeasure

public boolean enterMaterialQuantity(String PAR_Quantity, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the Field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(1773,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1773,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+PAR_LineNumber+"')]")
	.setText(PAR_Quantity);
	{
		think(1.0);
	}
	forms.textField(1773,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+PAR_LineNumber+"')]")
	.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterMaterialQuantity

public boolean enterMaterialOrg(String PAR_Org, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(1776,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(1776,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+PAR_LineNumber+"')]")
	.setText(PAR_Org);
	{
		think(1.0);
	}
	forms.textField(1776,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+PAR_LineNumber+"')]")
	.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterMaterialOrg

public boolean enterMaterialSubinventoryCode(String PAR_SubinventoryCode, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(
		1778,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(
		1778,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+PAR_LineNumber+"')]")
	.setText(PAR_SubinventoryCode);
	{
		think(1.0);
	}
	forms.textField(
		1778,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterMaterialSubinventoryCode

public boolean enterMaterialLocator(String PAR_Locator, int PAR_LineNumber) throws Exception
{
	/*
	 * returns false if the field is not editable and function did not do its correct function
	 */
	// first make sure that the field is editable before continuing this function
	if (!forms.textField(2009,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+PAR_LineNumber+"')]")
		.isEditable())
		return false;
	{
		think(1.0);
	}
	forms.textField(2009,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+PAR_LineNumber+"')]")
	.setText(PAR_Locator);
	{
		think(1.0);
	}
	forms.textField(2009,
		"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+PAR_LineNumber+"')]")
		.invokeSoftKey("NEXT_FIELD");
	{
		think(1.0);
	}
	return true;
} // end of enterMaterialLocator

public void enterMultipleTaskMaterials(String PAR_DatabankName,
		String PAR_GLBL_IC_ImagePath) throws Exception
		{
			/*
			 * 
			 * 
			 * This function allows multiple task material entry.
			 * it requires a databank to be read with the data to be used
			 * The databank must have the following fields
			 * - Service Activity Code (ServiceActivityCode)
			 * - NIIN (NIIN)
			 * - Unit of Measure (UnitOfMeasure)
			 * - Quantity (Quantity)
			 * - Inventory Org (InventoryOrg)
			 * - Subinventory Code (SubinventoryCode)
			 * - Subinventory locator (InventoryLocator)
			 * - Serial number (optional or enter null) (SerialNumber)
			 * 
			 * your databank must look similar to this below (see MaterialsToDebrief.csv from manny's databank folder)
			 * ServiceActivityCode,NIIN,UnitOfMeasure,Quantity,InventoryOrg,SubinventoryCode,InventoryLocator,SerialNumber
			 * SECREP Exchange,014745704,EA,1,1CJ,01F,C000001AF,1234567
			 * Inventory Type,014787314,EA,1,1CJ,01F,X000001AF,null
			 * 
			 * parameters
			 * PAR_DatabankName - name of your .csv databank.  This must be located in a recognized repository
			 * PAR_GLBL_IC_ImagePath - this is the path where the images will be saved.  usually the results folder
			 * 
			 * dependencies
			 * 1) make sure you setup the screenshot environment to setup the global variable GLBL_IC_ImagePath 
			 * at the beginning of your script by calling:
			 * String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980");
			 * 2) your must have the Screenshot function in your program. (ScreenShot(boolean Web,boolean Forms, String ImageName))
			 * 
			 * psuedo code
			 * 1) read the databank and get the number of records to process
			 * 2) while there are records to process:
			 * 2.a) get the record values and assign them to an opensript variable
			 * 2.b) save the openscript variable into a java variable
			 * 2.c) enter the record
			 * 2.d) save the record and wait until the green bar comes on
			 * 2.e) loop and get the next record
			 * 
			 * many gochuico 6-21-2021
			 */
	
	/*
	 * get the number of records in the databank
	 * 
	 */
	getDatabank(PAR_DatabankName).getNextDatabankRecord();
	int numberOfRecordsToProcess = getDatabank(PAR_DatabankName).getDatabankRecordCount();
	int MaterialLineNumber = 0;
	String PAR_ServiceActivityCode = null;
	String PAR_NIIN=null;
	String PAR_UnitOfMeasure= null;
	String PAR_Quantity= null;
	String PAR_Org= null;
	String PAR_SubinventoryCode = null;
	String PAR_Locator= null;
	String PAR_SerialNumber=null;

	int PAR_LineNumber = 0;
	
	for (int currentRecord=1;currentRecord<=numberOfRecordsToProcess;currentRecord++)
	{
		// get the record from the databank
		getDatabank(PAR_DatabankName).getRecord(currentRecord); // gets the first record
		// get the quantity and other information from the databank
		// Manifest Quantity

		info("ServiceActivityCode Record beign read ---> "+String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}"));

		PAR_ServiceActivityCode=String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}");
		PAR_NIIN = String.valueOf("{{db."+PAR_DatabankName+".NIIN}}");
		PAR_UnitOfMeasure = String.valueOf("{{db."+PAR_DatabankName+".UnitOfMeasure}}");
		PAR_Quantity = String.valueOf("{{db."+PAR_DatabankName+".Quantity}}");
		PAR_Org = String.valueOf("{{db."+PAR_DatabankName+".InventoryOrg}}");
		PAR_SubinventoryCode = String.valueOf("{{db."+PAR_DatabankName+".PAR_SubinventoryCode}}");
		PAR_Locator = String.valueOf("{{db."+PAR_DatabankName+".InventoryLocator}}");
		PAR_SerialNumber = String.valueOf("{{db."+PAR_DatabankName+".SerialNumber}}");

		
		getVariables().set(PAR_ServiceActivityCode,
			String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}"), Variables.Scope.GLOBAL);
		// Receipt Quantity
		getVariables().set(PAR_NIIN,
			String.valueOf("{{db."+PAR_DatabankName+".NIIN}}"), Variables.Scope.GLOBAL);
		// Receipt Subinventory
		getVariables().set(PAR_UnitOfMeasure,
			String.valueOf("{{db."+PAR_DatabankName+".UnitOfMeasure}}"), Variables.Scope.GLOBAL);
		// Receipt Locator
		getVariables().set(PAR_Quantity,
			String.valueOf("{{db."+PAR_DatabankName+".Quantity}}"), Variables.Scope.GLOBAL);
		// Receipt Serial Number or null
		getVariables().set(PAR_Org,
			String.valueOf("{{db."+PAR_DatabankName+".InventoryOrg}}"), Variables.Scope.GLOBAL);
		getVariables().set(PAR_SubinventoryCode,
			String.valueOf("{{db."+PAR_DatabankName+".SubinventoryCode}}"), Variables.Scope.GLOBAL);
		getVariables().set(PAR_Locator,
			String.valueOf("{{db."+PAR_DatabankName+".InventoryLocator}}"), Variables.Scope.GLOBAL);
		getVariables().set(PAR_SerialNumber,
			String.valueOf("{{db."+PAR_DatabankName+".SerialNumber}}"), Variables.Scope.GLOBAL);
	
		PAR_ServiceActivityCode=getVariables().get(PAR_ServiceActivityCode);
		PAR_NIIN = getVariables().get(PAR_NIIN);
		PAR_UnitOfMeasure = getVariables().get(PAR_UnitOfMeasure);
		PAR_Quantity = getVariables().get(PAR_Quantity);
		PAR_Org = getVariables().get(PAR_Org);
		PAR_SubinventoryCode = getVariables().get(PAR_SubinventoryCode);
		PAR_Locator = getVariables().get(PAR_Locator);
		PAR_SerialNumber = getVariables().get(PAR_SerialNumber);
	

		enterDebriefServiceActivityCode( PAR_ServiceActivityCode,PAR_LineNumber );
		enterMaterialNIINNumber( PAR_NIIN,  PAR_LineNumber);
		enterMaterialUnitOfMeasure( PAR_UnitOfMeasure,  PAR_LineNumber);
		enterMaterialQuantity( PAR_Quantity,  PAR_LineNumber);
		enterMaterialOrg( PAR_Org,  PAR_LineNumber);
		enterMaterialSubinventoryCode( PAR_SubinventoryCode,  PAR_LineNumber);
		enterMaterialLocator( PAR_Locator,  PAR_LineNumber);
		enterDebriefMaterialSerialNumber( PAR_SerialNumber,  PAR_LineNumber);
		ScreenShot(false,true,PAR_GLBL_IC_ImagePath+currentRecord+"_MultipleMaterialDebrief.jpg");
		clickOnDebriefMaterialSaveButton();

		delay (5000); // wait for 5 seconds. 
		// checkIfRecordIsGreen( PAR_LineNumber,PAR_GLBL_IC_ImagePath,Integer.toString(currentRecord));
		
		PAR_LineNumber = PAR_LineNumber++;
	} // end of for
} // end of enterMultipleTaskMaterials

public boolean runDebriefProcess() throws Exception
{
	boolean debriefProcessCompletedSuccessfully = false;
	
	try
	{
		/*
		 * Run with soft Cert 236
		 * 
		 * input global variable needed
		 * String myURL - this is the URL of the instance where you will be running the script
		 * String GLBL_ServiceRequestNumber - this is your SR number
		 * String GLBL_DatabankName - This is the name of your csv file
		 * 
		 * input databank variables
		 * you must have a databank (.csv file) with 2 records and add this to your master driver as an asset  
		 * 
		 * The folling fields must be prsent in your databank 
		 * String ServiceRequestNumber - This is your Service request number to debrief
		 * String ServiceActivityCode = This is your activity code. for example: SECREP Exchange, Inventory Type
		 * String itemNumber = This is your NIIN number
		 * String UnitOfMeasure = This is the NIIN unit of measure
		 * String Quantity = This is the SR quantity to debrief
		 * String Org = This is the inventory org
		 * String SubinventoryCode = This is the subinventory code
		 * String Locator = This is the subinventory locator
		 * String SerialNumber = This is the serial number if applicable
		 * 
		 * CSV file format example
		 * 			"SECREP Exchange","014745704","EA","1","1CJ","01F","C000001AF",null
		 *			"SECREP Exchange","014661855","EA","1","1CJ","01F","X000001AF",null
		 *
		 * output global variables
		 * GLBL_CarcassNumberS - this is a string delimited by "," containing the carcass numbers created by the debrief
		 * GLBL_ReplacementNumberS - this is  string delimited by "," containing the replacement numbers created by the debrief
		 * 
		 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 * environment settings section
		 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 */
		
		

		/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 * get the global environment variables
		 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 */
		String GLBL_EBS_URL = getVariables().get("myURL");
		String GLBL_SRNumber = getVariables().get("GLBL_ServiceRequestNumber");
		/*
		 * ++++++++++++ END OF GET GLOBAL ENVIROMENT VARIABLES +++++++++++++++++++++++++++++++++
		 */	
	    
	    //set up the Screenshot parameters
	    String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980");
	    
	    
		/* ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 * Read Playback Settings Section
		 * get the settings variables and save then in a global variable
		 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 */
		/*
		 * ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 * ++++++++++++ END OF GET SETTING VARIABLES SECTION +++++++++++++++
		 * +++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
		 */		
	    String PAR_DatabankName = getVariables().get("GLBL_DatabankName");
	    getDatabank(PAR_DatabankName).getNextDatabankRecord();
	    int numberOfRecordsToProcess = getDatabank(PAR_DatabankName).getDatabankRecordCount();
	

		
		/*
		web.window(2, "/web:window[@index='0' or @title='about:blank']")
		.navigate(
				"https://gcssmc-pt-ebs.int.gcssmc.sde/OA_HTML/AppsLogin");
				*/



	browser.launch();
	//delay(12000);
	web.window(2, "/web:window[@index='0' or @title='about:blank']")
	.navigate(
		GLBL_EBS_URL);

		String myCarcassNumber = null;
		String myReplacementNumber = null;
		
		int ProcessingLineNumber = 0; // this is the current Material Line Number

	/*	
		beginStep(
			"[1] working banner",
			0);
	{
		workingBanner();
	}
	
	endStep();
	*/
		
	beginStep("[2] select responsiblity", 0);
	{
		enterResponsiblity("GCSS-MC Maintenance Chief","Service Request");
		

	}
	endStep();
	beginStep("[3] Navigate to Find Service reqest form", 0);
	{
		SS_getEBSNavigationAndClickOnMenuItems("Service Request;Service Requests;Find Service Requests", ";");

	}
	endStep();
	beginStep("[4] Find Service Request", 0);
	{
		//FindServiceRequest("27628862");
		FindServiceRequest(GLBL_SRNumber,GLBL_IC_ImagePath);
	}
	endStep();
	beginStep("[5] Click On Task Tab", 0);
	{
		clickOnTaskTab();
	}
	endStep();

	beginStep("[6] Click on Debrief button", 0);
	{
		ScreenShot(false,true,GLBL_IC_ImagePath+"02_ClickOnDebriefButton.jpg");
		
		clickOnDebriefButton();
		

	}
	endStep();
	beginStep("[7] Click on Materials Tab", 0);
	{
		ScreenShot(false,true,GLBL_IC_ImagePath+"03_DebriefScreen.jpg");
		
		clickOnMaterialTab();

		}
	endStep();
	beginStep("[8] Enter materials", 0);
	{
		
		for (int currentRecord=1;currentRecord<=numberOfRecordsToProcess;currentRecord++)
		{
			// get the record from the databank
			getDatabank(PAR_DatabankName).getRecord(currentRecord); // gets the first record
			// 
			
			info("ServiceActivityCode Record beign read ---> "+String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}"));

			String GLBL_ServiceActivityCode=String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}");
			String GLBL_itemNumber = String.valueOf("{{db."+PAR_DatabankName+".itemNumber}}");
			String GLBL_UnitOfMeasure = String.valueOf("{{db."+PAR_DatabankName+".UnitOfMeasure}}");
			String GLBL_Quantity = String.valueOf("{{db."+PAR_DatabankName+".Quantity}}");
			String GLBL_Org = String.valueOf("{{db."+PAR_DatabankName+".Org}}");
			String GLBL_SubinventoryCode = String.valueOf("{{db."+PAR_DatabankName+".SubinventoryCode}}");
			String GLBL_Locator = String.valueOf("{{db."+PAR_DatabankName+".Locator}}");


			
			// ServiceActivityCode
			getVariables().set("GLBL_ServiceActivityCode",
				String.valueOf("{{db."+PAR_DatabankName+".ServiceActivityCode}}"), Variables.Scope.GLOBAL);
			// itemNumber
			getVariables().set("GLBL_itemNumber",
				String.valueOf("{{db."+PAR_DatabankName+".itemNumber}}"), Variables.Scope.GLOBAL);
			// UnitOfMeasure
			getVariables().set("GLBL_UnitOfMeasure",
				String.valueOf("{{db."+PAR_DatabankName+".UnitOfMeasure}}"), Variables.Scope.GLOBAL);
			// Quantity
			getVariables().set("GLBL_Quantity",
				String.valueOf("{{db."+PAR_DatabankName+".Quantity}}"), Variables.Scope.GLOBAL);
			// Org
			getVariables().set("GLBL_Org",
				String.valueOf("{{db."+PAR_DatabankName+".Org}}"), Variables.Scope.GLOBAL);
			// SubinventoryCode
			getVariables().set("GLBL_SubinventoryCode",
				String.valueOf("{{db."+PAR_DatabankName+".SubinventoryCode}}"), Variables.Scope.GLOBAL);
			// Locator
			getVariables().set("GLBL_Locator",
				String.valueOf("{{db."+PAR_DatabankName+".Locator}}"), Variables.Scope.GLOBAL);
		
		ScreenShot(false,true,GLBL_IC_ImagePath+"04_MaterialDebriefScreen.jpg");
		
		/* example of how the first record will look like to make the first call
		enterTaskMaterialDebrief(ProcessingLineNumber,
			"SECREP Exchange",
			"014745704",
			"EA",
			"1",
			"1CJ",
			"01F",
			"C000001AF",
			null,
			GLBL_IC_ImagePath,
			"05");
		*/ 
		/* sample data to run the second debrief
		enterTaskMaterialDebrief(ProcessingLineNumber,
			"SECREP Exchange",
			"014661855",
			"EA",
			"1",
			"1CJ",
			"01F",
			"X000001AF",
			null,
			GLBL_IC_ImagePath,
			"06");
		 */
		
		enterTaskMaterialDebrief(ProcessingLineNumber,
			getVariables().get("GLBL_ServiceActivityCode"),
			getVariables().get("GLBL_itemNumber"),
			getVariables().get("GLBL_UnitOfMeasure"),
			getVariables().get("GLBL_Quantity"),
			getVariables().get("GLBL_Org"),
			getVariables().get("GLBL_SubinventoryCode"),
			getVariables().get("GLBL_Locator"),
				null,
				GLBL_IC_ImagePath,
				Integer.toString(currentRecord));
				
		if (currentRecord==1) 
		{
		myCarcassNumber = getVariables().get("GLBL_CarcassNumber");
		myReplacementNumber = getVariables().get("GLBL_ReplacementNumber");
		}
		else
		{
			myCarcassNumber = myCarcassNumber+","+getVariables().get("GLBL_CarcassNumber");
			myReplacementNumber = myReplacementNumber+"," + getVariables().get("GLBL_ReplacementNumber");
		}
		info("myCarcassNumber ===> "+myCarcassNumber);
		info("myReplacementNumber ===> "+myReplacementNumber);
		
		// save the carcass and the replacement number into global variables
		getVariables().set("CarcassNumber",myCarcassNumber);
		getVariables().set("ReplacementNumber",myReplacementNumber) ;
		
		ProcessingLineNumber++;
		
	} // end of for
		
		ScreenShot(false,true,GLBL_IC_ImagePath+"07_MaterialDebriefCompletion.jpg");
	}
	endStep(); // endStep[8]
	
	beginStep("[9] Close Debrief and SR tracking forms", 0);
	{
		closeDebriefForm();
		closeSRTrackingForm();
		ExitEBS();
		
	}
	endStep(); // endStep[9]
	
	beginStep("[10] Print Carcass Numbers", 0);
	{
		for (int processingCarcassNumber=0;processingCarcassNumber<=ProcessingLineNumber;processingCarcassNumber++)
		{
			printDD_1348(myCarcassNumber,",");  // should use an array here to get the two carcass numbers
		}
	}
	endStep(); // endStep[10]
		
		debriefProcessCompletedSuccessfully = true;
	} catch (Exception e)
	{
		info ("Debrief process completed with an error: "+ e.getMessage());
		return debriefProcessCompletedSuccessfully;
	}
	return debriefProcessCompletedSuccessfully;
} // end of runDebriefProcess

public void runConsolidatedAssetListingReport(String PAR_Responsiblity, 
		String PAR_ConcurrentReportName,
		String PAR_ParentAAC,
		String PAR_ChildAAC,
		String PAR_PrimeSummaryOnly,
		String PAR_SupressInactiveNSN) throws Exception
{
/*
* Run this script after connecting to EBS via soft certificate 238
* 
* This script starts with the clicking of the OK button in the orange warning banner
* 
* Parameters:
* String PAR_Responsibility - this is the responsib lity where the report will be run.  normally, "GCSS-MC Inventory / Supply Officer"
* String PAR_CurrentReportname - this is the name of the concurrent program. normally "Consolidated Asset Listing (Spreadsheet)"
* String PAR_ParentAAC - This is the Parent AAC parameter/organization for the report. normally,"MMFAF7"
* String PAR_ChildAAC - This is the Parent AAC parameter/organization for the report. normally,"MMFAF7"
* String PAR_PrimeSummaryOnly - This is answerable by Y or N.  normally, "N"
* String PAR_SupressInactiveNSN - This is answerable by Y or N.  normally, "Y"
* 
* usage example:
* runConsolidatedAssetListingReport("GCSS-MC Inventory / Supply Officer", "Consolidated Asset Listing (Spreadsheet)","MMFAF7","MMFAF7","N", "Y")
* 
* 
* Manny Gochuico, CACI
*/
String GLBL_RequestID = null;

/*
* Setup Screenshop parameters
*/
String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980");




beginStep(
"[1] working banner",
0);
{
workingBanner();
}
endStep();

beginStep("[2] enter responsibility", 0);
{
enterResponsiblity(PAR_Responsiblity, "Reports");

}
endStep();
beginStep("[3] Navigate to EBS Forms", 0);
{
	// navigate to bogus form to prevent OATS from clicking the wrong transaction menu item
	SS_getEBSNavigationAndClickOnMenuItems("Reports;Movement Statistics",";");
	selectInventoryOrganization("MRA","01_getInventoryOrganization");
	clickOnReportTypeResponseButton("Cancel");
	
	
}
endStep();

beginStep("[5] Activate navigator window", 0);
{
{
think(1.0);
}
forms.window(20, "//forms:window[(@name='NAVIGATOR')]").activate(
true); // activate the navigator



}
endStep();
beginStep("[6] Navigator - GCSS-MC Inventory / Supply Officer", 0);
{
forms.captureScreenshot(22);
{
think(1.0);
}
if (forms.listOfValues(23, "//forms:listOfValues").exists())
forms.listOfValues(23, "//forms:listOfValues").clickCancel();
}
endStep();


beginStep("[7] Initiate Concurrent Request", 0);
{
clickOnViewRequests("NAVIGATOR");

}
endStep();
beginStep("[8] click on Submit new Request button", 0);
{
clickOnSubmitNewRequestsButton();
}

endStep();
beginStep("[9] Submit Request", 0);
{
enterConcurrentOrReportName(PAR_ConcurrentReportName);

ScreenShot(false,true,GLBL_IC_ImagePath+"01_EnterConcurrentProgramName.jpg");
}
endStep();
beginStep("[10] Parameters", 0);
{
// get these values from the .csv file or from the Preference table. for now I hardcoded it.
enterReportParameter("Parent AAC", PAR_ParentAAC);
enterReportParameter("Child AAC", PAR_ChildAAC);
enterReportParameter("Prime Summary Only?", PAR_PrimeSummaryOnly);
enterReportParameter("Suppress Inactive NSNs?", PAR_SupressInactiveNSN);

ScreenShot(false,true,GLBL_IC_ImagePath+"02_EnterConcurrentProgramParameters.jpg");

clickOKOnParameterWindow();
}
endStep();
beginStep("[11] Submit Request", 0);
{
clickOKOnSubmitRequestButton();
boolean RequestSubmittedAndSaved = checkIfTheRecordWasSaved("records applied and saved");

}
endStep();
beginStep("[12] get Request ID and then click No button", 0);
{
GLBL_RequestID = getRequestIDThenClickButton("No");
}
endStep();
beginStep("[13] Find Requests and click reresh until complete", 0);
{
findTheSpecificRequestByProgramName(PAR_ConcurrentReportName);

ScreenShot(false,true,GLBL_IC_ImagePath+"03_EnterConcurrentProgramCompletion.jpg");

}
endStep();
beginStep("[14] Close Requests Jobs Window", 0);
{
closeViewRequestsJobsWindow(); // close the jobs window


}
endStep();
beginStep("[15] Exit Oracle forms", 0);
{
ExitEBSandAllWebforms();
}
endStep();

} // end of runConsolidatedAssetListingReport

public boolean verifyDIC(int PAR_LineNumber, String PAR_DIC, String PAR_SDNNumber, String PAR_InventoryOrg) throws Exception
{
	/*
	 * this function verifies if a particular DIC exists in a receipt form
	 * 
	 * This function does the following sequentially:
	 * activate the navigator
	 * navigate to the custom forms MRP
	 * change organization
	 * enter SDN number and click on the find button
	 * check if the receipt form is ready to validate
	 * chack if the DIC exist
	 * closes the receript window
	 * closes the find SDN window
	 * goes back to activite the navigator
	 * 
	 * parameters
	 * PAR_LineNumber = this is line where the DIC status is tested. if 99, then the whole lines zone is searched until it finds it.
	 * PAR_DIC = this is the document status like FTR, FTR, D6T
	 * PAR_SDNNumber = this is the SDN Number
	 * PAR_InventoryOrg = this is the inventory org to be checked
	 *  
	 * sample usage
	 * verifyDIC(99, "FTE", "MMFAF711820012", "1CJ");
	 * 
	 * returns
	 * False = if the DIC line does not exist or the SDN cannot be found
	 * True = if the DIC line exist
	 * 
	 * manny gochuico (CACI 2021)
	 */
	String GLBL_IC_ImagePath = setupScreenshotParameters("0","0","1920","1980");
	boolean isDICVerified = false;
	String myImagename = "verifyDIC_"+PAR_DIC;
	
	// activate navigator
	activateNavigator();
	
	// navigate to Custom Forms MRP
	changeNavigationPathInEBSForms("Custom Forms;Document Management (MRP)", ";");
	
	// change organization
	selectInventoryOrganization(PAR_InventoryOrg);
	
	// enter SDN number and click on the find button
	EnterSDNNumberAndClickFindButton(PAR_SDNNumber);
	
	boolean ReceiptFormIsReady = false;
	
	ReceiptFormIsReady=checkIfSDNReceiptFormIsReady(PAR_SDNNumber);
	
	if (!ReceiptFormIsReady)
	{
		warn("SDNNumber **"+PAR_SDNNumber+"** does not exist!");
		return isDICVerified;
	}
	
	// check if DIC exist
	boolean PARDICExist = false;
	
	PARDICExist = checkIfCodeIdentifierExist(PAR_LineNumber, PAR_DIC);
	
	if (!PARDICExist)
	{
		warn(PAR_DIC+" does not exist!");
		closeEnterReceiptWindow();
		closeFindSDNWindow();
		return PARDICExist;
	}
	else PARDICExist=true;
	info(PAR_DIC+" is found. Success!");
	delay(1000);
	// take a screenshot
	ScreenShot(false,true, myImagename);
	closeEnterReceiptWindow();
	closeFindSDNWindow();
	
	return PARDICExist;
} // end of verifyDIC

public boolean checkIfSDNReceiptFormIsReady(String PAR_SDNNumber) throws Exception
{
	/*
	 * This function checks if the Receipt form for the SDN is populated with the SDN number and ready to to process
	 * 
	 * This is called before you start checking if FTE or FTR or any document status exist.
	 */
	boolean SDNReceiptFormIsReady = false;
	
	while(true)
	{
		if(forms.textField(26, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
					.exists())
			break;
		else
			delay(2000);
		
	} // end while (true)
	
	// at this point, the form already exist, check if the SDN number provided is valid
	String myFormSDNNumber = forms.textField(26, "//forms:textField[(@name='FIND_BLK_SDN_0')]")
	.getText();
	
	// check if it is blank
	if (myFormSDNNumber.isEmpty())
		return SDNReceiptFormIsReady;
	
	// compare with the parameter;
	if (myFormSDNNumber.equalsIgnoreCase(PAR_SDNNumber))
		SDNReceiptFormIsReady = true;
	
	return SDNReceiptFormIsReady;
} // end of checkIfSDNReceiptFormIsReady


public void findAndTransactShipMoveOrder(String PAR_SDNnumber) throws Exception
{
	/*
	 * this is a wrapper function to perform a Ship Move order
	 * 
	 * parameters:
	 * PAR_SDNNumber - this is the SDN number to transact
	 * 
	 */
	//activate navigator
	
	activateNavigator();
	
	// navigate to Shipping|Transactions
	changeNavigationPathInEBSForms("Shipping;Transactions", ";");
	
	// select inventory organization and take a screenshot
	selectInventoryOrganization("MRA","01_getInventoryOrganization");
	
	// enter SDN Nunmber
	enterQueryManagerDocumentNumberFindRange(PAR_SDNnumber, PAR_SDNnumber);
	
	// click OK on the choice box screen
	ClickOnChoiceBox("OK");
	
	// click on the blue man icon
	clickOnTransactMoveOrderIcon();
	
	// click on View/Update Allocations
	clickOnViewUpdateAllocationsButton();
	
	// generate serial number
	clickOnTransactMoveOrderLotSerialButton();
	generateLotSerial_SerialNumber();
	clickOnSerialNumberCreationDONEButton();
	
	// click transact button
	clickOnTransactMoveOrderLineAllocationTransactButton();
	
	// click OK button to acknowledge processed records
	ClickOnChoiceBox("OK");
	
	// close the transact window . this should bring you back to the navigator
	closeTransactMoveOrdersForm();
	
} // end of findAndTransactShipMoveOrder

public boolean enterShippingTransactionShippedQuantity(int PAR_LineNumber, int PAR_ShippedQuantity) throws Exception
{
	/*
	 * This enters the shipped quantity in the Shippng Transactions Form (Shipping->Transactions)
	 * 
	 * parameters
	 * int PAR_LineNumber - this is a zero-indexed line number
	 * int PAR_ShippedQuantity - this is the shipped quantity
	 * 
	 * returns
	 * true - if the quantity was successfully entered
	 * false - if the shipped quantity was NOT entered
	 */
	
	// first , ensure that the field is already on the screen
	while(true)
	{
	if (forms.textField(237,
	"//forms:textField[(@name='DLVB_SHIPPED_QUANTITY_"+PAR_LineNumber+"')]")
	.exists())
		break;
	else
		delay(2000);
	}
	
	// ensure it is editavble/enabled
	if (!forms.textField(237,
	"//forms:textField[(@name='DLVB_SHIPPED_QUANTITY_"+PAR_LineNumber+"')]")
	.isEditable())
		return false;
	
	// make the change
	forms.textField(237,
	"//forms:textField[(@name='DLVB_SHIPPED_QUANTITY_"+PAR_LineNumber+"')]")
	.setText(Integer.toString(PAR_ShippedQuantity));

		{
			think(2.0);
		}
	return true;
} // end of enterShippingTransactionShippedQuantity

public boolean enterTransactionControlNumber(int PAR_LineNumber, String PAR_SDNNumber, String PAR_TCNSuffix) throws Exception
{
	/*
	 * This is to enter value in the Transportation Control Number field locted in the Shipping transactions form
	 * 
	 * paramters
	 * int PAR_LineNumber - this is an zero-indexed based line number
	 * String PAR_SDNNumber - This is the SDN Number
	 * String PAR_TCNSuffix - this is the code to attach as a suffix.  for example "XXX"
	 * 
	 * usage example
	 * enterTransactionControlNumber(0, "MMFAF740430003", "XXX")
	 */
	
	boolean TCNwasUpdated = false;
	
	// ensure the field is already on screen
	while(true)
	{
		if(forms.textField(650, "//forms:textField[(@name='DLVY_WAYBILL_"+PAR_LineNumber+"')]")
			.exists())
			break;
		else
			delay(2000);
	}
	
	// ensure it is editable. if not return with a false value 
	if (!forms.textField(650, "//forms:textField[(@name='DLVY_WAYBILL_"+PAR_LineNumber+"')]")
			.isEditable())
		return TCNwasUpdated;
	
	{
		think(1.0);
	}
	forms.textField(650, "//forms:textField[(@name='DLVY_WAYBILL_"+PAR_LineNumber+"')]")
			.setText(PAR_SDNNumber+PAR_TCNSuffix);
	{
		think(2.0);
	}
	TCNwasUpdated = true;
	
	return TCNwasUpdated;
	
} // end of enterTransactionControlNumber


public boolean enterTransactionServicelevel(int PAR_LineNumber, String PAR_ServiceLevel) throws Exception
{
	/*
	 * This is to enter value in the Service Level field locted in the Shipping transactions form
	 * 
	 * paramters
	 * int PAR_LineNumber - this is an zero-indexed based line number
	 * String PAR_ServiceLevel - This is the SDN Number
	 * 
	 * 
	 * usage example
	 * enterTransactionServicelevel(0, "J")
	 * 
	 * returns
	 * True - if service level was populated
	 * False - if service Level was not populated
	 */
	
	boolean ServiceLevelwasUpdated = false;
	
	// ensure the field is already on screen
	while(true)
	{
		if(forms.textField(650, "//forms:textField[(@name='DLVY_SERVICE_LEVEL_NAME_"+PAR_LineNumber+"')]")
			.exists())
			break;
		else
			delay(2000);
	}
	
	// ensure it is editable. if not return with a false value 
	if (!forms.textField(650, "//forms:textField[(@name='DLVY_SERVICE_LEVEL_NAME_"+PAR_LineNumber+"')]")
			.isEditable())
		return ServiceLevelwasUpdated;
	
	{
		think(1.0);
	}
	forms.textField(650, "//forms:textField[(@name='DLVY_SERVICE_LEVEL_NAME_"+PAR_LineNumber+"')]")
			.setText(PAR_ServiceLevel);
	{
		think(2.0);
	}
	ServiceLevelwasUpdated = true;
	
	return ServiceLevelwasUpdated;
	
} // end of enterTransactionServicelevel

public void shipConfirmOrder(String PAR_SDNNumber, int PAR_ShippedQuantity) throws Exception
{
	/*
	 * This wrapper executes the Ship confirm order steps for MRP Secrep.
	 * 
	 * parameters
	 * String PAR_SDNNumber - SDN Number to Ship
	 * int PAR_ShippedQuantity - Quantity to ship
	 * 
	 * This starts from activatin the Forms navigator and finishes with the Forms Navigator
	 * 
	 * Manny gochuico (CACI)
	 */
	//activate navigator
	
	activateNavigator();
	
	// navigate to Shipping|Transactions
	changeNavigationPathInEBSForms("Shipping;Transactions", ";");
	
	// select inventory organization and take a screenshot
	selectInventoryOrganization("MRA","01_getInventoryOrganization");
	
	// enter SDN Nunmber
	enterQueryManagerDocumentNumberFindRange(PAR_SDNNumber, PAR_SDNNumber);
	
	// click OK on the choice box screen
	ClickOnChoiceBox("OK");
	
	boolean ShippedQuantityEntered = enterShippingTransactionShippedQuantity(0,PAR_ShippedQuantity);
	
	// click on delivery tab
	clickOnDeliveryTab();
	
	// enter transpoprtation control number
	boolean TCNUpdated = enterTransactionControlNumber(0, "MMFAF740430003", "XXX");
	
	// enterTrtansactdion service level
	enterTransactionServicelevel(0, "J");
	
	// click on ship confirm button
	clickOnShipConfirmButton();
	
	// click OK on shipmentConfirmation popup screen
	ClickOnChoiceBox("Ok");
	
	// click OK on Confirm Delivery popup Screen
	clickOnShipConfirmOKButton();
	
	// click OK on the messages pop-up screen
	clickOKinMessageForm();
	
	// click on DD-1348 Red document icon
	boolean redDocumentIconExist = clickOnRedDD_1348DocumentIcon();
	if (!redDocumentIconExist)
		redDocumentIconExist = clickOnToolsGenerateDD1348();
		
	// close shipping transactions Form
		closeShippingTransactionsForm();
		
	// now back to the navigator
	
	
} // end of shipConfirmOrder


public String getSDNNumberFromChoiceBoxMessage(String PAR_SDNNumbermask) throws Exception {
	/*
	 * Synopsis 
	 * primariy used by MRP SECREP TC_01 step 13
	 * this function parses the SDN Number from the choice
	 * message that has the SDN number 
	 * 
	 * 
	 *
	 * @param PAR_SDNNumbermask - This is a SDN mask identifer so that the SDN number can be identified within
	 * the message wihtout worrying where the SDN number would be in the message
	 * 
	 * @return 
	 * SDN Number - if the SDN Number was found within the string
	 * NONE - If the SDN Number was not found
	 * 
	 * usage example:
	 * getSDNNumberFromChoiceBoxMessage("MMF")
	 * 
	 * manny gochuico for CACI
	 */
	
	// get the message from the box
	String PAR_myString = forms.choiceBox(59, "//forms:choiceBox").getAlertMessage();
	
	// find the location of the SDN Number
	int indexOfSDNNumberInString = PAR_myString.indexOf(PAR_SDNNumbermask);
	
	if (indexOfSDNNumberInString==0)
		return "NONE";
	
	String mySDNNumber = PAR_myString.substring(indexOfSDNNumberInString, indexOfSDNNumberInString+14);
	info("mySDNNumber====> "+mySDNNumber);

	// click on the OK button to close the message window if the button exist
	forms.choiceBox(59, "//forms:choiceBox").clickButton("OK");
	
	return mySDNNumber;
} // end of getSDNNumberFromChoiceBoxMessage

public void PickPackAndShip(String PAR_SDNNumber) throws Exception
{
	
	

	/*
	 * This is a wrapper for the TC 12 integeration
	 * 
	 * 
	 */
	
	/*
	// warning banner
	workingBanner();
	
	// enter Responsibility
	enterResponsiblity("GCSS-MC Inventory / Supply Shipping and Receiving NCO", "Shipping");
	
	// navigate to the shipping transaction form
	// to go around the OATs issue of clicking on the wrong menu when there is a duplicate menu item in a higher level
	SS_getEBSNavigationAndClickOnMenuItems("Shipping;Reports and Documents",";");
	selectInventoryOrganization("MRA","01_getInventoryOrganization");
	clickOnReportTypeResponseButton("Cancel");
	
	// at this point the navigator is activated
	// now click on the correct navigation
	SS_getEBSNavigationAndClickOnMenuItems("Shipping;Transactions", ";");
	
	*/
	
	beginStep(
		"[1] E-Business Suite Home Page Redirect (/gcssmc-dv-ebs.dev.gcssmc.sde/)",
		0);
{
	web.window(2, "/web:window[@index='0' or @title='about:blank']")
			.navigate("https://gcssmc-dv-ebs.dev.gcssmc.sde/");
/*
 * 	web.window(4,
 
			"/web:window[@index='0' or @title='E-Business Suite Home Page Redirect']")
			.waitForPage(null);
*/
	{
		
		delay(3000);	
	}

}
endStep();
beginStep(
		"[2] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DFKejWyITGYsoP2Q0Q3sCRHdwIUXWf2Farvejx2YRxoFeYoN0uHPrTZr91mid1SIZ7%2BXfkCZ5KojJEo29W2lNYHKD%2FqZpWTz0ggmIQbYZIQ6p5x4gYYKBQ11oAFaKIfVzc0xEjsCzAHNpo%2FAXe8OmcQQ2SNonI0aWM868aH4NzhZppoZiHGkkbm (/obrareq.cgi)",
		0);
{
	/*
	web.window(6,
			"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
			.waitForPage(null);
	*/
	{
		delay(5000);
	}
	web.button(
			7,
			"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
			.click();
	{
		delay(2000);
	}
	/*
	web.notificationBar(8,
			"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
			.clickButton("Close");
	*/
}
endStep();
beginStep("[3] Home (/OA.jsp)", 0);
{
	/*
	web.window(9, "/web:window[@index='0' or @title='Home']")
			.waitForPage(null);
	*/
	{
		delay(12000);
	}
	web.element(
			12,
			"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Inventory / Supply Shipping & Receiving NCO' or @index='58']")
			.click();
}
endStep();
beginStep("[4] Home (/OA.jsp)", 0);
{
	/*
	web.window(13, "/web:window[@index='0' or @title='Home']")
			.waitForPage(null);
	*/
	{
		delay(8000);
	}
	web.element(
			16,
			"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Shipping' or @index='178']")
			.click();
}
endStep();
beginStep("[5] Home (/OA.jsp)", 0);
{
	/*
	web.window(17, "/web:window[@index='0' or @title='Home']")
			.waitForPage(null);
	*/
	{
		delay(3000);
	}
	web.element(
			20,
			"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Transactions' or @index='180']")
			.click();
	{
		delay(6000);
	}
	forms.window(21, "//forms:window[(@name='SHIPPING_TRANSACTIONS')]")
			.activate(true);
}
endStep();
beginStep("[6] Organizations (Working...)", 0);
{
	forms.captureScreenshot(22);
	{
		think(20.085);
	}
	forms.listOfValues(23, "//forms:listOfValues").find("%MRA%");
}
endStep();
beginStep("[7] Organizations", 0);
{
	forms.captureScreenshot(26);
}
endStep();


	
	// enter the SDN number
	enterQueryManagerDocumentNumberFindRange(PAR_SDNNumber, PAR_SDNNumber);
	// click OK on the choicebox message
	ClickOnChoiceBox("OK");
	
	// select record to pick, pack and ship
	
	// click on Actions and select Pick and Ship
	clickOnShippingActionLOVandPressGoButton("Pick and Ship");
	
	// click on the blue man icon
	clickOnTransactMoveOrderIcon();
	
	// click on View/Update Allocations
	clickOnViewUpdateAllocationsButton();
	
	// generate serial number
	clickOnTransactMoveOrderLotSerialButton();
	generateLotSerial_SerialNumber();
	getStartSerialNumber();
	getEndSerialNumber();
	clickOnSerialNumberCreationDONEButton();
	
	// click transact button
	clickOnTransactMoveOrderLineAllocationTransactButton();
	
	// click OK button to acknowledge processed records
	ClickOnChoiceBox("OK");
	
	// close the transact window . this should bring you back to the navigator
	closeTransactMoveOrdersForm();
	
	// close the shipping form
	closeShippingTransactionsForm();
	
	// query the SDN again
	enterQueryManagerDocumentNumberFindRange(PAR_SDNNumber, PAR_SDNNumber);
	
	// click OK on the message button
	clickOKinMessageForm();
	
	// click OK on confirm delivery popup window

	clickOnDeliveryTab();
	clickOnShipConfirmButton();
	
	// close the shipping form
	closeShippingTransactionsForm();
	
	
} // end of PickPackAndShip


} // end of the program
