import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {

		getVariables().set("Search_Item_Instance", "{{db.MI_Process_Manager_Input.Search_Item_Instance, 317456979}}", Variables.Scope.GLOBAL);
		getVariables().set("Search_Serial_Number", "2F0F-701-8E8", Variables.Scope.GLOBAL); //591127
		getVariables().set("AO_Assignee_Name", "CHALKLEY, COL., ADAM L", Variables.Scope.GLOBAL);
		getVariables().set("RO_Assignee_Name", "GABRIELLOPEZ, CPL., CHRISTIAN O", Variables.Scope.GLOBAL);
		getVariables().set("MyURL", "https://gcssmc-ebs.cm.gcssmc.sde/OA_HTML/AppsLogin", Variables.Scope.GLOBAL);
		getVariables().set("GLBL_Prefix_AORO_File_Name","TC_06", Variables.Scope.GLOBAL);
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		//processAOROAssignmentByInstanceNumber();
		
		processAOROAssignmentBySerialNumber();
		
	} // public void run()

	public void finish() throws Exception {
		
		
	}	

	public void openBrowserGCSSMC() throws Exception {
		browser.launch();
	}

	public void closeBrowserGCSSMC() throws Exception {
		browser.close();
	}
	
	/*
	 * Uses TEST238 login using MyURL
	 * Navigation steps
	*/
	public void navigateToItemDetailPage() throws Exception {
		try
		{
			beginStep("navigateToItemDetailPage() - Navigate to ItemDetailPage using 238");
			{
				beginStep(" navigateToItemDetailPage() - Navigate to GCSS URL", 0);
				{
					getVariables().set("MyUser", "238", Variables.Scope.GLOBAL);
					getScript("CACI_FunctLib_EBSFunctions")
							.callFunction(
									"EBSCertificateLogin",
									"{{MyURL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}",
									"{{MyUser,243}}");
				}
				endStep();	
				
				getScript("CACI_FunctLib_EBSFunctions").callFunction("enterResponsiblity", "GCSS-MC Inventory / Supply Officer","Service Request");
	
				getScript("CACI_FunctLib_EBSFunctions").callFunction("SS_getEBSNavigationAndClickOnMenuItems", "Service Request;Installed Base;View and Transfer Customer Item Instances",";");
				beginStep("Navigate to Item Detail Page");
				{
					String screenshotFileName = "{{GLBL_Prefix_AORO_File_Name}}" + "_Navigate_Item_Detail";
					getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", screenshotFileName);
					delay(3000);
					screenshotFileName = null;
				}
				
				delay(3000); // There is no EBS open so no script to handle those javaScript is necessary and the delay is minimal here 
					
			}
		}
		catch(Exception e) {
			info("navigateToItemDetailPage () : " + e.getMessage());
			throw e;
		}
		endStep();
	}  //  public void navigateToItemDetailPage()
	
	
	/*
	 * Search using the Serial Number
	 * Confirm the Serial Information exists on Configuration tab
	*/
	public void confirmSerialNumberExistsOnConfiguration() throws Exception {
		try
		{
			beginStep("confirm SerialNumber exists on Configuration Tab");
			{
				openBrowserGCSSMC();
				delay(2500);

				navigateToItemDetailPage();
				delay(3000);
				
				searchBySerialNumber("{{Search_Serial_Number}}");
				
				processItemDetailUpdate();

				delay(3000);
				/*
				getScript("ItemOwnerAssignment").callFunction("itemAOROAssignment", "Accountable Officer", "{{AO_Assignee_Name}}");
				delay(3000);
				
				getScript("ItemOwnerAssignment").callFunction("itemAOROAssignment", "Responsible Officer", "{{RO_Assignee_Name}}");
				delay(3000);
				*/
				closeBrowserGCSSMC();
				delay(2500);
				
			} // beginStep("confirm SerialNumber exists on Configuration Tab")
			endStep();
			
		}
		catch (Exception e)
		{
			info("confirmSerialNumberExistsOnConfiguration() : " + e.getMessage());
			throw e;
		}
	}  // public void confirmSerialNumberExistsOnConfiguration()
	
	
	
	/*
	 * Assumes it is already on the Item Search page
	 * search using the Item Instance
	 * Process AO Assignment followed by RO Assignment
	*/
	public void processAOROAssignmentByInstanceNumber() throws Exception {
		try
		{
			beginStep("process AO/RO Assignment processAOROAssignmentByInstanceNumber()");
			{
				openBrowserGCSSMC();
				delay(2500);
				
				navigateToItemDetailPage();
				delay(3000);

				searchByItemInstance("{{Search_Item_Instance}}");
				
				processItemDetailUpdate();

				delay(3000);
				
				getScript("ItemOwnerAssignment").callFunction("itemAOROAssignment", "Accountable Officer", "{{AO_Assignee_Name}}");
				delay(3000);
				
				getScript("ItemOwnerAssignment").callFunction("itemAOROAssignment", "Responsible Officer", "{{RO_Assignee_Name}}");
				delay(3000);
				
				closeBrowserGCSSMC();
				delay(2500);
				
			} // beginStep("process AO/RO Assignment processAOROAssignmentByInstanceNumber()")
			endStep();
			
		}
		catch (Exception e)
		{
			info("processAOROAssignmentByInstanceNumber () : " + e.getMessage());
			throw e;
		}
	}  // public void processAOROAssignmentByInstanceNumber()

	/*
	 * Assumes it is already on the Item Search page
	 * search using the Serial Number
	 * Process AO Assignment followed by RO Assignment
	*/
	public void processAOROAssignmentBySerialNumber() throws Exception {
		try
		{
			beginStep("process AO/RO Assignment processAOROAssignmentByInstanceNumber()");
			{
				openBrowserGCSSMC();
				delay(2500);

				navigateToItemDetailPage();
				delay(3000);
				
				searchBySerialNumber("{{Search_Serial_Number}}");
				
				processItemDetailUpdate();

				delay(3000);
				
				getScript("ItemOwnerAssignment").callFunction("itemAOROAssignment", "Accountable Officer", "{{AO_Assignee_Name}}");
				delay(3000);
				
				getScript("ItemOwnerAssignment").callFunction("itemAOROAssignment", "Responsible Officer", "{{RO_Assignee_Name}}");
				delay(3000);
				
				closeBrowserGCSSMC();
				delay(2500);
				
			} // beginStep("process AO/RO Assignment processAOROAssignmentBySerialNumber()")
			endStep();
			
		}
		catch (Exception e)
		{
			info("processAOROAssignmentBySerialNumber() : " + e.getMessage());
			throw e;
		}
	}  // public void processAOROAssignmentBySerialNumber()

	public void confirmMIAssociationExists() throws Exception {
		beginStep("Verify both MIs are associated");
		{
			try
			{
				openBrowserGCSSMC();
				delay(3000);
				
				navigateToItemDetailPage();
				
				searchByItemInstance("{{Search_Item_Instance}}");
				delay(4000);
				
				processItemDetailUpdate();
				delay(6000);

				Object PCNItemExists = getScript("ItemOwnerAssignment").callFunction("validatePCNExistsOnItem", "{{MI_ItemNumber}}");
				delay(3000);

				closeBrowserGCSSMC();
				delay(3000);
			
			}
			catch (Exception e)
			{
				info ("Verify both MIs are associated : " + getClass().getName() + " - " + e.getMessage());
				throw e;
			}
		} //beginStep("Verify both MIs are associated")
		endStep();
	} // public void confirmMIAssociationExists()
	
	public void searchByItemInstance(String PAR_Search_Item_Instance) throws Exception {
		beginStep("[6] Item Instance Search (/RF.jsp)", 0);
		{
			
			web.window(23,
					"/web:window[@index='0' or @title='Item Instance Search']")
					.waitForPage(10, true);
			{
				delay(3000);
			}

			web.textBox(
					26,
					"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='ProductNumberSch' or @name='ProductNumberSch' or @index='0']")
					.click();
			{
				delay(2000);
			}
			web.textBox(
					27,
					"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='ProductNumberSch' or @name='ProductNumberSch' or @index='0']")
					.setText(PAR_Search_Item_Instance);
			{
				delay(3000);
			}
			
			web.button(
					28,
					"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@index='3']")
					.click();
			delay(3000);
		}
		endStep();
		beginStep("Search by Item Instance Screen");
		{
			String screenshotFileName = "{{GLBL_Prefix_AORO_File_Name}}" + "_Search_by_Item_Instance";
			getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", screenshotFileName);
			delay(3000);
			screenshotFileName = null;
		}

	} // public void searchByItemInstance() throws Exception
	
	public void searchBySerialNumber(String PAR_Serial_Number) throws Exception
	{
		try
		{
			beginStep("Item Instance Search using Serial Number", 0);
			{
				/*
				web.window(2526,
						"/web:window[@index='0' or @title='Item Instance Search']")
						.waitForPage(null);
				{
					think(1.391);
				}
				*/
				web.textBox(
						2529,
						"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='SerialNumberSch' or @name='SerialNumberSch' or @index='5']")
						.click();
				{
					delay(2000);
				}
				
				web.textBox(
						2530,
						"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='SerialNumberSch' or @name='SerialNumberSch' or @index='5']")
						.setText(PAR_Serial_Number);
				{
					delay(4000);
				}

				web.button(
						2532,
						"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:button[@index='3']")
						.click();
				delay(3000);
			} // beginStep("Item Instance Search using Serial Number", 0)
			endStep();
			beginStep("Search by Serial Number Screen");
			{
				String screenshotFileName = "{{GLBL_Prefix_AORO_File_Name}}"+"_Search_by_Serial_Number";
				getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", screenshotFileName);
				delay(3000);
				screenshotFileName = null;
			}

		}
		catch(Exception e)
		{
			info("searchBySerialNumber() : " + e.getMessage());
			throw e;
		}
	}
	
	/*
	 * Method to click on the Item detail record Update / Edit icon at the right side of the specific row
	*/
	public void processItemDetailUpdate() throws Exception {
		try
		{
			beginStep(
				"[7] Item Instance Search (/InstanceSearchPG__QueryRN__542&_ti=1550982838&retainAM=N&addBreadCrumb=N&OAPB=_OAFMID&oapc=5&oas=lDP_OllKnbuXul1_NLGVKw..)",
				0);
			{
				web.window(1841,
					"/web:window[@index='0' or @title='Item Instance Search']")
					.waitForPage(null);
				{
					delay(2000);
				}
				web.image(
					1844,
					"/web:window[@index='0' or @title='Item Instance Search']/web:document[@index='0']/web:img[@alt='Update Item Instance' or @index='154' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_MEDIA/updateicon_enabled.gif']")
					.click();
				
				beginStep("Click on Item Detial");
				{
					String screenshotFileName = "{{GLBL_Prefix_AORO_File_Name}}" + "35_TC_01_Click_Item_Detail";
					getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", screenshotFileName);
				

					delay(6000);
					screenshotFileName = null;
				}

			}
			endStep();
			
		}
		catch (Exception e)
		{
			info ("processItemDetailUpdate()" + e.getMessage());
			throw e;
		}
	} // public void processItemDetailUpdate() 
	
}
