import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.webdom.api.elements.DOMBrowser;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		
		getVariables().set("GLBL_ServiceRequestNumber", "27635044",
				Variables.Scope.GLOBAL);
		
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
	//	getDatabank("debrief_material_db").getNextDatabankRecord();
		debriefProcess();
		
		
		
	} //public void run() throws Exception
	
	public void debriefProcess() throws Exception {
				
		userNavigation();
		runDebriefProcess();
		saveDebrief();
		captureCarcassSDN();
		captureReplacementSDN();
		closeEBS();
		browser.close();
		
	} //public void debriefProcess()
	
	public void userNavigation() throws Exception {
		
		getVariables().set("MyURL",
			"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		browser.launch();
		DOMBrowser myBrowser = web.window("/web:window[@index='0' or @index='1']");
		myBrowser.maximize();
		getScript("CACI_FunctLib_EBSFunctions").callFunction(
			"EBSCertificateLogin", "{{MyURL}}", "243");
			delay(3000);
		
		/*
		
		beginStep(
			"[1] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3DDhv8maFnlOdg0KOYHdhSZYn3yqJjfx68OOV%2FX3EnMc3FM9umZOs%2B2UTR3VyNPgXkf7KoiF3tKnB6Rx65c7kQLfO3Fn75ck9mQudRxVB9b7zGc1fAorKvCUHXNKR1jWHAlGRnYfSmQyDgIkh0JvHiZMsOs3FavXFsEuvBPZC9fwsSGQfpbajMvIkr (/obrareq.cgi)",
			0);
	{
		web.window(11, "/web:window[@index='0' or @title='about:blank']")
				.navigate(
						"{{MyURL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}");
		web.window(12,
				"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
				.waitForPage(null);
		{
			delay(8000);
		}
		web.button(
				13,
				"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
				.click();
	}
	endStep();
	
	
*/

	beginStep("[2] Select User Responsibility", 0);
	{
		//web.window(14, "/web:window[@index='0' or @title='Home']")
		//		.waitForPage(null);
		{
			delay(8000);
		}
		web.element(
				17,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Maintenance Chief' or @index='170']")
				.click();
	}
	endStep();
	beginStep("[3] Select User Role", 0);
	{
		web.window(18, "/web:window[@index='0' or @title='Home']")
				.waitForPage(null);
		{
			delay(8000);
		}
		web.element(
				21,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Request' or @index='190']")
				.click();
	}
	endStep();
	beginStep("[4] Select User Role - 2", 0);
	{
		web.window(22, "/web:window[@index='0' or @title='Home']")
				.waitForPage(null);
		{
			delay(8000);
		}
		web.element(
				25,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Requests' or @index='194']")
				.click();
	}
	endStep();
	beginStep("[5] Select User Role - 3", 0);
	{
		web.window(26, "/web:window[@index='0' or @title='Home']")
				.waitForPage(null);
		{
			delay(8000);
		}
		web.element(
				29,
				"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Find Service Requests' or @index='196']")
				.click();
	}
	endStep();
		
		
		
	} //public void userNavigation() throws Exception
	
	
	public void runDebriefProcess() throws Exception {
		
		
		
		//find service request
		
		beginStep("[6] Find Service Requests", 0);
		{
			
			forms.textField(24,
					"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_NUMBER_0')]")
					.setText("{{GLBL_ServiceRequestNumber,27635036}}");
			{
				delay(2000);
			}
			
						
			forms.button(25, "//forms:button[(@name='CS_FIND_MAIN_SEARCH_0')]")
					.click();
			{
				delay(2000);
			}
			forms.spreadTable(26,
					"//forms:spreadTable[(@name='CS_FIND_GRID_ITEM_GRID_0')]")
					.focusRow(1);
			{
				delay(2000);
			}
			forms.spreadTable(27,
					"//forms:spreadTable[(@name='CS_FIND_GRID_ITEM_GRID_0')]")
					.setFocus();
		}
		endStep();
		beginStep(
				"[7] Service Request ( 27635032 - Create Maintenance SR ) . Eastern Time",
				0);
		{
			
			forms.tab(30, "//forms:tab[(@name='SR_CANVASES')]").select("Tasks");
			{
				delay(2000);
			}
			forms.spreadTable(31,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			{
				delay(2000);
			}
			forms.spreadTable(32,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			{
				delay(2000);
			}
			forms.spreadTable(33,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.setFocus();
			{
				delay(2000);
			}
			forms.button(34, "//forms:button[(@name='CREATE_TASK_DEBRIEF_0')]")
					.click();
		}
		endStep();
		
		
		
		// select Material Tab
		
		beginStep("[8] GCSS-MC Debrief ", 0);
		{
			forms.captureScreenshot(36);
			{
				delay(2000);
			}
			forms.spreadTable(37,
					"//forms:spreadTable[(@name='MASTER_GRID_0')]").focusRow(1);
			{
				delay(2000);
			}
			forms.window(38, "//forms:window[(@name='MAIN_WINDOW')]").activate(
					true);
			{
				delay(2000);
			}
			forms.tab(39, "//forms:tab[(@name='DEBRIEF_LINES')]").select(
					"Material");
			{
				delay(2000);
			}
			
			
		// input debrief NIIN and other information
			
		//getDatabank("MAIN_TC_09_Parts_Data").getNextDatabankRecord();
			
			//Datafile recordcount
			int recordCount = getDatabank("debrief_material_db").getDatabankRecordCount();
			int partsRowCount = 0; //variable used to traverse through Parts Requirements table
			
			
			for (int i=1; i<=recordCount; i++)
			{
				//input data record increment
				getDatabank("debrief_material_db").getRecord(i);
				
				
				////forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE5_"+ partsRowCount +"')]")
		
			forms.textField(41,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_NUMBER_"+ partsRowCount +"')]")
					.setText("{{db.debrief_material_db.NIIN,014661855}}");
			{
				delay(5000);
			}
			forms.textField(42,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_UOM_CODE_"+ partsRowCount +"')]")
					.setFocus();
			{
				delay(5000);
			}
			forms.textField(43,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_QUANTITY_"+ partsRowCount +"')]")
					.setText("{{db.debrief_material_db.Quantity,1}}");
			{
				delay(5000);
			}
			forms.textField(44,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORG_"+ partsRowCount +"')]")
					.setText("{{db.debrief_material_db.Organization,1CJ}}");
			{
				delay(5000);
			}
			forms.textField(
					45,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+ partsRowCount +"')]")
					.setFocus();
			{
				delay(5000);
			}
			{
				forms.textField(
					45,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_SUB_INVENTORY_CODE_"+ partsRowCount +"')]")
					.setText("{{db.debrief_material_db.Subinventory,01F}}");
			}
			forms.textField(46,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+ partsRowCount +"')]")
					.setFocus();
			{
				delay(5000);
			}
			{
				forms.textField(46,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_LOCATOR_DISP_"+ partsRowCount +"')]")
					.setText("{{db.debrief_material_db.Locator,C000001AF}}");
			}
			{
				delay(5000);
			}
			
			/*
			 * Serial Number Generation
			 * Variable Set for MIN / MAX
			 */
			
			getVariables().set("min", "00000001");
			getVariables().set("max", "99999999");
			getVariables().set("random", "{{@random({{min}},{{max}})}}");
			info("random = {{random}}");
			
			/*
			 * Variable Set for Serial Number Generation End
			 */
			
			forms.textField(
					47,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+ partsRowCount +"')]")
					.setText("{{@random({{min}},{{max}}),0102030405}}");	
			{
				delay(5000);
			}
			{
				forms.textField(
					47,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+ partsRowCount +"')]")
					.storeAttribute("NIIN_Serial_Number", "text");
					info("NIIN Serial Number is {{NIIN_Serial_Number}}");
			}
			
			//} // if ("//forms:textField[(@name='CSP_REQUIREMENT_LINES_ATTRIBUTE5_"+ partsRowCount +"')]").isEmpty()
			
			partsRowCount = partsRowCount + 1;
			
			//below validation to check if we need to create another row on the screen.  The increment has to be done before, because the table starts with "0" and the DataBank record starts with "1"
			if (partsRowCount != recordCount)
			{
				forms.textField(
					47,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ITEM_SERIAL_NUMBER_"+ partsRowCount +"')]")
					.invokeSoftKey("DOWN");	
				{
					delay(3000);
				}
		}
			
			
		}
	}
		
	} //public void runDebriefProcess() throws Exception
	
	
			public void saveDebrief() throws Exception {
				
				
				// save record(s)
				
				
				forms.window(49, "//forms:window[(@name='MAIN_WINDOW')]")
						.clickToolBarButton("Save");
				{
					delay(4000);
				}
				
				
				
			} //public void saveDebrief() throws Exception
			
			public void captureCarcassSDN() throws Exception {
			
			
			forms.textField(76,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_0')]")
					.setFocus();
			{
				delay(1000);
			}
			{
				forms.textField(76,
				"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_0')]")
				.storeAttribute("GLBL_Carcass_1", "text");
				info("Carcass SDN 1 is {{GLBL_Carcass_1}}");
			}
							
			forms.textField(77,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_1')]")
					.click();
			{
				delay(1000);
			}
			{
				forms.textField(77,
				"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_RIP_RETURN_SDN_1')]")
				.storeAttribute("GLBL_Carcass_2", "text");
				info("Carcass SDN 2 is {{GLBL_Carcass_2}}");
			}
							
			
	} //public void captureCarcassSDN() throws Exception
			
			public void captureReplacementSDN() throws Exception {
	
			forms.textField(78,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORDER_SDN_0')]")
					.click();
			{
				delay(1000);
			}
			{
				forms.textField(78,
				"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORDER_SDN_0')]")
				.storeAttribute("GLBL_Replacement_1", "text");
				info("Replacement SDN 1 is {{GLBL_Replacement_1}}");
			}
							
			forms.textField(79,
					"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORDER_SDN_1')]")
					.click();
			{
				forms.textField(79,
				"//forms:textField[(@name='CSF_DEBRIEF_MATERIAL_LINES_NEW_ORDER_SDN_1')]")
				.storeAttribute("GLBL_Replacement_2", "text");
				info("Replacement SDN 2 is {{GLBL_Replacement_2}}");
			}
							
			
			
	} //public void captureReplacementSDN() throws Exception
			
			
			
			
			public void closeEBS() throws Exception {
			
			
			{
				delay(4000);
			}
			/*
			forms.window(80, "//forms:window[(@name='MAIN_WINDOW')]").close();
			{
				delay(4000);
			}
			forms.window(81, "//forms:window[(@name='MAIN_WINDOW')]").activate(
					true);
			{
				delay(2000);
			}
			forms.alertDialog(82, "//forms:alertDialog").clickYes();
		
		endStep();
		beginStep("[11] Forms", 0);
		{
			forms.captureScreenshot(84);
			{
				delay(3000);
			}
			forms.window(85, "//forms:window[(@name='MAIN_WINDOW')]").activate(
					true);
		}
		endStep();
		beginStep("[12] GCSS-MC Debrief ", 0);
		{
			forms.captureScreenshot(87);
			{
				delay(4000);
			}
			forms.alertDialog(88, "//forms:alertDialog").clickYes();
		}
		endStep();
		beginStep("[13] Forms", 0);
		{
			forms.captureScreenshot(90);
			{
				delay(4000);
			}
			forms.window(91,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
		}
		endStep();
		
		*/
			
		beginStep(
				"[14] Service Request ( 27635032 - Create Maintenance SR ) . Eastern Time",
				0);
				
	
		{
			forms.captureScreenshot(93);
			{
				delay(4000);
			}
			forms.window(94,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.selectMenu("File|Exit Oracle Applications");
		}
		endStep();
		beginStep("[15] Caution", 0);
		{
			forms.captureScreenshot(96);
			{
				delay(4000);
			}
			forms.choiceBox(97, "//forms:choiceBox").clickButton("OK");
			{
				delay(4000);
			}
			web.image(
					98,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:img[@alt='Logout' or @index='12' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_MEDIA/signout.png']")
					.click();
		}
		endStep();

	
			
	} //public void closeEBS() throws Exception

	public void finish() throws Exception { 
		
	} //public void finish() throws Exception
	
}
