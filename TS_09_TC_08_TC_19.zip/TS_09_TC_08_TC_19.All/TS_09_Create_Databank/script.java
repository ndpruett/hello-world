import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;

import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;



import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Paths;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		getVariables().set("DataBankName", "part_document_record_{{@timestamp}}.csv",
				Variables.Scope.GLOBAL);
		getVariables().set("DataBaseLocation",
				"C:\\\\OracleATS\\\\OFT\\\\Databank", Variables.Scope.GLOBAL);
		getVariables().set("HeaderString", "NIIN,SDN",
				Variables.Scope.GLOBAL);
		getVariables().set("DataLine",
				"NIIN,1234567878",
				Variables.Scope.GLOBAL);
		callFunction("CreatDataBank", "{{DataBaseLocation}}",
				"{{DataBankName}}", "{{HeaderString}}");
		for (int i = 0; i < 10; i++) {
			;
			callFunction("CreateNewRecordLine", "{{DataBaseLocation}}",
					"{{DataBankName}}", "{{DataLine}}");
		}
		

	}

	/**
	 * 
	 * 
	 * @param DataBankPath 
	 * @param FileName 
	 * @param DataString 
	 */
	public void CreateNewRecordLine(@Arg("DataBankPath")
	String DataBankPath, @Arg("FileName")
	String FileName, @Arg("DataString")
	String DataString)
		throws Exception {
		
		BufferedWriter out = null;
		FileWriter fstream = new FileWriter(DataBankPath+"\\"+FileName, true); //true tells to append data.
		    out = new BufferedWriter(fstream);
		    out.write(DataString+"\n");
		    out.close();
		
	
		
		
		
		
		
	}

	/**
	 * 
	 * 
	 * @param DataBankPath 
	 * @param FileName 
	 * @param HeaderString 
	 */
	public void CreatDataBank(@Arg("DataBankLocation")
			String DataBankLocation, @Arg("FileName")
			String FileName, @Arg("HeaderString")
			String HeaderString) throws Exception {
		beginStep("Initialize Transaction", 0);
		{
			String DataBankPath;
			DataBankPath = DataBankLocation;
			File newFile = new File(DataBankPath);
			if(!newFile.isDirectory()){

					Files.createDirectory(Paths.get(DataBankPath));

			}
			File file = new File(DataBankPath+"\\"+FileName);
			boolean success = file.delete();
			Writer output = new BufferedWriter(new FileWriter(file,true));
			output.write(HeaderString+"\n");
			output.close();
		}
		endStep();
	}

	public void finish() throws Exception {
	}
}
