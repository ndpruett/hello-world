import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		browser.launch();
		getVariables().set("MyUser", "236", Variables.Scope.GLOBAL);
		getVariables().set("MyURL",
				"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
				Variables.Scope.GLOBAL);
		getScript("CACI_FunctLib_EBSFunctions").callFunction(
				"EBSCertificateLogin", "{{MyURL}}", "{{MyUser}}");
		beginStep("[2] Home (/OA.jsp)", 0);
		{
			web.window(6, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null, true);
			{
				think(4.181);
			}
			web.element(
					9,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Maintenance Chief' or @index='58']")
					.click();
		}
		endStep();
		beginStep("[3] Home (/OA.jsp)", 0);
		{
			web.window(10, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				think(5.109);
			}
			web.element(
					13,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Request' or @index='78']")
					.click();
		}
		endStep();
		beginStep("[4] Home (/OA.jsp)", 0);
		{
			web.window(14, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				think(6.088);
			}
			web.element(
					17,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Service Requests' or @index='82']")
					.click();
		}
		endStep();
		beginStep("[5] Home (/OA.jsp)", 0);
		{
			web.window(18, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				think(3.78);
			}
			web.element(
					21,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Find Service Requests' or @index='86']")
					.click();
		}
		endStep();
		beginStep("[6] Find Service Requests", 0);
		{
			forms.captureScreenshot(23);
			{
				think(65.171);
			}
			delay(10000);
			
			forms.window(24, "//forms:window[(@name='CS_FIND_MAIN')]").close();
			{
				think(1.269);
			}
			forms.window(25, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
		}
		endStep();
		beginStep("[7] Navigator - GCSS-MC Maintenance Chief", 0);
		{
			forms.captureScreenshot(27);
		}
		endStep();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		beginStep("[1] Initialize Test Case", 0);
		{
			getVariables().set("SRNumber", "{{GLBL_ServiceRequestNumber}}", Variables.Scope.GLOBAL);
		}
		endStep();
		beginStep("[2] Responsibilities (Working...)", 0);
		{
			forms.captureScreenshot(30);
			{
				think(20.093);
			}
			forms.window(28, "//forms:window[(@name='NAVIGATOR')]")
					.clickToolBarButton("Switch Responsibility...");
			think(23.763);
			forms.captureScreenshot(30);
			{
				think(20.093);
			}
			forms.listOfValues(31, "//forms:listOfValues").find(
					"%Maintenance Chief%");
			{
				think(4.098);
			}
			forms.window(32, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
		}
		endStep();
		beginStep("[3] Navigator - GCSS-MC Maintenance Chief", 0);
		{
			forms.captureScreenshot(34);
			{
				think(0.208);
			}
			forms.listOfValues(35, "//forms:listOfValues").select(
					"GCSS-MC Maintenance Chief");
		}
		endStep();
		beginStep("[4] Responsibilities", 0);
		{
			forms.captureScreenshot(37);
			{
				think(29.954);
			}
		}
		endStep();
		beginStep("[5] Navigator - GCSS-MC Maintenance Chief", 0);
		{
			forms.captureScreenshot(63);
			{
				think(0.139);
			}
			forms.treeList(64, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem("Service Request");
			{
				think(0.727);
			}
			forms.button(65, "//forms:button[(@name='NAV_CONTROLS_EXPAND_0')]")
					.click();
			{
				think(2.059);
				think(0.002);
			}
			forms.treeList(88, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem("Service Request|Service Requests");
			{
				think(1.111);
			}
			forms.button(89, "//forms:button[(@name='NAV_CONTROLS_EXPAND_0')]")
					.click();
			{
				think(1.768);
				think(0.003);
			}
			forms.treeList(112, "//forms:treeList[(@name='NAVIGATOR_LIST_0')]")
					.focusItem(
							"Service Request|Service Requests|Find Service Requests");
			{
				think(1.896);
			}
			forms.button(113, "//forms:button[(@name='NAV_CONTROLS_OPEN_0')]")
					.click();
		}
		endStep();
		beginStep("[6] Find Service Requests", 0);
		{
			forms.captureScreenshot(115);
			{
				think(25.462);
			}
			forms.textField(116,
					"//forms:textField[(@name='SR_BSC_QUERY_INCIDENT_NUMBER_0')]")
					.setText("{{SRNumber,27632150}}");
			{
				think(1.605);
			}
			forms.button(117, "//forms:button[(@name='CS_FIND_MAIN_SEARCH_0')]")
					.click();
			{
				think(0.108);
			}
			forms.spreadTable(118,
					"//forms:spreadTable[(@name='CS_FIND_GRID_ITEM_GRID_0')]")
					.focusRow(1);
			{
				think(49.138);
			}
			forms.spreadTable(119,
					"//forms:spreadTable[(@name='CS_FIND_GRID_ITEM_GRID_0')]")
					.setFocus();
		}
		endStep();
		beginStep(
				"[7] Service Request ({{SRNumber, 27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(121);
			{
				think(0.45);
			}
			forms.tab(122, "//forms:tab[(@name='SR_CANVASES')]")
					.select("Tasks");
			{
				think(2.375);
			}
			forms.spreadTable(123,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			{
				think(0.284);
			}
			forms.spreadTable(124,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			{
				think(10.462);
			}
			forms.textField(125,
					"//forms:textField[(@name='CREATE_TASK_DESC_FLEX_0')]")
					.setFocus();
		}
		endStep();
		beginStep("[8] Tasks additional information", 0);
		{
			forms.captureScreenshot(127);
			{
				think(0.115);
			}
			forms.flexWindow(128, "//forms:flexWindow").openDialog(
					"Operational Status", "");
			{
				think(4.264);
			}
			forms.listOfValues(129, "//forms:listOfValues").select(
					"Operational - Minor|Minor (Mission capable)");
		}
		endStep();
		beginStep("[9] Operational Status", 0);
		{
			forms.captureScreenshot(131);
			{
				think(11.663);
			}
			forms.flexWindow(132, "//forms:flexWindow").clickOk();
		}
		endStep();
		beginStep(
				"[10] Service Request ( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(134);
			{
				think(8.041);
			}
			forms.window(135,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
		}
		endStep();
		beginStep("[11] Note", 0);
		{
			forms.captureScreenshot(137);
			{
				think(5.084);
			}
			if (false) {
				forms.choiceBox(138, "//forms:choiceBox").clickButton("OK");
				{
					think(3.957);
				}
			}
		}
		endStep();
		beginStep(
				"[12] Service Request ( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(141);
			{
				think(24.88);
			}
			forms.textField(142,
					"//forms:textField[(@name='CREATE_TASK_TASK_STATUS_0')]")
					.openDialog();
			{
				think(5.061);
			}
			forms.window(143,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
			{
				think(0.502);
			}
			forms.listOfValues(144, "//forms:listOfValues")
					.select("Assigned|Tasks is assigned to resource(s). The schedule is optimized and can be communicated to the resources in the field");
		}
		endStep();
		beginStep("[13] Task Statuses", 0);
		{
			forms.captureScreenshot(146);
			{
				think(4.614);
			}
			forms.window(147,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			{
				think(0.946);
			}
			forms.statusBar(148, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 1 records applied and saved.", MatchOption.Exact, 0);
			{
				think(26.968);
			}
			forms.textField(149,
					"//forms:textField[(@name='CREATE_TASK_TASK_STATUS_0')]")
					.openDialog();
			{
				think(25.815);
			}
			forms.window(150,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
			{
				think(0.536);
			}
			forms.listOfValues(151, "//forms:listOfValues").select(
					"Completed|Task is done and frozen");
		}
		endStep();
		beginStep("[14] Task Statuses", 0);
		{
			forms.captureScreenshot(153);
			{
				think(5.514);
			}
			forms.window(154,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			{
				think(1.453);
			}
			forms.statusBar(155, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 1 records applied and saved.", MatchOption.Exact, 0);
			{
				think(6.618);
			}
			forms.spreadTable(156,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(2);
			{
				think(25.902);
			}
			forms.textField(157,
					"//forms:textField[(@name='CREATE_TASK_DESC_FLEX_0')]")
					.setFocus();
		}
		endStep();
		beginStep("[15] Tasks additional information", 0);
		{
			forms.captureScreenshot(159);
			{
				think(0.139);
			}
			forms.flexWindow(160, "//forms:flexWindow").openDialog(
					"Operational Status", "");
			{
				think(5.822);
			}
			forms.listOfValues(161, "//forms:listOfValues").select(
					"Operational - Minor|Minor (Mission capable)");
		}
		endStep();
		beginStep("[16] Operational Status", 0);
		{
			forms.captureScreenshot(163);
			{
				think(12.797);
			}
			forms.flexWindow(164, "//forms:flexWindow").clickOk();
		}
		endStep();
		beginStep(
				"[17] Service Request ( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(166);
			{
				think(5.142);
			}
			forms.window(167,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
		}
		endStep();
		beginStep("[18] Note", 0);
		{
			forms.captureScreenshot(169);
			{
				think(3.812);
			}
			forms.choiceBox(170, "//forms:choiceBox").clickButton("OK");
			{
				think(2.664);
			}
			forms.statusBar(171, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 2 records applied and saved.", MatchOption.Exact, 0);
		}
		endStep();
		beginStep(
				"[19] Service Request( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(173);
			{
				think(27.314);
			}
			forms.window(174,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			{
				think(0.448);
			}
			forms.statusBar(175, "//forms:statusBar").verifyText(
					"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40401: No changes to save.", MatchOption.Exact, 0);
			{
				think(7.179);
			}
			forms.textField(176,
					"//forms:textField[(@name='CREATE_TASK_TASK_STATUS_0')]")
					.openDialog();
			{
				think(3.453);
			}
			forms.window(177,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
			{
				think(0.768);
			}
			forms.listOfValues(178, "//forms:listOfValues")
					.select("Assigned|Tasks is assigned to resource(s). The schedule is optimized and can be communicated to the resources in the field");
		}
		endStep();
		beginStep("[20] Task Statuses", 0);
		{
			forms.captureScreenshot(180);
			{
				think(4.73);
			}
			forms.window(181,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			{
				think(1.577);
			}
			forms.statusBar(182, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 1 records applied and saved.", MatchOption.Exact, 0);
			{
				think(8.93);
			}
			forms.textField(183,
					"//forms:textField[(@name='CREATE_TASK_TASK_STATUS_0')]")
					.openDialog();
			{
				think(6.826);
			}
			forms.window(184,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
			{
				think(0.654);
			}
			forms.listOfValues(185, "//forms:listOfValues").select(
					"Completed|Task is done and frozen");
		}
		endStep();
		beginStep("[21] Task Statuses", 0);
		{
			forms.captureScreenshot(187);
			{
				think(5.326);
			}
			forms.window(188,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			{
				think(0.955);
			}
			forms.statusBar(189, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 1 records applied and saved.", MatchOption.Exact, 0);
			{
				think(10.068);
			}
			forms.tab(190, "//forms:tab[(@name='SR_CANVASES')]").select(
					"Workbench");
			{
				think(3.798);
			}
			forms.textField(
					"//forms:textField[(@name='INCIDENT_TRACKING_URGENCY_0')]")
					.storeAttribute("WorkBenchOperationalStatus", "text");
			{
				think(106.52);
			}
			forms.textField(
					"//forms:textField[(@name='INCIDENT_TRACKING_REFERENCE_NUMBER_0')]")
					.storeAttribute("InstanceNumber", "text");
			if (false) {
				forms.spreadTable(191,
						"//forms:spreadTable[(@name='WKB_GRID_CONTROL_RESOLUTION_HISTORY_0')]")
						.focusRow(1);
				{
					think(27.44);
				}
			}
			forms.textField(192,
					"//forms:textField[(@name='INCIDENT_TRACKING_URGENCY_0')]")
					.openDialog();
			{
				think(7.786);
			}
			if (false) {
				forms.window(193,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.activate(true);
				{
					think(0.456);
				}
			}
			forms.listOfValues(194, "//forms:listOfValues").select(
					"Operational - Minor|63|Mission Capable");
		}
		endStep();
		beginStep("[22] Request Urgencies", 0);
		{
			forms.captureScreenshot(196);
			{
				think(22.065);
			}
			forms.window(197,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			{
				think(1.118);
			}
			forms.statusBar(198, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 1 records applied and saved.", MatchOption.Exact, 0);
			{
				think(14.509);
			}
			forms.tab(199, "//forms:tab[(@name='SR_CANVASES')]")
					.select("Tasks");
			{
				think(3.938);
			}
			forms.spreadTable(200,
					"//forms:spreadTable[(@name='SR_TASK_GRID_GRID_ITEM_0')]")
					.focusRow(1);
			{
				think(32.29);
			}
			forms.button(201,
					"//forms:button[(@name='CREATE_TASK_ADD_TASK_NOTES_0')]")
					.click();
			{
				think(0.79);
			}
			forms.tab(202, "//forms:tab[(@name='SR_CANVASES')]").select(
					"Subject");
			{
				think(39.369);
			}
			forms.textField(203,
					"//forms:textField[(@name='INCIDENT_TRACKING_STATUS_CODE_0')]")
					.openDialog();
		}
		endStep();
		beginStep("[23] Request Statuses (Working...)", 0);
		{
			forms.captureScreenshot(205);
			{
				think(17.75);
			}
			forms.listOfValues(206, "//forms:listOfValues").find("%Closed");
			{
				think(6.923);
			}
			forms.listOfValues(207, "//forms:listOfValues").select(
					"Closed|*|*|*|Closed");
		}
		endStep();
		beginStep(
				"[24] Service Request ( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(209);
			{
				think(9.992);
			}
			forms.window(210,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.clickToolBarButton("Save");
			forms.captureScreenshot(211);
			{
				think(68.592);
			}
			forms.choiceBox(212, "//forms:choiceBox").clickButton("OK");
		}
		endStep();
		beginStep("[25] Note", 0);
		{
			forms.captureScreenshot(214);
			{
				think(12.051);
			}
			forms.choiceBox(215, "//forms:choiceBox").clickButton("OK");
			{
				think(3.214);
			}
			forms.statusBar(216, "//forms:statusBar")
					.verifyText(
							"FormsFT AutoValidation: Verify StatusBar text value", "FRM-40400: Transaction complete: 1 records applied and saved.", MatchOption.Exact, 0);
			forms.button(1684,
					"//forms:button[(@name='INCIDENT_TRACKING_PRODUCT_DETAIL_0')]")
					.click();
		}
		endStep();
		if (false) {
			beginStep(
					"[26] Service Request ( 27632146 - Create Maintenance SR ) . Eastern Time",
					0);
			{
				forms.captureScreenshot(218);
				{
					think(23.577);
				}
				forms.button(219,
						"//forms:button[(@name='INCIDENT_TRACKING_PRODUCT_DETAIL_0')]")
						.click();
				{
					think(388.734);
				}
				forms.window(220,
						"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
						.close();
			}
			endStep();
		}
		if (false) {
			beginStep(
					"[26] Service Request ( 27632144 - Create Maintenance SR ) . Eastern Time",
					0);
			{
				forms.captureScreenshot(1671);
				{
					think(82.517);
				}
				forms.textField(1672,
						"//forms:textField[(@name='CREATE_TASK_TASK_STATUS_0')]")
						.openDialog();
				{
					think(0.025);
				}
				forms.listOfValues(1673, "//forms:listOfValues").find("Assigned%");
			}
			endStep();
		}
		if (false) {
			beginStep("[27] Task Statuses", 0);
			{
				forms.captureScreenshot(1675);
				{
					think(0.688);
				}
				forms.listOfValues(1676, "//forms:listOfValues").find("%");
				{
					think(0.013);
				}
				forms.listOfValues(1677, "//forms:listOfValues").select(
						"Completed|Task is done and frozen");
			}
			endStep();
		}
		if (false) {
			beginStep(
					"[28] Service Request ( 27632144 - Create Maintenance SR ) . Eastern Time",
					0);
			{
				forms.captureScreenshot(1679);
				{
					think(0.365);
				}
				if (false) {
					forms.textField(1680,
							"//forms:textField[(@name='CREATE_TASK_TASK_PRIORITY_0')]")
							.setFocus();
					{
						think(0.011);
					}
				}
				if (false) {
					forms.tab(1681, "//forms:tab[(@name='SR_CANVASES')]").select(
							"Workbench");
					{
						think(2.401);
					}
				}
				forms.spreadTable(1682,
						"//forms:spreadTable[(@name='WKB_GRID_CONTROL_RESOLUTION_HISTORY_0')]")
						.focusRow(1);
				{
					think(9.639);
				}
				forms.tab(1683, "//forms:tab[(@name='SR_CANVASES')]").select(
						"Subject");
				{
					think(16.043);
				}
				forms.button(1684,
						"//forms:button[(@name='INCIDENT_TRACKING_PRODUCT_DETAIL_0')]")
						.click();
			}
			endStep();
		}
		beginStep("[29] Item Instance Details (/RF.jsp)", 0);
		{
			web.window(1685,
					"/web:window[@index='1' or @title='Item Instance Details']")
					.waitForPage(null);
			{
				think(0.023);
			}
			web.link(
					1688,
					"/web:window[@index='1' or @title='Item Instance Details']/web:document[@index='0']/web:a[@text='Show Instance Flex Fields' or @href='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/RF.jsp?function_id=19544&resp_id=50463&resp_appl_id=512&security_group_id=0&lang_code=US&params=zCL0bJLJvTrQrRppJRw9RBIu4k41-vp0BemZulTSA1MsnMDnj9m282sD634TY2jf&oas=bf1SPqLRZRauPLAbU3tmGg..#' or @index='27']")
					.click();
		}
		endStep();
		beginStep(
				"[30] Item Instance Details (/InstanceDetailsPG&_ti=1763889186&language_code=US&InstanceId=20457620&CallFromForm='Y'&oapc=4&oas=NDbTkONrQBW5XSpDt0JlRg..)",
				0);
		{
			web.window(1689,
					"/web:window[@index='1' or @title='Item Instance Details']")
					.waitForPage(null);
			{
				think(11.776);
			}
			web.textBox(
					1643,
					"/web:window[@index='1' or @title='Item Instance Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='InstDff0' or @name='InstDff0' or @index='7']")
					.assertAttributes(
							"ValidateOperationalStatus",
							web.attributes(web.attribute("value",
									"{{WorkBenchOperationalStatus,Deadlined}}",
									TestOperator.StringExact)));
			web.textBox(
					1692,
					"/web:window[@index='1' or @title='Item Instance Details']/web:document[@index='0']/web:form[@id='DefaultFormName' or @name='DefaultFormName' or @index='0']/web:input_text[@id='InstDff0' or @name='InstDff0' or @index='7']")
					.click();
			{
				think(18.805);
			}
			web.window(1693,
					"/web:window[@index='1' or @title='Item Instance Details']")
					.close();
			{
				think(63.711);
			}
			forms.window(1694,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.selectMenu("Tools2|Transfer of Custody Report");
		}
		endStep();
		beginStep("[31] Parameters", 0);
		{
			forms.captureScreenshot(1696);
			{
				think(28.358);
			}
			forms.flexWindow(1697, "//forms:flexWindow").clickOk();
		}
		endStep();
		beginStep("[32] Submit Request", 0);
		{
			forms.captureScreenshot(1699);
			{
				think(9.394);
			}
			forms.button(1700, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
					.click();
			{
				think(0.422);
			}
			forms.statusBar(1701, "//forms:statusBar")
					.assertText(
							"FormsFT AutoValidation: Verify StatusBar text value",
							"FRM-40400: Transaction complete: 1 records applied and saved.",
							MatchOption.Exact, 0);
		}
		endStep();
		beginStep("[33] Decision", 0);
		{
			forms.captureScreenshot(1703);
			
			
			delay(3000);
			

			String message = forms.choiceBox(55, "//forms:choiceBox").getAlertMessage();

			/* Copy the entire alert message into the string variable ReqID */

			String ReqID = message;

			/* Find the starting position of the Request ID in the alert message */
			/* This will return the # of characters from the beginning of the string */

			Integer startpos = message.indexOf("Request ID" );

			/* we then find the position of the ) in the alert message */
			/* we know we want the position of the character that appears */
			/* after the Request ID phrase so we use that as the start position */

			Integer endpos = ReqID.indexOf(")" ,(startpos+6));

			/* The startpos and endpos variables form a right and left hand boundary */
			/* we now store the substring value between those boundaries in the */
			/* “thesub” variable */

			String thesub = ReqID.substring(startpos+12, endpos);

			/* we now define an OpenScript “SetVariable” so that our value */
			/* can be used in any subsequent step in the script */

			getVariables().set("RequestID" , thesub, Variables.Scope.GLOBAL);
			
			delay(3000);
			
			
			
			
			
			
			
			{
				think(10.161);
			}
			forms.choiceBox(1704, "//forms:choiceBox").clickButton("No");
			{
				think(5.317);
			}
			forms.window(1705,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
		}
		endStep();
		beginStep(
				"[34] Service Request ( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(1707);
			{
				think(10.323);
			}
			forms.window(1708,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.selectMenu("View|Requests");
		}
		endStep();
		beginStep("[35] Find Requests", 0);
		{
			forms.captureScreenshot(1710);
			{
				think(30.826);
			}
			forms.radioButton(1711,
					"//forms:radioButton[(@name='JOBS_QF_WHICH_JOBS_SPECIFIC_JOBS_0')]")
					.select();
			{
				think(8.849);
			}
			forms.textField(1712,
					"//forms:textField[(@name='JOBS_QF_REQUEST_ID_0')]")
					.setText("sdfsdfsfdfsd");
			{
				think(1.674);
			}
			forms.button(1721, "//forms:button[(@name='JOBS_QF_FIND_0')]")
					.click();
			{
				think(6.206);
			}
			forms.window(1722, "//forms:window[(@name='JOBS')]").activate(true);
		}
		endStep();
		beginStep("[36] View Current Requests", 0);
		{
			forms.captureScreenshot(1724);
			{
				think(11.088);
			}
			getScript("CACI_FunctLib_EBSFunctions").callFunction(
					"ProcessRequest");
			forms.button(1726, "//forms:button[(@name='JOBS_VIEW_REPORT_0')]")
					.click();
		}
		endStep();
		beginStep(
				"[37] View Transfer of Custody Document", 0);
		{
			web.window(
					1727,
					"/web:window[@index='1' or @title='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_CGI/FNDWRR.exe?temp_id=1071485762']")
					.waitForPage(null);
			{
				think(35.157);
				String MyString = web
						.document(
								"/web:window[@index='1' or @title='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_CGI/FNDWRR.exe?temp_id=1071485762']")
						.getHTML();
				
				
				getScript("CACI_FunctLib_EBSFunctions").callFunction(
						"FileWriter", MyString, "TransferofCustodyDocument");
			}
			
			
			
			web.window(
					1728,
					"/web:window[@index='1' or @title='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_CGI/FNDWRR.exe?temp_id=1071485762']")
					.close();
			{
				think(9.416);
			}
			forms.window(1729, "//forms:window[(@name='JOBS')]").close();
			{
				think(4.224);
			}
			forms.window(1730,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
		}
		endStep();
		beginStep(
				"[38] Service Request( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(1732);
			{
				think(20.691);
			}
			forms.window(1733,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.close();
			{
				think(16.709);
			}
			forms.window(1734,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
			{
				think(0.297);
			}
			forms.alertDialog(1735, "//forms:alertDialog").clickYes();
		}
		endStep();
		beginStep("[39] Forms", 0);
		{
			forms.captureScreenshot(1737);
			{
				think(6.423);
			}
			forms.window(1738,
					"//forms:window[(@name='FOLDER_INCIDENT_TRACKING')]")
					.activate(true);
		}
		endStep();
		beginStep(
				"[40] Service Request ( {{SRNumber,27632146}} - Create Maintenance SR ) . Eastern Time", 0);
		{
			forms.captureScreenshot(1740);
			{
				think(0.411);
			}
			forms.alertDialog(1741, "//forms:alertDialog").clickYes();
		}
		endStep();
		beginStep("[41] Forms", 0);
		{
			forms.captureScreenshot(1743);
			{
				think(1.217);
			}
			forms.window(1744, "//forms:window[(@name='NAVIGATOR')]").activate(
					true);
		}
		endStep();
		beginStep("[42] Navigator - GCSS-MC Maintenance Chief", 0);
		{
			forms.captureScreenshot(1746);
			{
				think(6.367);
			}
			forms.window(1747, "//forms:window[(@name='NAVIGATOR')]")
					.selectMenu("File|Exit Oracle Applications");
		}
		endStep();
		beginStep("[43] Caution", 0);
		{
			forms.captureScreenshot(1749);
			{
				think(38.96);
			}
			forms.choiceBox(1750, "//forms:choiceBox").clickButton("OK");
			{
				think(12.163);
			}
			web.link(
					1751,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:a[@href='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/OALogout.jsp?menu=Y' or @index='5']")
					.click();
		}
		endStep();
		beginStep(
				"[44] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3D%2BPzBldYlsCtge1HdyAMIZkrLel4ZGmFrP%2FksFJucrkyl2aqg2d0ktmauLBCdw3TzsAKwPFAiKmdSRI71%2FpEbngW9m5h7%2Fb52oiViMuH1nvToB864X33ZPo8hIoj0X1pIu%2FwLZcx9sxNOvzWPohmWqleIjAupeBFJ46Igf2zX3ZqCqastzr (/obrareq.cgi)",
				0);
		{
			web.window(1752,
					"/web:window[@index='0' or @title='Single Sign-Off']")
					.waitForPage(null);
		}
		endStep();

	}

	public void finish() throws Exception {
	}
}
