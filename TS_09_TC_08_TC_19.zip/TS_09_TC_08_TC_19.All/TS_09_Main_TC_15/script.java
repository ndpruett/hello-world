import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		
		browser.launch();

		
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		
		processMultipleSDNReceipt();
		
		
	}
	
	public void processMultipleSDNReceipt() throws Exception {
		

		
		
		
		userNavigation();
		delay(3000);
		getScript("EnterSDNReceipt").callFunction("selectInventoryOrganization", "1CJ%");
		delay(3000);
		
		//getDatabank("MAIN_TC_09_Parts_Data").getNextDatabankRecord();
		
		//Datafile recordcount
		
		int recordCount = getDatabank("enter_multiple_sdn_receipt_db").getDatabankRecordCount();
		int partsRowCount = 0; //variable used to traverse through Parts Requirements table
		
		
		for (int i=1; i<=recordCount; i++)
			
		{
			
			//input data record increment
			
			getDatabank("enter_multiple_sdn_receipt_db").getRecord(i);
			getVariables().set("SDN", "{{db.enter_multiple_sdn_receipt_db.sdn}}", Variables.Scope.LOCAL);
			getVariables().set("locator", "{{db.enter_multiple_sdn_receipt_db.locator}}", Variables.Scope.LOCAL);
			getVariables().set("organization", "{{db.enter_multiple_sdn_receipt_db.inventory_organization}}", Variables.Scope.LOCAL);
			getVariables().set("NIINType", "{{db.enter_multiple_sdn_receipt_db.inventory}}", Variables.Scope.LOCAL);
			getVariables().set("serialNumber", "", Variables.Scope.LOCAL);
			
			processSingleSDNReceipt("{{SDN}}", "{{locator}}", "{{organization}}", "{{NIINType}}",null);
			
		
		
		
		partsRowCount = partsRowCount + 1;
		

	
		}//for (int i=1; i<=recordCount; i++)
		
		beginStep("Enter Receipt Information and Serial Number");
		{
			forms.captureScreenshot(null);
			delay(4000);
			getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "False", "True", "02_Receipt_Information");
				delay(6000);
		}
		
		endStep();
		closeEBSBrowser();
		browser.close();
		/*
		getScript("EnterSDNReceipt").callFunction("setupScreenshotParameters",
				"0", "0", "1980", "1920");	
		*/
		
	}
	
	/**
	 * 
	 * 
	 * @param PAR_SDN 
	 * @param PAR_locator 
	 * @param PAR_organization 
	 * @param PAR_NIINType 
	 * @param PAR_serialNumber 
	 */
	public void processSingleSDNReceipt(@Arg("PAR_SDN")
	String PAR_SDN, @Arg("PAR_locator")
	String PAR_locator, @Arg("PAR_organization")
	String PAR_organization, @Arg("PAR_NIINType")
	String PAR_NIINType, @Arg("PAR_serialNumber")
	String PAR_serialNumber) throws Exception {
		
		try {
			
			delay(3000);
			getScript("EnterSDNReceipt").callFunction("EnterSDNNumberAndClickFindButton", PAR_SDN);
			delay(3000);
			getScript("EnterSDNReceipt").callFunction("clickOnEnterReceiptButton");

			getScript("EnterSDNReceipt").callFunction("enterSDNReceipt", "0",
					"{{SDN}}", "{{NIINType}}", "{{locator}}",
					"{{serialNumber}}", "imagetest");
			delay(3000);
			

			delay(3000);


			
		}
		catch(Exception e){
			info("processSingleSDNReceipt() : " +e.getMessage() );
			throw e;
		}//try
		
	}//private void processSingleSDNReceipt(String PAR_SDN, String PAR_locator, String PAR_organization, String PAR_NIINType, String PAR_manifestQuantity, String PAR_receiptQuantity, String PAR_serialNumber)
	
	private void userNavigation() throws Exception {
		
		getVariables().set("MyURL",
			"https://gcssmc-pt-ebs.int.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		
		getScript("CACI_FunctLib_EBSFunctions").callFunction(
			"EBSCertificateLogin", "{{MyURL}}", "238");
			delay(3000);
		
		/*
		

		beginStep("[2] This site isn’t secure (/AppsLogin)", 0);
		{
			web.window(9, "/web:window[@index='0' or @title='about:blank']")
					.navigate(
							"{{MyURL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}");
		//	web.window(10,
		//			"/web:window[@index='0' or @title='This site isn’t secure']")
		//			.waitForPage(null);
			{
				delay(4000);
			}
		}
		endStep();
		beginStep(
				"[3] https://gcssmc-dv-oam.dev.gcssmc.sde/oam/server/obrareq.cgi?encquery%3Dr3ska%2BsGPsbfS26JWCCUeCn8x1%2BAbFhGtnQALQyUXPpZvAo32RbPUE7nkAJzuB1r7ZBQWTcZikKInj%2Bxs6Iq6TNaZxb89g2m8QoJZMuAiRNtk8gcdBbOMoMwcs6jFoGoEXZ3NuISGb1iXDSlnA1OOhsGMZsi1%2BfWZvgYspS4ydwPyscGGItH (/obrareq.cgi)",
				0);
		{
			web.window(13,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					.waitForPage(null);
			{
				delay(4000);
			}
			web.button(
					14,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
					.click();
		}
		endStep();
		
		*/
		
		beginStep(
				"[4] Select User Responsibility", 0);
		{
		//	web.window(15, "/web:window[@index='0' or @title='Home']")
		//			.waitForPage(null);
			{
				delay(12000);
			}
			web.element(
					18,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='GCSS-MC Inventory / Supply Officer' or @index='62']")
					.click();
		}
		endStep();
		beginStep("[5] Select User Role", 0);
		{
			web.window(19, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(6000);
			}
			web.element(
					22,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Custom Forms' or @index='326']")
					.click();
		}
		endStep();
		beginStep("[6] Select User Role", 0);
		{
			web.window(23, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null);
			{
				delay(2000);
			}
			web.element(
					26,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='Document Management (Supply)' or @index='328']")
					.click();
			{
				delay(6000);
			}
		}
		
		endStep();

	}
	
private void closeEBSBrowser() throws Exception {
		
		beginStep("[6] Close EBS Forms", 0);
		{
			forms.window(24,
					"//forms:window")
					.selectMenu("File|Exit Oracle Applications");
		}
		endStep();
		beginStep("[7] Close Browser", 0);
		{
			forms.choiceBox(27, "//forms:choiceBox").clickButton("OK");
			{
				delay(13000);
			}
			web.image(
					28,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:img[@alt='Logout' or @index='14' or @src='https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_MEDIA/signout.png']")
					.click();
		}
		endStep();
	

		
	}//private void closeEBSBrowser() throws Exception
	

	public void finish() throws Exception {
	}
}
