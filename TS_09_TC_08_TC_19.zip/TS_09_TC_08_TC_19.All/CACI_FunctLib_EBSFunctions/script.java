import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.util.ArrayList;

import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.applet.api.*;
import oracle.oats.scripting.modules.image.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.formsFT.common.api.elements.List;
import java.awt.*;
import java.util.*;
import lib.*;
import java.io.File;
import java.io.FileOutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;


public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.image.api.ImageService img;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;
	public void initialize() throws Exception {
	}

	/**
	 * 
	 * @param PAR_NavigationString 
	 * @param delimiterPattern 
	 */
	public void SS_getEBSNavigationAndClickOnMenuItems(@Arg("PAR_NavigationString") String PAR_NavigationString,@Arg("delimiterPattern") String delimiterPattern) throws Exception{boolean isThereAComma=false;int menuItemCounter=0;String myNavigation=PAR_NavigationString;String charToSearch=delimiterPattern;ArrayList<String> menuItems=new ArrayList<String>();String repeatedString=null;boolean repeatedText=false;int repeatedCount=0;for (int i=0;i < myNavigation.length();i++){;int commaLocation=myNavigation.indexOf(charToSearch,i);info("commaLocaton ===> " + commaLocation);if (commaLocation > 0){isThereAComma=true;String A=myNavigation.substring(i,commaLocation);menuItems.add(A);info(menuItems.get(menuItemCounter).toString());i=commaLocation;menuItemCounter++;info("the value of i is ==>" + i);} else {if (isThereAComma){menuItems.add(myNavigation.substring(i,myNavigation.length()));info(menuItems.get(menuItemCounter).toString());break;} else {menuItems.add(myNavigation);info("myNavigation ===> " + myNavigation);menuItemCounter++;break;}}}info("Now Click on the menu items");boolean allmenuitemsclicked=false;for (int i=0;i < menuItems.size();i++){;String menuItem=menuItems.get(i).toString();info(menuItem);while (true){if (web.element(18,"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem+"']").exists()){info("check point " + i);break;} else {think(2.0);if (forms.window(29,"//forms:window[(@name='NAVIGATOR')]").exists()){allmenuitemsclicked=true;break;}}}if (allmenuitemsclicked){break;}think(4.0);web.element(18,"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='" + menuItem+"']").click();info("(" + i+") clicked on ==> "+menuItem);think(2.0);info("Checkpoint " + i+"a");{think(2.0);}}}

	/**
	 * 
	 * @param PAR_Responsiblity 
	 * @param PAR_FirstMenuitem 
	 */
	public void enterResponsiblity(
			@Arg("PAR_Responsiblity") String PAR_Responsiblity,
			@Arg("PAR_FirstMenuitem") String PAR_FirstMenuitem)
			throws Exception {
		{
			web.window(1293, "/web:window[@index='0' or @title='Home']")
					.waitForPage(20, true);
			{
				think(1.0);
			}
			while (true) {
				if (web.element(
						1296,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"
								+ PAR_Responsiblity + "' or @index='58']")
						.exists()) {
					break;
				} else {
					think(1.0);
				}
			}
			web.element(
					1296,
					"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"
							+ PAR_Responsiblity + "' or @index='58']").click();
			think(2.0);
			while (true) {
				if (web.element(
						18,
						"/web:window[@index='0' or @title='Home']/web:document[@index='0']/web:div[@text='"
								+ PAR_FirstMenuitem + "']").exists()) {
					info("Found the menu item");
					break;
				} else {
					think(2.0);
				}
			}
		}
	}

	/**
	 * 
	 * @param FIleName name of the image file
	 * @param TabTime time in mSeconds to wait between tabs
	 */
	
	
	
	

	
	
	
	
	
	
	public void ProcessCert(@Arg("FIleName") String FIleName,
			@Arg("TabTime") int TabTime, @Arg("Desc") String Desc) throws Exception {
		Boolean Flag = true;
		do {
			if (img.target("{{@resourceFile(" + FIleName + ")}}", 55, 12, 0.9,
					"ItemMaster").exists()) {
				delay(TabTime);
				img.target("{{@resourceFile(" + FIleName + ")}}", 50, 11, 0.9,
						"ItemMaster").doubleClick();
				Flag = false;
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_TAB);
				delay(3000);
			}
			;
		} while (Flag);
		info(Desc + "User Logging In");
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {

	}

	/**
	 * The Screenshot function will create a .jpg image in a special sub foldernamed "ScreenShots" in the current result playback session.   The parameters passed are:Web - this is a boolean value where true is if we are capturing a web pageForms - this is a boolean value where ture is if we are capturing a Forms appletImageName - is the name we are giving the image without the file extension
	 * @param Web 
	 * @param Forms 
	 * @param ImageName 
	 */
	public void ScreenShot(@Arg("Web") Boolean Web,
			@Arg("Forms") Boolean Forms, @Arg("ImageName") String ImageName)
			throws Exception {
		
		/* Define Local Resources */
		String ResultsReport;
		String imgName = ImageName + ".jpg";
		Integer HzResolution = 1920;
		Integer VrResolution = 1080;
		
		
		
		/* Create Directory Path for Images */
		
		ResultsReport = getSettings().get("oats_session_result_dir")
				+ "\\ScreenShots";
		
			
		File newFile = new File(ResultsReport);
		
		/* Check to see if the directory already exists and if it does continue if it doesn't
		 * Then create a new directory 
		 */
		
				if(!newFile.isDirectory()){
		
						Files.createDirectory(Paths.get(ResultsReport));
		
				}
				
		/* Save screen captures */		
		
		if (Web) {
			web.window(
					"/web:window[@index='0' or @title='www.oracle.com - Bing']")
					.capturePage(ResultsReport, imgName);
		}
		if (Forms) {
			ft.getScreenCapture(0, 0, HzResolution, VrResolution, ResultsReport + "\\"
					+ imgName);
		}
	}

	/**
	 * 
	 * @param URL Target Environment
	 * @param UserCertificate See Cert Table
	 */
	public void EBSCertificateLogin(@Arg("URL") String URL,
			@Arg("UserCertificate") int UserCertificate) throws Exception {
		beginStep("[1] Navigate to EBS", 0);
		{
			web.window(10, "/web:window[@index='0' or @title='about:blank']")
					.navigate(
							"{{arg.URL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}");
			
			
			delay(20000);
			
			
			
			info("One");
			if( web.link(
				9,
				"/web:window[@index='0' or @title='This site isn’t secure']/web:document[@index='0']/web:a[@text='More information']")
				.exists()){
			
			
			
			
			
			info("two");
			web.link(
					15,
					"/web:window[@index='0' or @title='This site isn’t secure']/web:document[@index='0']/web:a[@text='More information']")
					.click();
			
			
			
			
			{
				think(6.598);
			}
			delay(3000);
			web.link(
					9,
					"/web:window[@index='0' or @title='This site isn’t secure']/web:document[@index='0']/web:a[@text='Go on to the webpage (not recommended)']")
					.click();
			{
				think(6.598);
			}
			
			
			
			delay(5000);
			if(
					web.dialog(
				10,
				"/web:dialog_unknown[@text='The current webpage is trying to open a site in your Trusted sites list. Do you want to allow this?' or @index='0']")
				.exists()
				)
			
				
			   {
			     
			    web.dialog(
				10,
				"/web:dialog_unknown[@text='The current webpage is trying to open a site in your Trusted sites list. Do you want to allow this?' or @index='0']")
				.clickButton(1);
			
			
			    }
			
			
			
			}
			
			
			for (int i = 0; i < 10; i++) {
				
				
				delay(2000);
				
				
				callFunction("CertificateExists");
				
				
				String MyResult = eval("{{CertificateThere}}");
				info("result is:  " + MyResult);
				boolean YesNo = toBoolean(MyResult);
				if (YesNo) {
					
					callFunction("ChooseCertificate", "{{arg.UserCertificate}}");
				     
					break;
				
				
				
				}
			}
			web.window(12,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']")
					.waitForPage(null);
			{
				think(8.471);
			}
			web.button(
					13,
					"/web:window[@index='0' or @title='GCSS-MC Warning Banner']/web:document[@index='0']/web:form[@index='0']/web:input_submit[@name='OK' or @value='OK' or @index='0']")
					.click();
		}
		endStep();
		beginStep("[2] Home (/OA.jsp)", 0);
		{
			callFunction("CertificateExists");
			String MyResult = eval("{{CertificateThere}}");
			info("result is:  " + MyResult);
			boolean YesNo = toBoolean(MyResult);
			if (YesNo) {
				callFunction("ChooseCertificate", "{{arg.UserCertificate}}");
			}
			web.window(14, "/web:window[@index='0' or @title='Home']")
					.waitForPage(null, true);
			{
				think(10.876);
			}
		}
		endStep();
	}

	

	/**
	 * Check to see if Certificate Exists
	 */
public void CertificateExists() throws Exception {
		
		getVariables().set("CertificateThere", "false", Variables.Scope.GLOBAL);
		
		delay(5000);
		
		if (img.target("{{@resourceFile(ImageLib/SelectCertificate.png)}}", 82, 17, 0.9,
		"SecurityCertificatePopUp").exists()){
			
			img.target("{{@resourceFile(ImageLib/SelectCertificate.png)}}", 82, 17, 0.9,
			"SecurityCertificatePopUp").click();
			
			getVariables().set("CertificateThere", "true", Variables.Scope.GLOBAL);
			
			info("Certficate found");
			info("{{CertificateThere}}");
		
		}
		
	}

	/**
	 * Cancels Security Certificate
	 */
	public void CancelCert() throws Exception {
		if (img.target("{{@resourceFile(ImageLib/SelectCertificate.png)}}", 82,
				17, 0.9, "SecurityCertificatePopUp").exists()) {
			img.target("{{@resourceFile(ImageLib/CancelButton.png)}}", 97, 18,
					0.9, "ClickCancelButton").click();
		}
	}

	/**
	 * ChoosCertificate fuction uses a java case statement to select the proper user certificate by translating the cert number to 
	 * the image event that clicks on the nice name the list of certs to nice names is:
	 *
	 *		201		Supply Financial
	 *		203		Warranty
	 *		221		Advanced Search
	 *		223		EATO, Material Redistribution
	 *		243		System Admin
	 *
	 * @param User CertNumber
	 */
	public void ChooseCertificate(@Arg("User") int User) throws Exception {
		
		img.target("{{@resourceFile(ImageLib/MoreChoices.png)}}", 59, 17, 0.95,
		"ClickMoreChoices").click();

		
		Integer Login = User;
		Boolean Flag = true;
		Integer TabbingTIme =1000;
		
		
		switch (Login){
			
		
		
		case 200:
			/* ImageLib/ItemMaster.png */
			
			getVariables().set("MyImage", "ImageLib/ItemMaster.png",
				Variables.Scope.GLOBAL);
			
			getVariables().set("MyDescription", "Item Master ",
				Variables.Scope.GLOBAL);
	
			callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
			break;
		
		
		
		
		
		case 201:
			
			/* ImageLib/SupplyFinancial.png */
			
			getVariables().set("MyImage", "ImageLib/SupplyFinancial.png",
				Variables.Scope.GLOBAL);
			
			getVariables().set("MyDescription", "Supply Financial ",
				Variables.Scope.GLOBAL);
	
			callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
			
			
		break;
		
		
			
			
		case 203:
			
			/* ImageLib/WarranteCert.png */
			
			
			getVariables().set("MyImage", "ImageLib/WarranteCert.png",
				Variables.Scope.GLOBAL);
			getVariables().set("MyDescription", "Warranty ",
					Variables.Scope.GLOBAL);
				
			callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
				
		break;	
			
			
			
			
			
			
			
		case 211:
			
			
			/* ImageLib/UnitAccountManager.png */
			
			getVariables().set("MyImage", "ImageLib/UnitAccountManager.png",
				Variables.Scope.GLOBAL);
			
			getVariables().set("MyDescription", "Unit Account Manager ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
      case 213:
			
    	  /* ImageLib/InventorySupplyNCO.png */
    	  
    	  
    	  getVariables().set("MyImage", "ImageLib/InventorySupplyNCO.png",
				Variables.Scope.GLOBAL);
			
    	  getVariables().set("MyDescription", "Inventory Supply NCO ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
			
			
        case 221:
        	
        	
        	 /* ImageLib/AdvancedSearch.png */
        	
        	getVariables().set("MyImage", "ImageLib/AdvancedSearch.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "Advanced Search ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
        case 223:
        	
        	 /* ImageLib/EATO.png */
			

        	getVariables().set("MyImage", "ImageLib/EATO.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "EATO ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
		
			
			
        case 236:
			

        	/* ImageLib/MaintenanceChief.png */
        	
        	
        	
        	getVariables().set("MyImage", "ImageLib/MaintenanceChief.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "Maintenance Chief ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
				
			
			
			
			
		
        case 238:
			

        	/* ImageLib/ShippingReceivingNCO.png */
        	
        	
        	getVariables().set("MyImage", "ImageLib/ShippingReceivingNCO.png",
				Variables.Scope.GLOBAL);
			
        	getVariables().set("MyDescription", "Shipping Receiving NCO ",
				Variables.Scope.GLOBAL);
			
		callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
			
	break;	
		
			
			
			
			
		case 243: 
			
			
			/* ImageLib/SysAdmin.png */
			
				getVariables().set("MyImage", "ImageLib/SysAdmin.png",
				Variables.Scope.GLOBAL);
			
				getVariables().set("MyDescription", "Sys Admin ",
					Variables.Scope.GLOBAL);
				
			    callFunction("ProcessCert", "{{MyImage}}", TabbingTIme, "{{MyDescription}}");
				
		break;	
			
		
		
		
		default:
			info("Error No Such User Exists");
		break;
			
		}
		
		delay(2000);
		img.target("{{@resourceFile(ImageLib/OKButton.png)}}", 15, 8, 0.91,
				"ClickOKonCert").click();
		
		}
		
		

	public void finish() throws Exception {

		
		
		
	}
}
