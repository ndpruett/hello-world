import oracle.oats.scripting.modules.basic.api.*;
import oracle.oats.scripting.modules.browser.api.*;
import oracle.oats.scripting.modules.functionalTest.api.*;
import oracle.oats.scripting.modules.utilities.api.*;
import oracle.oats.scripting.modules.utilities.api.sql.*;
import oracle.oats.scripting.modules.utilities.api.xml.*;
import oracle.oats.scripting.modules.utilities.api.file.*;
import oracle.oats.scripting.modules.webdom.api.*;
import oracle.oats.scripting.modules.formsFT.api.*;
import oracle.oats.scripting.modules.applet.api.*;

public class script extends IteratingVUserScript {
	@ScriptService oracle.oats.scripting.modules.utilities.api.UtilitiesService utilities;
	@ScriptService oracle.oats.scripting.modules.browser.api.BrowserService browser;
	@ScriptService oracle.oats.scripting.modules.functionalTest.api.FunctionalTestService ft;
	@ScriptService oracle.oats.scripting.modules.webdom.api.WebDomService web;
	@ScriptService oracle.oats.scripting.modules.applet.api.AppletService applet;
	@ScriptService oracle.oats.scripting.modules.formsFT.api.FormsService forms;

	public void initialize() throws Exception {
		getVariables().set("MyURL",
//			"https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin",
//			"https://gcssmc-ebs.cm.gcssmc.sde/OA_HTML/AppsLogin",
			"https://gcssmc-pt-ebs.int.gcssmc.sde/OA_HTML/AppsLogin",
			Variables.Scope.GLOBAL);
		
		browser.launch();
	}

	/**
	 * Add code to be executed each iteration for this virtual user.
	 */
	public void run() throws Exception {
		executeMPR();
		
	} // public void run() throws Exception 
	
	private void navigateToMPR() throws Exception {
		try
		{
			beginStep("navigateToMPR() - Navigate to MPR using 243");
			{
				beginStep(" navigateToMPR() - Navigate to GCSS URL", 0);
				{
					getVariables().set("MyUser","243", Variables.Scope.GLOBAL);
					getScript("CACI_FunctLib_EBSFunctions")
							.callFunction(
									"EBSCertificateLogin",
									"{{MyURL,https://gcssmc-dv-ebs.dev.gcssmc.sde/OA_HTML/AppsLogin}}",
									"{{MyUser,243}}");
				}
				endStep();

				/*
				web.window(1293, "/web:window[@index='0' or @title='Home']")
				.waitForPage(20, true);
				*/
				{
					info ("Navigate debug 2");
					delay(12000);
					info ("Navigate debug 3");
				}
				info ("Navigate debug 4");
				
				getScript("CACI_FunctLib_EBSFunctions").callFunction("enterResponsiblity", "GCSS-MC OBIEE Reports User","Maintenance Production Report");
				delay(2000);
				
				getScript("CACI_FunctLib_EBSFunctions").callFunction("SS_getEBSNavigationAndClickOnMenuItems","Maintenance Production Report",";");
				
				beginStep("Navigate to MPR");
				{
					String screenshotFileName = "01_Navigate_MPR";
					getScript("CACI_FunctLib_EBSFunctions").callFunction("ScreenShot", "true", "false", screenshotFileName);
					screenshotFileName = null;
				}
				endStep();
					
				delay(3000);
				
				//to click the 2nd Open on the notification bar, since the 1st notification bar goes off by default
				for(int i=0; i<5; i++) {
					if (web.notificationBar(15, "/web:window[@index='0' or @title='Home']").exists()) {
						web.notificationBar(15, "/web:window[@index='0' or @title='Home']")
						.clickButton("Open");
						
						break;
					}
					delay(3000);
				} // for(int i=0; i<5; i++)
				
				delay(5000);
				
				//to click the 2nd Open on the notification bar, since the 1st notification bar goes off by default
				for(int i=0; i<5; i++) {
					if (web.notificationBar(15, "/web:window[@index='0' or @title='Home']").exists()) {
						web.notificationBar(15, "/web:window[@index='0' or @title='Home']")
						.clickButton("Open");
						
						break;
					}
					delay(3000);
				} // for(int i=0; i<5; i++)
						
			}
		}
		catch(Exception e) {
			info("navigateToCreateMIItem() : " + e.getMessage());
			throw e;
		}
		endStep();
	} //private void navigateToMPR
	
	private void processMPR() throws Exception {
		try
		{
			String choiceBoxTitle = "";
			String decisionMessage = null;
			
			//Datafile recordcount
			int recordCount = getDatabank("Main_TC_14_Data").getDatabankRecordCount();

			for (int i=1; i<=recordCount; i++)
			{
				//input data record increment
				getDatabank("Main_TC_14_Data").getRecord(i);
				
				beginStep("[4] Maintenance Production Report Parameters", 0);
				{
					forms.captureScreenshot(16);
					{
						think(3.726);
					}
					forms.button(15, "//forms:button[(@name='BLOCKNAME_CLEAR_0')]")
					.click();
					{
						think(2.772);
					}

					forms.textField(17,
						"//forms:textField[(@name='BLOCKNAME_TAMCN_0')]")
							.setText("{{db.Main_TC_14_Data.TAMCN,D000}}");

					forms.textField(18, "//forms:textField[(@name='BLOCKNAME_AAC_0')]")
						.setText("{{db.Main_TC_14_Data.AAC,M29030}}");
	
					forms.textField(19,
					"//forms:textField[(@name='BLOCKNAME_UNITNAME_0')]")
						.setText("{{db.Main_TC_14_Data.UnitName,AAC-M%}}");
	
					forms.textField(20,
					"//forms:textField[(@name='BLOCKNAME_RESOURCE_GROUP_0')]")
						.setText("{{db.Main_TC_14_Data.ResourceGroup,AAC-M29030}}");
	
					think(1.843);
				
					forms.captureScreenshot(21);
					{
						think(3.843);
					}
				
				
					forms.button(18, "//forms:button[(@name='BLOCKNAME_SUBMIT_0')]")
							.click();
					
					think(1.843);
				
				}
				endStep();
				beginStep("[5] Submit Request", 0);
				{
					forms.captureScreenshot(22);
					{
						think(3.843);
					}
					
					if (forms.button(23, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]").exists())
					{
						forms.button(23, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]")
							.click();
						{
							think(1.125);
						}
					
					} //if (forms.button(23, "//forms:button[(@name='WORK_ORDER_SUBMIT_0')]").exists())
				
					info(forms.choiceBox(216, "//forms:choiceBox").getBundleID());
					info(forms.choiceBox(216, "//forms:choiceBox").getName());
					info(forms.choiceBox(216, "//forms:choiceBox").getTitle());
					//info(forms.choiceBox(216, "//forms:choiceBox").getAlertMessage());
					choiceBoxTitle = forms.choiceBox(216, "//forms:choiceBox").getTitle();
					decisionMessage = forms.choiceBox(216, "//forms:choiceBox").getAlertMessage();
					
					if (forms.choiceBox(216, "//forms:choiceBox").exists())
					{
						if (choiceBoxTitle.equalsIgnoreCase("Error"))
						{
							
						beginStep("[6] Error", 0);
						{
							forms.captureScreenshot(215);
							{
								think(2.054);
							}
							forms.choiceBox(216, "//forms:choiceBox").clickButton("OK");
						
							think(2.054);
						
						}
						
						endStep ();
						
						} //if choiceBoxTitle.equalsIgnoreCase("Error")
	
					} // if (forms.choiceBox(216, "//forms:choiceBox").exists())
	
				}
				endStep();
				
				beginStep("[7] Decision", 0);
				{
					if (forms.choiceBox(25, "//forms:choiceBox").exists())
					{
						forms.captureScreenshot(25);
						{
							think(1.824);
						}
						
						if (choiceBoxTitle.equalsIgnoreCase("Decision"))
						{
							String submittedRequestID = getConcurrentRequestIDNumber(decisionMessage);
							Object submittedRequestPhaseObject = null;
							forms.choiceBox(25, "//forms:choiceBox").clickButton("No");
							{
								delay(1000);
							}
							submittedRequestPhaseObject = getScript("ConcurrentRequestJobs").callFunction(
								"getConcurrentRequestPhase", submittedRequestID);
							String submittedRequestPhase = null;
							submittedRequestPhase = submittedRequestPhaseObject.toString();
						
							while (submittedRequestPhase.equals("Running")) {
								submittedRequestPhaseObject = getScript("ConcurrentRequestJobs").callFunction(
									"getConcurrentRequestPhase", submittedRequestID);							
								submittedRequestPhase = submittedRequestPhaseObject.toString();
							} // while (submittedRequestPhase.equals("Running"))
							
	
						} // if (choiceBoxTitle.equalsIgnoreCase("Decision"))
					}
					
					forms.window(26, "//forms:window[(@name='BLOCKNAME')]").activate(
							true);
				}
				endStep();
			
			} //for (int i=1; i<=recordCount; i++)			
		}
		catch (Exception e) {
			info("processMPRO() " + e.getMessage());
			throw e;
		}
		
	} // private void processMPR()
	
	public void executeMPR() throws Exception {
		
		navigateToMPR();
		
		processMPR();
		
		getScript("ConcurrentRequestJobs").callFunction("closeEBSForm");
		
		closeBrowserGCSSMC();
		
	} // public void executeMPR()
	

	public void finish() throws Exception {
	}
	
	public void closeBrowserGCSSMC() throws Exception {
		browser.close();
	}
	
	private String getConcurrentRequestIDNumber(String PAR_myString) throws Exception {
        /*
         * Synopsis this function parses the requestIDNumber from the alert
         * message that has the request id number this is normally called by the
         * function getRequestIDThenClickButton() but it can be used whenever
         * you need to parse a number from any string
         * 
         * @param PAR_myString - This is a string to parse the number from
         * 
         * @return requestID or the number in the string in String type
         * 
         * manny gochuico, CACI International
         */
        final StringBuilder requestID = new StringBuilder(PAR_myString.length());
        for (int i = 0; i < PAR_myString.length(); i++) {
                final char x = PAR_myString.charAt(i);
                if (x > 47 && x < 58) {
                        requestID.append(x);
                }
        }
        return requestID.toString();
	} // end of getConcurrentRequestIDNumber
}
